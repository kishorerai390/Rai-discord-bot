"""
Sentinel Bot Cogs Package.
"""
