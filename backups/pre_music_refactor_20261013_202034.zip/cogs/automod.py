"""
Automated Moderation (AutoMod) Cog.
Detects:
- Spam and message flooding
- Excessive mentions
- Repeated messages
- Custom banned words and regex filters
- Discord invite links
- Suspicious and phishing links
- Excessive emojis and uppercase characters
Applies configurable actions: delete message, warn, or timeout, and logs violations.
"""

from __future__ import annotations

import asyncio
import datetime
import logging
import re
import time
from collections import defaultdict
from typing import TYPE_CHECKING, Dict, List, Optional
import discord
from discord import app_commands
from discord.ext import commands

from config import Colors
from utils.embeds import create_embed, error_embed, info_embed, success_embed, warning_embed
from utils.permissions import is_admin_or_owner

if TYPE_CHECKING:
    from main import SentinelBot

logger = logging.getLogger(__name__)

# Invite link regex
INVITE_REGEX = re.compile(r"(?:https?://)?(?:www\.)?(?:discord\.(?:gg|io|me|li)|discord(?:app)?\.com/invite)/[a-zA-Z0-9]+", re.IGNORECASE)
# Suspicious links regex (free nitro, steam scams, homoglyph & typo domain spoofing)
SUSPICIOUS_REGEX = re.compile(
    r"(?:https?://)?(?:www\.)?(?:[a-zA-Z0-9-]+\.)*(?:steamcomm[a-z0-9-]*\.[a-z]+|steampowered-[a-z0-9-]*\.[a-z]+|d1scord[a-z0-9-]*\.[a-z]+|discrod[a-z0-9-]*\.[a-z]+|discocrd[a-z0-9-]*\.[a-z]+|discor(?:cd|cl|d-gift)[a-z0-9-]*\.[a-z]+|dlscord[a-z0-9-]*\.[a-z]+|discord-nitro[a-z0-9-]*\.[a-z]+|gift-nitro[a-z0-9-]*\.[a-z]+|free-nitro[a-z0-9-]*\.[a-z]+|nitro-airdrop[a-z0-9-]*\.[a-z]+|boost-discord[a-z0-9-]*\.[a-z]+|discordapp\.(?:click|gift|org|info|ru|vip|top|club|fun))",
    re.IGNORECASE,
)
# Custom emoji regex (<:name:id> or <a:name:id>)
EMOJI_REGEX = re.compile(r"<a?:[a-zA-Z0-9_]+:[0-9]+>")
# Unicode emoji regex
UNICODE_EMOJI_REGEX = re.compile(
    r"[\U00010000-\U0010ffff]|[\u2600-\u27bf]|[\u2300-\u23ff]|[\u2b50\u2b55]"
)


class AutoModCog(commands.Cog, name="AutoMod"):
    """Automated Moderation and Content Filtering."""

    def __init__(self, bot: SentinelBot):
        self.bot = bot
        # In-memory spam tracking: (guild_id, user_id) -> list of monotonic timestamps
        self._spam_tracker: Dict[tuple[int, int], List[float]] = defaultdict(list)
        # Duplicate message tracking: (guild_id, user_id) -> (last_msg_content, timestamp)
        self._last_message: Dict[tuple[int, int], tuple[str, float]] = {}
        # Channel-level message burst tracking: channel_id -> list of timestamps
        self._channel_burst_tracker: Dict[int, List[float]] = defaultdict(list)
        # Active auto-slowmodes: channel_id -> expiry_monotonic_timestamp
        self._channel_slowmode_active: Dict[int, float] = {}
        # Ghost mention tracking: message_id -> (author, mention_ids, clean_content, channel_id, guild_id, timestamp)
        self._recent_mentions: Dict[int, tuple[discord.Member, List[int], str, int, int, float]] = {}
        # Join burst tracking for Anti-Raid quarantine: list of monotonic timestamps
        self._join_burst_tracker: List[float] = []

    automod_group = app_commands.Group(
        name="automod",
        description="Automated moderation rules and filters",
        default_permissions=discord.Permissions(administrator=True),
    )

    # ==========================================
    # MESSAGE LISTENER
    # ==========================================

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        # Feature 84: Malicious Webhook Payload Interceptor
        wh_id = getattr(message, "webhook_id", None)
        if isinstance(wh_id, int) and message.guild:
            if SUSPICIOUS_REGEX.search(message.content or "") or ("@everyone" in message.content and "nitro" in message.content.lower()):
                try:
                    await message.delete()
                    if message.guild.me.guild_permissions.manage_webhooks:
                        whs = await message.channel.webhooks()
                        for wh in whs:
                            if wh.id == message.webhook_id:
                                await wh.delete(reason="Rai Security: Pruned malicious webhook posting phishing/nitro scams")
                                break
                except Exception:
                    pass
            return

        # Ignore webhooks, bots, DMs
        if message.author.bot or not message.guild or not isinstance(message.author, discord.Member):
            return

        guild = message.guild
        member = message.author

        # Record mentions for Ghost Mention Catcher before exemption checks
        if message.mentions or message.role_mentions:
            mention_ids = [m.id for m in message.mentions] + [r.id for r in message.role_mentions]
            self._recent_mentions[message.id] = (
                member,
                mention_ids,
                message.clean_content[:300] if message.clean_content else "",
                message.channel.id,
                guild.id,
                time.monotonic(),
            )
            if len(self._recent_mentions) > 500:
                oldest_id = min(self._recent_mentions.keys(), key=lambda k: self._recent_mentions[k][5])
                self._recent_mentions.pop(oldest_id, None)

        # Anti-Raid Sudden Message Velocity Burst Check across any text channel
        if isinstance(message.channel, discord.TextChannel):
            await self._check_channel_burst(message.channel)

        # Exemption checks: Owner, Administrator, Bot, or Whitelisted
        if member.id == guild.owner_id or member.id == self.bot.user.id or member.guild_permissions.administrator:
            return

        role_ids = [r.id for r in member.roles]
        if await self.bot.db.is_whitelisted(guild.id, member.id, role_ids):
            return

        guild_cfg = await self.bot.db.get_or_create_guild_config(guild.id)
        if not guild_cfg.automod_enabled:
            return

        auto_cfg = await self.bot.db.get_automod_config(guild.id)

        # 1. Spam / Flood Detection
        if auto_cfg.spam_detection:
            now = time.monotonic()
            key = (guild.id, member.id)
            timestamps = self._spam_tracker[key]
            # prune older than window
            cutoff = now - auto_cfg.spam_window
            self._spam_tracker[key] = [t for t in timestamps if t > cutoff]
            self._spam_tracker[key].append(now)

            if len(self._spam_tracker[key]) > auto_cfg.spam_limit:
                await self._enforce_automod(message, "Message Flooding / Spam", auto_cfg.action)
                self._spam_tracker[key].clear()
                return

        # 2. Repeated Messages
        key = (guild.id, member.id)
        now = time.monotonic()
        last_content, last_time = self._last_message.get(key, ("", 0.0))
        if message.content and message.content == last_content and (now - last_time) < 10.0:
            await self._enforce_automod(message, "Repeated Message Spam", auto_cfg.action)
            self._last_message[key] = ("", 0.0)
            return
        if message.content:
            self._last_message[key] = (message.content, now)

        # 3. Excessive Mentions
        if len(message.mentions) > auto_cfg.mention_limit:
            await self._enforce_automod(message, f"Excessive Mentions ({len(message.mentions)}/{auto_cfg.mention_limit})", auto_cfg.action)
            return

        # 3.5 New Account Anti-Avatar Raid Shield (Feature 55)
        if len(message.attachments) > 0 and member.avatar is None and isinstance(member.created_at, datetime.datetime):
            acct_age = (datetime.datetime.now(datetime.timezone.utc) - member.created_at).total_seconds()
            if acct_age < 172800.0:  # < 48 hours
                await self._enforce_automod(message, "New Account (<48h) Default Avatar Attachment Shield", "delete")
                return

        # 3.6 Suspicious Rapid Join Self-Bot / Scripted Activity Scanner (Feature 56)
        if isinstance(member.joined_at, datetime.datetime):
            join_age = (datetime.datetime.now(datetime.timezone.utc) - member.joined_at).total_seconds()
            if join_age < 30.0 and (len(message.mentions) >= 3 or "http" in message.content.lower()):
                await self._enforce_automod(message, "Suspicious Rapid Join Self-Bot / Scripted Activity", "timeout")
                return

        # 4. Invite Links
        if auto_cfg.invite_links_block and INVITE_REGEX.search(message.content):
            await self._enforce_automod(message, "Discord Invite Link", auto_cfg.action)
            return

        # 5. Suspicious / Phishing Links
        if auto_cfg.suspicious_links_block and SUSPICIOUS_REGEX.search(message.content):
            await self._enforce_automod(message, "Suspicious / Phishing Link", "timeout")
            return

        # 6. Banned Words
        if auto_cfg.banned_words_enabled and auto_cfg.banned_words:
            banned_list = [w.strip().lower() for w in auto_cfg.banned_words.split(",") if w.strip()]
            lower_content = message.content.lower()
            for word in banned_list:
                if re.search(rf"\b{re.escape(word)}\b", lower_content):
                    await self._enforce_automod(message, "Word Filter Violation", auto_cfg.action)
                    return

        # 7. Excessive Emojis
        if auto_cfg.excessive_emojis_block:
            custom_emojis = len(EMOJI_REGEX.findall(message.content))
            unicode_emojis = len(UNICODE_EMOJI_REGEX.findall(message.content))
            total_emojis = custom_emojis + unicode_emojis
            if total_emojis > auto_cfg.emoji_limit:
                await self._enforce_automod(message, f"Emoji Spam ({total_emojis} emojis)", auto_cfg.action)
                return

        # 8. Excessive Caps
        if auto_cfg.excessive_caps_block and len(message.content) > 15:
            letters = [c for c in message.content if c.isalpha()]
            if letters:
                caps_ratio = sum(1 for c in letters if c.isupper()) / len(letters)
                if (caps_ratio * 100) >= auto_cfg.caps_percentage:
                    await self._enforce_automod(message, f"Excessive Caps ({int(caps_ratio * 100)}%)", auto_cfg.action)
                    return

        # 9. Anti-Spoiler Grid Spam / Client Lag Protection
        if "||" in message.content:
            spoiler_count = message.content.count("||") // 2
            if spoiler_count >= 10:
                await self._enforce_automod(message, f"Excessive Spoiler Grid Spam ({spoiler_count} blocks)", "delete")
                return

    async def _enforce_automod(self, message: discord.Message, reason: str, action: str) -> None:
        """Applies configured enforcement action and sends notification."""
        guild = message.guild
        member = message.author

        # 1. Delete message
        try:
            await message.delete()
        except (discord.Forbidden, discord.NotFound, discord.HTTPException):
            pass

        # 2. Punish member if configured
        punishment_str = "Deleted Message"
        action_word = None
        if action == "kick":
            try:
                await member.kick(reason=f"AutoMod ({reason})")
                action_word = "KICKED"
                punishment_str = "Kicked from Server"
            except (discord.Forbidden, discord.HTTPException):
                action_word = "FLAGGED"
        elif action == "timeout":
            try:
                until = discord.utils.utcnow() + datetime.timedelta(minutes=10)
                await member.timeout(until, reason=f"AutoMod ({reason})")
                action_word = "MUTED"
                punishment_str = "Deleted Message + 10m Timeout"
            except (discord.Forbidden, discord.HTTPException):
                action_word = "FLAGGED"
        elif action == "warn":
            await self.bot.db.add_warning(guild.id, member.id, self.bot.user.id, f"AutoMod: {reason}")
            action_word = "WARNED"
            punishment_str = "Deleted Message + Logged Warning"

        # 3. Public Channel Notice (Matches exact AutoMod format from screenshots)
        if action_word:
            try:
                await message.channel.send(
                    f"🚫 **{member.name}** was **{action_word}** by AutoMod ({reason})."
                )
            except (discord.Forbidden, discord.HTTPException):
                pass

        # 4. Log to AutoMod channel
        log_cfg = await self.bot.db.get_logging_config(guild.id)
        channel_id = log_cfg.automod_channel_id or log_cfg.moderation_channel_id or log_cfg.general_channel_id
        if channel_id:
            channel = guild.get_channel(channel_id)
            if channel and isinstance(channel, discord.TextChannel):
                embed = warning_embed("AutoMod Violation", f"**User:** {member.mention} (`{member.id}`)\n**Channel:** {message.channel.mention}")
                embed.add_field(name="Reason", value=reason, inline=True)
                embed.add_field(name="Action Taken", value=punishment_str, inline=True)
                if message.content:
                    content_preview = message.content[:500] + ("..." if len(message.content) > 500 else "")
                    embed.add_field(name="Original Content", value=f"```{content_preview}```", inline=False)
                try:
                    await channel.send(embed=embed)
                except (discord.Forbidden, discord.HTTPException):
                    pass

        # 5. Dispatch confidential report to owner mod-report channel
        try:
            from utils.owner_reporter import OwnerReporter
            OwnerReporter.send_mod_report(
                self.bot,
                guild.id,
                event="AutoMod Sanction",
                user=member,
                reason=reason,
                action_taken=punishment_str,
                severity="HIGH" if action == "kick" else "MEDIUM",
                details={"Channel": message.channel.mention, "Content": message.content[:200] if message.content else "N/A"},
            )
        except Exception:
            pass

    async def _check_channel_burst(self, channel: discord.TextChannel) -> None:
        """Detect sudden chat bursts (>10 msgs in 4s) across any channel and engage auto-slowmode."""
        now = time.monotonic()
        timestamps = self._channel_burst_tracker[channel.id]
        cutoff = now - 4.0
        self._channel_burst_tracker[channel.id] = [t for t in timestamps if t > cutoff]
        self._channel_burst_tracker[channel.id].append(now)

        if len(self._channel_burst_tracker[channel.id]) >= 10:
            if channel.id in self._channel_slowmode_active:
                return  # Already engaged

            guild = channel.guild
            if not channel.permissions_for(guild.me).manage_channels:
                return

            original_delay = channel.slowmode_delay
            if original_delay >= 5:
                # Channel already has 5s or higher slowmode
                return

            self._channel_slowmode_active[channel.id] = now + 120.0
            self._channel_burst_tracker[channel.id].clear()

            try:
                await channel.edit(slowmode_delay=5, reason="Anti-Raid: Sudden message velocity burst (>10 msgs in 4s)")
                embed = discord.Embed(
                    title="⚠️ Auto-Slowmode Engaged",
                    description=(
                        "High message velocity detected. A temporary **5-second slowmode** "
                        "has been automatically engaged for **2 minutes** to maintain chat stability."
                    ),
                    color=0xE67E22,
                )
                embed.set_footer(text="Anti-Raid Autonomous Protection • Slowmode will reset automatically")
                await channel.send(embed=embed, delete_after=120)

                from utils.owner_reporter import OwnerReporter
                OwnerReporter.send_security_report(
                    self.bot,
                    guild.id,
                    event="Sudden Channel Message Flood / Burst",
                    action_taken=f"Engaged 5s auto-slowmode on #{channel.name} for 120 seconds",
                    user=None,
                    severity="HIGH",
                    details={
                        "Channel": f"`#{channel.name}` (`{channel.id}`)",
                        "Velocity": ">10 messages in 4.0s",
                        "Original Slowmode": f"{original_delay}s",
                        "Auto Slowmode": "5s (2 min duration)",
                    },
                )
            except Exception as e:
                logger.error(f"Failed to engage auto-slowmode on channel {channel.id}: {e}")
                return

            # Background task to revert slowmode
            asyncio.create_task(self._revert_slowmode(channel.id, original_delay))

    async def _revert_slowmode(self, channel_id: int, original_delay: int) -> None:
        """Reverts channel slowmode after cool-off duration."""
        await asyncio.sleep(120.0)
        self._channel_slowmode_active.pop(channel_id, None)
        channel = self.bot.get_channel(channel_id)
        if isinstance(channel, discord.TextChannel) and channel.slowmode_delay == 5:
            try:
                await channel.edit(slowmode_delay=original_delay, reason="Anti-Raid: Burst slowmode duration ended (2 mins)")
                embed = discord.Embed(
                    description="✅ **Auto-slowmode lifted.** Channel velocity has normalized.",
                    color=Colors.SUCCESS,
                )
                await channel.send(embed=embed, delete_after=10)
            except Exception as e:
                logger.debug(f"Could not revert slowmode on channel {channel_id}: {e}")

    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        """Ghost Mention Catcher: detects quickly deleted mentions within 60s."""
        if not message.guild or message.id not in self._recent_mentions:
            return

        author, mention_ids, content, ch_id, guild_id, timestamp = self._recent_mentions.pop(message.id)
        if (time.monotonic() - timestamp) > 60.0:
            return

        channel = message.guild.get_channel(ch_id)
        channel_name = channel.mention if channel else f"#{ch_id}"

        from utils.owner_reporter import OwnerReporter
        OwnerReporter.send_mod_report(
            self.bot,
            guild_id,
            event="Ghost Mention Detected",
            user=author,
            reason="Deleted message containing mentions within 60 seconds",
            action_taken="Discreet Mod Alert Dispatched",
            severity="LOW",
            details={
                "Channel": channel_name,
                "Content": content or "[No text]",
                "Target Count": str(len(mention_ids)),
            },
        )

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Dynamic Anti-Raid Quarantine: Detects sudden join spikes (10+ joins in 15s)."""
        if member.bot:
            return

        # Feature 67: Auto-Quarantine Homoglyph & Zero-Width Username Spoofs
        name_str = member.name or ""
        if any(c in name_str for c in ("\u200b", "\u200c", "\u200d", "\ufeff")):
            if member.guild.me.guild_permissions.manage_nicknames:
                try:
                    await member.edit(nick="[Sanitized Name]", reason="Rai Security: Cleared invisible / zero-width characters in username")
                except Exception:
                    pass

        now = time.monotonic()
        cutoff = now - 15.0
        self._join_burst_tracker = [t for t in self._join_burst_tracker if t > cutoff]
        self._join_burst_tracker.append(now)

        if len(self._join_burst_tracker) >= 10:
            self._join_burst_tracker.clear()
            from utils.owner_reporter import OwnerReporter
            OwnerReporter.send_security_report(
                self.bot,
                member.guild.id,
                event="Mass Join Velocity Spike",
                user=member,
                action_taken="Dynamic Anti-Raid Alert Dispatched to Security Room",
                severity="HIGH",
                details={
                    "Status": "Dynamic Anti-Raid Armed",
                    "Join Spike": "10+ accounts joined within 15s",
                    "Recommendation": "Monitor verification gate and invites",
                },
            )

    # ==========================================
    # SLASH COMMANDS
    # ==========================================

    @automod_group.command(name="enable", description="Enable the AutoMod system")
    @is_admin_or_owner()
    async def automod_enable(self, interaction: discord.Interaction):
        await self.bot.db.update_guild_config(interaction.guild.id, automod_enabled=True)
        await interaction.response.send_message(embed=success_embed("AutoMod Enabled", "Automated moderation filters are now active."), ephemeral=True)

    @automod_group.command(name="disable", description="Disable the AutoMod system")
    @is_admin_or_owner()
    async def automod_disable(self, interaction: discord.Interaction):
        await self.bot.db.update_guild_config(interaction.guild.id, automod_enabled=False)
        await interaction.response.send_message(embed=info_embed("AutoMod Disabled", "Automated moderation filters are now paused."), ephemeral=True)

    @automod_group.command(name="setup", description="Quick setup for AutoMod features and actions")
    @is_admin_or_owner()
    @app_commands.describe(
        action="Action to take when a rule is triggered",
        block_invites="Block Discord invite links",
        block_suspicious_links="Block phishing and scam links",
        block_caps="Block excessive uppercase messages",
    )
    @app_commands.choices(
        action=[
            app_commands.Choice(name="Delete Only", value="delete"),
            app_commands.Choice(name="Delete & Warn", value="warn"),
            app_commands.Choice(name="Delete & Timeout (10m)", value="timeout"),
            app_commands.Choice(name="Delete & Kick from Server", value="kick"),
        ]
    )
    async def automod_setup(
        self,
        interaction: discord.Interaction,
        action: app_commands.Choice[str],
        block_invites: Optional[bool] = None,
        block_suspicious_links: Optional[bool] = None,
        block_caps: Optional[bool] = None,
    ):
        updates = {"action": action.value}
        if block_invites is not None:
            updates["invite_links_block"] = int(block_invites)
        if block_suspicious_links is not None:
            updates["suspicious_links_block"] = int(block_suspicious_links)
        if block_caps is not None:
            updates["excessive_caps_block"] = int(block_caps)

        await self.bot.db.update_automod_config(interaction.guild.id, **updates)
        await self.bot.db.update_guild_config(interaction.guild.id, automod_enabled=True)

        embed = success_embed(
            "AutoMod Configuration Updated",
            f"**Action:** {action.name}\n"
            f"**Block Invites:** {'Yes' if updates.get('invite_links_block', True) else 'No'}\n"
            f"**Block Suspicious Links:** {'Yes' if updates.get('suspicious_links_block', True) else 'No'}\n"
            f"**Block Caps:** {'Yes' if updates.get('excessive_caps_block', True) else 'No'}"
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @automod_group.command(name="words", description="Manage banned words list")
    @is_admin_or_owner()
    @app_commands.describe(
        action="Add, remove, or view banned words",
        words="Comma-separated list of words (e.g. word1, word2)",
    )
    @app_commands.choices(
        action=[
            app_commands.Choice(name="Add Words", value="add"),
            app_commands.Choice(name="Remove Words", value="remove"),
            app_commands.Choice(name="List Words", value="list"),
            app_commands.Choice(name="Clear All", value="clear"),
        ]
    )
    async def automod_words(
        self,
        interaction: discord.Interaction,
        action: app_commands.Choice[str],
        words: Optional[str] = None,
    ):
        cfg = await self.bot.db.get_automod_config(interaction.guild.id)
        existing = [w.strip().lower() for w in cfg.banned_words.split(",") if w.strip()]

        if action.value == "list":
            if not existing:
                await interaction.response.send_message(embed=info_embed("Banned Words", "No banned words currently configured."), ephemeral=True)
                return
            formatted = ", ".join(f"`{w}`" for w in existing)
            await interaction.response.send_message(embed=info_embed(f"Banned Words ({len(existing)})", formatted), ephemeral=True)
            return

        if action.value == "clear":
            await self.bot.db.update_automod_config(interaction.guild.id, banned_words="")
            await interaction.response.send_message(embed=success_embed("Banned Words Cleared", "All banned words have been removed."), ephemeral=True)
            return

        if not words:
            await interaction.response.send_message(embed=error_embed("Missing Words", "Please provide comma-separated words."), ephemeral=True)
            return

        input_words = [w.strip().lower() for w in words.split(",") if w.strip()]

        if action.value == "add":
            combined = set(existing).union(input_words)
            new_str = ",".join(combined)
            await self.bot.db.update_automod_config(interaction.guild.id, banned_words=new_str)
            await interaction.response.send_message(embed=success_embed("Words Added", f"Added {len(input_words)} word(s) to the filter."), ephemeral=True)
        elif action.value == "remove":
            remaining = [w for w in existing if w not in input_words]
            new_str = ",".join(remaining)
            await self.bot.db.update_automod_config(interaction.guild.id, banned_words=new_str)
            await interaction.response.send_message(embed=success_embed("Words Removed", f"Removed {len(input_words)} word(s) from the filter."), ephemeral=True)

    @automod_group.command(name="status", description="Display full AutoMod status and active rules")
    @is_admin_or_owner()
    async def automod_status(self, interaction: discord.Interaction):
        guild_cfg = await self.bot.db.get_or_create_guild_config(interaction.guild.id)
        auto_cfg = await self.bot.db.get_automod_config(interaction.guild.id)

        embed = create_embed(
            title=f"🤖 AutoMod Status — {interaction.guild.name}",
            color=Colors.SUCCESS if guild_cfg.automod_enabled else Colors.DARK,
        )
        embed.add_field(name="Module Enabled", value="🟢 Yes" if guild_cfg.automod_enabled else "🔴 No", inline=True)
        embed.add_field(name="Punishment Action", value=auto_cfg.action.capitalize(), inline=True)
        embed.add_field(name="Spam Limit", value=f"{auto_cfg.spam_limit} msgs / {auto_cfg.spam_window}s", inline=True)
        embed.add_field(name="Mention Limit", value=f"Max {auto_cfg.mention_limit} mentions", inline=True)
        embed.add_field(name="Invite Links Filter", value="Active" if auto_cfg.invite_links_block else "Off", inline=True)
        embed.add_field(name="Suspicious Links Filter", value="Active" if auto_cfg.suspicious_links_block else "Off", inline=True)
        embed.add_field(name="Caps Filter", value=f"{auto_cfg.caps_percentage}%" if auto_cfg.excessive_caps_block else "Off", inline=True)
        embed.add_field(name="Emoji Filter", value=f"Max {auto_cfg.emoji_limit}" if auto_cfg.excessive_emojis_block else "Off", inline=True)

        banned_count = len([w for w in auto_cfg.banned_words.split(",") if w.strip()])
        embed.add_field(name="Banned Words Count", value=str(banned_count), inline=True)

        await interaction.response.send_message(embed=embed, ephemeral=True)

    @automod_group.command(name="config", description="Display full active AutoMod rules, thresholds, and filters")
    @is_admin_or_owner()
    async def automod_config(self, interaction: discord.Interaction):
        await self.automod_status(interaction)

    @automod_group.command(name="whitelist", description="Manage members, roles, or channels exempt from AutoMod filters")
    @is_admin_or_owner()
    @app_commands.describe(
        action="Whitelist action to perform",
        user="Member to exempt",
        role="Role to exempt",
        channel="Channel to exempt",
    )
    @app_commands.choices(
        action=[
            app_commands.Choice(name="Add Exemption", value="add"),
            app_commands.Choice(name="Remove Exemption", value="remove"),
            app_commands.Choice(name="List Exemptions", value="list"),
        ]
    )
    async def automod_whitelist(
        self,
        interaction: discord.Interaction,
        action: app_commands.Choice[str],
        user: Optional[discord.Member] = None,
        role: Optional[discord.Role] = None,
        channel: Optional[discord.TextChannel] = None,
    ):
        guild_id = interaction.guild.id

        if action.value == "list":
            wl = await self.bot.db.get_whitelist(guild_id)
            users = [f"<@{item['target_id']}>" for item in wl if item["target_type"] == "user"]
            roles = [f"<@&{item['target_id']}>" for item in wl if item["target_type"] == "role"]
            channels = [f"<#{item['target_id']}>" for item in wl if item["target_type"] == "channel"]

            embed = create_embed(
                title=f"🛡️ AutoMod Whitelist & Exemptions — {interaction.guild.name}",
                color=Colors.INFO,
            )
            embed.add_field(name=f"Exempt Members ({len(users)})", value=", ".join(users) if users else "*None*", inline=False)
            embed.add_field(name=f"Exempt Roles ({len(roles)})", value=", ".join(roles) if roles else "*None*", inline=False)
            embed.add_field(name=f"Exempt Channels ({len(channels)})", value=", ".join(channels) if channels else "*None*", inline=False)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if not user and not role and not channel:
            await interaction.response.send_message(embed=error_embed("Missing Target", "Please specify a user, role, or channel to exempt."), ephemeral=True)
            return

        target_id = user.id if user else role.id if role else channel.id
        target_type = "user" if user else "role" if role else "channel"
        mention = user.mention if user else role.mention if role else channel.mention

        if action.value == "add":
            await self.bot.db.add_whitelist(guild_id, target_id, target_type, interaction.user.id)
            await interaction.response.send_message(embed=success_embed("Exemption Added", f"Added {mention} to the AutoMod exemption list."), ephemeral=True)
        else:
            removed = await self.bot.db.remove_whitelist(guild_id, target_id, target_type)
            if removed:
                await interaction.response.send_message(embed=success_embed("Exemption Removed", f"Removed {mention} from the AutoMod exemption list."), ephemeral=True)
            else:
                await interaction.response.send_message(embed=warning_embed("Not Found", f"{mention} was not found on the exemption list."), ephemeral=True)

    @automod_group.command(name="blacklist", description="Add or remove keywords and phrases from content filters")
    @is_admin_or_owner()
    @app_commands.describe(
        action="Blacklist operation to perform",
        words="Comma-separated keywords or phrases",
    )
    @app_commands.choices(
        action=[
            app_commands.Choice(name="Add Keywords", value="add"),
            app_commands.Choice(name="Remove Keywords", value="remove"),
            app_commands.Choice(name="List Keywords", value="list"),
            app_commands.Choice(name="Clear All", value="clear"),
        ]
    )
    async def automod_blacklist(
        self,
        interaction: discord.Interaction,
        action: app_commands.Choice[str],
        words: Optional[str] = None,
    ):
        await self.automod_words(interaction, action, words)

    @automod_group.command(name="test", description="Safely evaluate a sample message against active AutoMod rules")
    @is_admin_or_owner()
    @app_commands.describe(message="Sample message text to evaluate against filters")
    async def automod_test(self, interaction: discord.Interaction, message: str):
        auto_cfg = await self.bot.db.get_automod_config(interaction.guild.id)
        results = []
        triggered = []

        # 1. Invite Link Filter
        has_invite = bool(INVITE_REGEX.search(message))
        if auto_cfg.invite_links_block:
            if has_invite:
                results.append("🚨 **Invite Filter:** `TRIGGERED` (Discord invite link detected)")
                triggered.append("Invite Links")
            else:
                results.append("✅ **Invite Filter:** `PASS` (No invite link)")
        else:
            results.append("⚪ **Invite Filter:** `DISABLED`")

        # 2. Suspicious & Phishing Links
        has_suspicious = bool(SUSPICIOUS_REGEX.search(message))
        if auto_cfg.suspicious_links_block:
            if has_suspicious:
                results.append("🚨 **Scam/Phishing Filter:** `TRIGGERED` (Malicious domain pattern matched)")
                triggered.append("Phishing Link")
            else:
                results.append("✅ **Scam/Phishing Filter:** `PASS` (No known scam domain)")
        else:
            results.append("⚪ **Scam/Phishing Filter:** `DISABLED`")

        # 3. Banned Words
        banned = [w.strip().lower() for w in auto_cfg.banned_words.split(",") if w.strip()]
        matched_words = [w for w in banned if re.search(r"\b" + re.escape(w) + r"\b", message, re.IGNORECASE)]
        if matched_words:
            results.append(f"🚨 **Keyword Filter:** `TRIGGERED` (Matched: `{', '.join(matched_words)}`)")
            triggered.append("Banned Word")
        else:
            results.append(f"✅ **Keyword Filter:** `PASS` ({len(banned)} active keywords checked)")

        # 4. Caps Filter
        letters = [c for c in message if c.isalpha()]
        if auto_cfg.excessive_caps_block and len(letters) >= 8:
            caps_pct = (sum(1 for c in letters if c.isupper()) / len(letters)) * 100
            if caps_pct >= auto_cfg.caps_percentage:
                results.append(f"🚨 **Caps Filter:** `TRIGGERED` ({round(caps_pct)}% caps vs {auto_cfg.caps_percentage}% limit)")
                triggered.append("Excessive Caps")
            else:
                results.append(f"✅ **Caps Filter:** `PASS` ({round(caps_pct)}% uppercase)")
        else:
            results.append("✅ **Caps Filter:** `PASS`")

        embed = create_embed(
            title="🧪 AutoMod Rule Evaluation Diagnostic",
            description=f"**Sample Message:**\n```{message[:300]}```\n" + "\n".join(results),
            color=Colors.ERROR if triggered else Colors.SUCCESS,
        )
        if triggered:
            embed.add_field(
                name="Automated Response Simulation",
                value=f"This message would be intercepted with action: **`{auto_cfg.action.upper()}`** due to: {', '.join(triggered)}.",
                inline=False,
            )
        else:
            embed.add_field(
                name="Automated Response Simulation",
                value="✅ This message passed all active AutoMod filters without any violations.",
                inline=False,
            )
        embed.set_footer(text="100% Non-destructive test simulation")
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: SentinelBot):
    await bot.add_cog(AutoModCog(bot))
