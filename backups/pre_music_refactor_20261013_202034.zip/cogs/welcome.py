"""
Customizable Welcome & Goodbye System.
Supports templates, member count formatting, avatar embeds, autorole, DMs, and test previews.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Dict, Optional
import discord
from discord import app_commands
from discord.ext import commands

from config import Colors
from utils.embeds import create_embed, error_embed, info_embed, success_embed
from utils.permissions import is_admin_or_owner

if TYPE_CHECKING:
    from main import SentinelBot

logger = logging.getLogger(__name__)


def format_template(text: str, member: discord.Member | discord.User, guild: Optional[discord.Guild] = None) -> str:
    """Bulletproof placeholder formatter supporting {user}, {username}, {server}, {membercount}, {userid}, {created_at}, {joined_at}."""
    if not text:
        return ""
    g = getattr(member, "guild", None) or guild
    server_name = g.name if g else "the server"
    member_cnt = str(g.member_count) if g and g.member_count else "1"
    user_mention = member.mention if hasattr(member, "mention") else f"<@{member.id}>"
    user_name = getattr(member, "name", str(member))
    user_id = str(getattr(member, "id", "0"))
    created_str = discord.utils.format_dt(member.created_at, "F") if hasattr(member, "created_at") and member.created_at else "Recently"
    joined_dt = getattr(member, "joined_at", None)
    joined_str = discord.utils.format_dt(joined_dt, "F") if joined_dt else "Just now"

    res = text.replace("{user}", user_mention)
    res = res.replace("{username}", user_name)
    res = res.replace("{server}", server_name)
    res = res.replace("{membercount}", member_cnt)
    res = res.replace("{member_count}", member_cnt)
    res = res.replace("{userid}", user_id)
    res = res.replace("{created_at}", created_str)
    res = res.replace("{joined_at}", joined_str)
    return res


def build_sticky_banner(guild: discord.Guild) -> tuple[discord.Embed, discord.ui.View]:
    """Generates an aesthetic quick-navigation bulletin and link buttons for #general-chat."""
    embed = discord.Embed(
        title="✦ 𝓡ᴀɪ 𝕱ᴀᴍ ╏ 𝓦ᴇʟᴄᴏᴍᴇ & 𝓠ᴜɪᴄᴋ 𝓝ᴀᴠɪɢᴀᴛɪᴏɴ ✦",
        description=(
            "Welcome to **#general-chat**! Keep conversations respectful, vibrant, and fun.\n\n"
            "📌 **Quick Hubs & Navigation:**\n"
            "• 📜 <#1545502710101704714> — Server rules, conduct, and safety policy\n"
            "• 🎭 <#1545502722739150898> — Self roles, gaming squads, and theme colors\n"
            "• 🎙️ `➕・𝓒ʀᴇᴀᴛᴇ・𝕽ᴏᴏᴍ` — Instant private & gaming voice lounges\n"
            "• 🛠️ <#1554891396119531602> — Control panel to lock, rename, and manage your VC"
        ),
        color=0x9B59B6,
    )
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    embed.set_footer(
        text="✦ 𝓡ᴀɪ 𝕱ᴀᴍ ╏ Autonomous Guide • Stickied Bulletin ✦",
        icon_url=guild.icon.url if guild.icon else None,
    )
    view = discord.ui.View()
    view.add_item(discord.ui.Button(label="📜 Rules & Guide", style=discord.ButtonStyle.link, url=f"https://discord.com/channels/{guild.id}/1545502710101704714"))
    view.add_item(discord.ui.Button(label="🎭 Pick Roles", style=discord.ButtonStyle.link, url=f"https://discord.com/channels/{guild.id}/1545502722739150898"))
    view.add_item(discord.ui.Button(label="🛠️ Room Control", style=discord.ButtonStyle.link, url=f"https://discord.com/channels/{guild.id}/1554891396119531602"))
    return embed, view


class WelcomeCog(commands.Cog, name="Welcome"):
    """Welcome, onboarding, and stickied server guidance manager."""

    def __init__(self, bot: SentinelBot):
        self.bot = bot
        # Track message activity in sticky-enabled channels: channel_id -> message count
        self._sticky_channels: Dict[int, int] = {1545502730699808768: 0}  # #general-chat default
        self._sticky_messages: Dict[int, Optional[int]] = {}  # channel_id -> message_id
        self._sticky_lock = asyncio.Lock()

    welcome_group = app_commands.Group(
        name="welcome",
        description="Configure welcome greeting system",
        default_permissions=discord.Permissions(administrator=True),
    )

    goodbye_group = app_commands.Group(
        name="goodbye",
        description="Configure departure announcements and goodbye embeds",
        default_permissions=discord.Permissions(administrator=True),
    )

    sticky_group = app_commands.Group(
        name="sticky",
        description="Manage stickied informational banners",
        default_permissions=discord.Permissions(administrator=True),
    )

    # ==========================================
    # LISTENERS
    # ==========================================

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        guild = member.guild
        guild_cfg = await self.bot.db.get_or_create_guild_config(guild.id)
        if not guild_cfg.welcome_enabled:
            return

        w_cfg = await self.bot.db.get_welcome_config(guild.id)

        # 1. Automatic role assignment if set in welcome_config
        if w_cfg.autorole_id:
            role = guild.get_role(w_cfg.autorole_id)
            if role and guild.me.guild_permissions.manage_roles and role < guild.me.top_role:
                try:
                    await member.add_roles(role, reason="Welcome Autorole")
                except (discord.Forbidden, discord.HTTPException) as e:
                    logger.warning(f"Failed to apply autorole to {member.id}: {e}")

        # 2. Welcome Channel Message with Bounded Retries & Permission Verification
        if w_cfg.welcome_channel_id:
            channel = guild.get_channel(w_cfg.welcome_channel_id)
            if not channel and hasattr(self.bot, "fetch_channel"):
                try:
                    channel = await self.bot.fetch_channel(w_cfg.welcome_channel_id)
                except Exception:
                    channel = None

            if not channel and guild.system_channel:
                channel = guild.system_channel

            if channel and isinstance(channel, discord.TextChannel):
                perms = channel.permissions_for(guild.me)
                if not perms.send_messages:
                    logger.warning(f"Cannot send welcome in #{channel.name}: Missing 'Send Messages' permission.")
                else:
                    raw_msg = w_cfg.welcome_message or "Welcome to **{server}**, {user}! You are our **{membercount}**th member."
                    formatted_msg = format_template(raw_msg, member, guild)

                    if w_cfg.embed_enabled and perms.embed_links:
                        embed = create_embed(
                            title=format_template(getattr(w_cfg, "welcome_title", None) or "✦ Welcome to {server}! ✦", member, guild),
                            description=formatted_msg,
                            color=getattr(w_cfg, "welcome_color", None) or Colors.SUCCESS,
                            thumbnail_url=member.display_avatar.url,
                        )
                        embed.add_field(name="👤 Username", value=f"`{member.name}`", inline=True)
                        embed.add_field(name="🆔 User ID", value=f"`{member.id}`", inline=True)
                        embed.add_field(name="👥 Member Count", value=f"**#{guild.member_count or len(guild.members):,}**", inline=True)
                        embed.add_field(name="🗓️ Account Created", value=discord.utils.format_dt(member.created_at, "R"), inline=True)
                        embed.add_field(name="⚡ Joined Server", value=discord.utils.format_dt(discord.utils.utcnow(), "R"), inline=True)
                        if guild.icon:
                            embed.set_author(name=guild.name, icon_url=guild.icon.url)
                        embed.set_footer(text=f"Welcome to {guild.name} • Enjoy your stay!")

                        for attempt in range(2):
                            try:
                                from utils.role_manager import OnboardingRoleView
                                await channel.send(content=member.mention, embed=embed, view=OnboardingRoleView())
                                break
                            except (discord.Forbidden, discord.HTTPException) as e:
                                if attempt == 1:
                                    logger.warning(f"Failed to dispatch welcome embed after retries: {e}")
                                await asyncio.sleep(0.5)
                    else:
                        for attempt in range(2):
                            try:
                                await channel.send(formatted_msg)
                                break
                            except (discord.Forbidden, discord.HTTPException) as e:
                                if attempt == 1:
                                    logger.warning(f"Failed to dispatch welcome message: {e}")
                                await asyncio.sleep(0.5)

        # 3. Welcome DM
        if w_cfg.dm_enabled and not member.bot:
            try:
                dm_text = format_template(
                    w_cfg.welcome_message or f"Welcome to **{guild.name}**, {member.name}! Glad to have you here.",
                    member,
                    guild,
                )
                await member.send(dm_text)
            except (discord.Forbidden, discord.HTTPException):
                pass

        # 4. Auto Server Member Milestone Celebration in #general-chat
        count = guild.member_count or len(guild.members)
        if count % 100 == 0 or count in (100, 250, 500, 1000, 1500, 2000):
            general_ch = guild.get_channel(1545502730699808768)
            if general_ch and w_cfg.welcome_channel_id != 1545502730699808768 and isinstance(general_ch, discord.TextChannel):
                m_embed = discord.Embed(
                    title="🎉 ✦ 𝕸ᴇᴍʙᴇʀ 𝕸ɪʟᴇsᴛᴏɴᴇ 𝕽ᴇᴀᴄʜᴇᴅ! ✦ 🎉",
                    description=(
                        f"We just welcomed our **{count:,}th member**, {member.mention}!\n\n"
                        f"Thank you everyone for making **{guild.name}** an amazing community! 🚀"
                    ),
                    color=0xF1C40F,
                )
                if guild.icon:
                    m_embed.set_thumbnail(url=guild.icon.url)
                m_embed.set_footer(text="✦ ʀᴀɪ Autonomous Ecosystem • Member Milestones ✦")
                try:
                    await general_ch.send(embed=m_embed)
                except Exception:
                    pass

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member | discord.User):
        guild = getattr(member, "guild", None)
        if not guild:
            return

        w_cfg = await self.bot.db.get_welcome_config(guild.id)
        if not getattr(w_cfg, "goodbye_enabled", True):
            return

        if w_cfg.goodbye_channel_id:
            channel = guild.get_channel(w_cfg.goodbye_channel_id)
            if not channel and hasattr(self.bot, "fetch_channel"):
                try:
                    channel = await self.bot.fetch_channel(w_cfg.goodbye_channel_id)
                except Exception:
                    channel = None

            if not channel and guild.system_channel:
                channel = guild.system_channel

            if channel and isinstance(channel, discord.TextChannel):
                perms = channel.permissions_for(guild.me)
                if not perms.send_messages:
                    logger.warning(f"Cannot send goodbye in #{channel.name}: Missing 'Send Messages' permission.")
                else:
                    raw_msg = w_cfg.goodbye_message or "**{username}** has left {server}. We now have **{membercount}** members."
                    formatted_msg = format_template(raw_msg, member, guild)

                    if w_cfg.embed_enabled and perms.embed_links:
                        embed = create_embed(
                            title=format_template(getattr(w_cfg, "goodbye_title", None) or "✦ Farewell from {server} ✦", member, guild),
                            description=formatted_msg,
                            color=getattr(w_cfg, "goodbye_color", None) or Colors.DARK,
                            thumbnail_url=member.display_avatar.url if hasattr(member, "display_avatar") else None,
                        )
                        embed.add_field(name="👤 Username", value=f"`{getattr(member, 'name', str(member))}`", inline=True)
                        embed.add_field(name="🆔 User ID", value=f"`{member.id}`", inline=True)
                        embed.add_field(name="👥 Remaining Members", value=f"**{guild.member_count or len(guild.members):,}**", inline=True)
                        embed.add_field(name="⏱️ Departure Time", value=discord.utils.format_dt(discord.utils.utcnow(), "F"), inline=True)
                        embed.set_footer(text=f"{guild.name} • Member Departure Record")

                        for attempt in range(2):
                            try:
                                await channel.send(embed=embed)
                                break
                            except (discord.Forbidden, discord.HTTPException) as e:
                                if attempt == 1:
                                    logger.warning(f"Failed to dispatch goodbye embed: {e}")
                                await asyncio.sleep(0.5)
                    else:
                        for attempt in range(2):
                            try:
                                await channel.send(formatted_msg)
                                break
                            except (discord.Forbidden, discord.HTTPException) as e:
                                if attempt == 1:
                                    logger.warning(f"Failed to dispatch goodbye message: {e}")
                                await asyncio.sleep(0.5)

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        """Detect when member passes Discord Membership Screening (Agrees to Rules) and unlock verified roles."""
        if getattr(before, "pending", False) and not getattr(after, "pending", False):
            guild = after.guild
            logger.info(f"Member {after} ({after.id}) agreed to server rules / passed membership screening in {guild.name}")
            
            roles_to_add = []
            
            # 1. Check guild welcome autorole config
            w_cfg = await self.bot.db.get_welcome_config(guild.id)
            if w_cfg and w_cfg.autorole_id:
                auto_role = guild.get_role(w_cfg.autorole_id)
                if auto_role and auto_role not in after.roles and auto_role < guild.me.top_role:
                    roles_to_add.append(auto_role)

            # 2. Known community and verified roles for main server (or by name match)
            verified_role = guild.get_role(1549504522953695269)   # ✨ ┆ VERIFIED MEMBER
            community_role = guild.get_role(1545494584203673740)  # 💖 ┆ RAI FAM
            
            if not verified_role:
                for r in guild.roles:
                    rname = r.name.lower()
                    if "verified" in rname and "member" in rname and r < guild.me.top_role:
                        verified_role = r
                        break
            if not community_role:
                for r in guild.roles:
                    rname = r.name.lower()
                    if ("rai" in rname and "fam" in rname) and r < guild.me.top_role:
                        community_role = r
                        break

            if verified_role and verified_role not in after.roles and verified_role < guild.me.top_role:
                roles_to_add.append(verified_role)
            if community_role and community_role not in after.roles and community_role < guild.me.top_role:
                roles_to_add.append(community_role)

            if roles_to_add:
                try:
                    await after.add_roles(*roles_to_add, reason="Automated Gateway: Agreed to Discord Rules & Passed Screening")
                    logger.info(f"Granted {[r.name for r in roles_to_add]} to {after} after passing screening")
                except Exception as err:
                    logger.warning(f"Failed to grant screening roles to {after}: {err}")

            # 3. Log to Security / Mod Report channel
            try:
                from utils.owner_reporter import OwnerReporter
                OwnerReporter.send_mod_report(
                    self.bot,
                    guild.id,
                    event="Membership Screening Completed",
                    user=after,
                    action_taken=f"Granted verified roles: {', '.join(f'`{r.name}`' for r in roles_to_add)}" if roles_to_add else "Verified standing confirmed",
                    details={
                        "Account Age": discord.utils.format_dt(after.created_at, "R"),
                        "Gate": "Discord Native Rule Agreement",
                    },
                )
            except Exception:
                pass

        # 4. Server Boost Detection & Real-time Celebration
        if getattr(before, "premium_since", None) is None and getattr(after, "premium_since", None) is not None:
            await self._handle_server_boost(after)

    async def _handle_server_boost(self, member: discord.Member, is_test: bool = False) -> None:
        """Handles real-time server boost celebration, role award, and VIP announcement."""
        guild = member.guild
        logger.info(f"Member {member} ({member.id}) boosted server {guild.name} (test={is_test})")

        # 1. Assign booster role
        booster_role = guild.get_role(1549504543472353381)  # 💎 ┆ SERVER BOOSTER
        if not booster_role:
            for r in guild.roles:
                if "booster" in r.name.lower() and r < guild.me.top_role:
                    booster_role = r
                    break

        if booster_role and booster_role not in member.roles and booster_role < guild.me.top_role and not is_test:
            try:
                await member.add_roles(booster_role, reason="Server Boost Unlocked")
            except Exception as e:
                logger.warning(f"Failed to award booster role to {member}: {e}")

        # 2. Celebration Embed
        embed = discord.Embed(
            title="💎 ✦ 𝓝ᴇᴡ 𝕾ᴇʀᴠᴇʀ 𝕭ᴏᴏsᴛ ✦ 💎",
            description=(
                f"Huge appreciation to {member.mention} for boosting **{guild.name}**!\n\n"
                f"✨ **Server Tier:** Level {guild.premium_tier} • **Total Boosts:** {guild.premium_subscription_count}\n\n"
                "**VIP Booster Perks Unlocked:**\n"
                "• 💎 `💎 ┆ SERVER BOOSTER` prestige profile role\n"
                "• 🎙️ Ultra-HD 384kbps Priority Bitrate in Dynamic Voice Suites\n"
                "• 👑 Priority Suite customization & VIP badge\n"
                "• ⭐ Instant Private Lounge creation privileges"
            ),
            color=0xF47FFF,  # Nitro Rose Pink
        )
        if member.display_avatar:
            embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(
            text="✦ 𝓡ᴀɪ 𝕱ᴀᴍ ╏ Community Booster Celebration ✦",
            icon_url=guild.icon.url if guild.icon else None,
        )

        general_ch = guild.get_channel(1545502730699808768)  # #general-chat
        if not general_ch or not isinstance(general_ch, discord.TextChannel):
            general_ch = guild.system_channel

        if general_ch and isinstance(general_ch, discord.TextChannel):
            try:
                await general_ch.send(
                    content=f"🎉 **SERVER BOOST!** Thank you {member.mention} for boosting the server!" if not is_test else f"**[PREVIEW]** {member.mention}",
                    embed=embed,
                )
            except Exception as e:
                logger.debug(f"Could not post booster announcement: {e}")

        # 3. Telemetry Report
        if not is_test:
            try:
                from utils.owner_reporter import OwnerReporter
                OwnerReporter.send_room_report(
                    self.bot,
                    guild.id,
                    event="Server Boost Detected",
                    user=member,
                    action_taken="Awarded booster role & enabled 384kbps VIP audio bitrate",
                    details={
                        "Tier": f"Level {guild.premium_tier}",
                        "Total Boosts": str(guild.premium_subscription_count),
                    },
                )
            except Exception:
                pass

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        """Monitors chat volume in stickied channels and cleanly cycles the navigation banner."""
        if message.author.bot or not message.guild or not isinstance(message.channel, discord.TextChannel):
            return

        if message.channel.id not in self._sticky_channels:
            return

        self._sticky_channels[message.channel.id] += 1
        # Re-post every 7 messages to keep it visible at the bottom of active chat
        if self._sticky_channels[message.channel.id] >= 7:
            await self._refresh_sticky_message(message.channel)

    async def _refresh_sticky_message(self, channel: discord.TextChannel) -> None:
        """Atomically deletes the previous sticky message and re-posts it at the bottom."""
        async with self._sticky_lock:
            self._sticky_channels[channel.id] = 0
            old_msg_id = self._sticky_messages.get(channel.id)
            if old_msg_id:
                try:
                    old_msg = await channel.fetch_message(old_msg_id)
                    await old_msg.delete()
                except Exception:
                    pass

            embed, view = build_sticky_banner(channel.guild)
            try:
                new_msg = await channel.send(embed=embed, view=view)
                self._sticky_messages[channel.id] = new_msg.id
            except Exception as e:
                logger.debug(f"Failed to post sticky banner in #{channel.name}: {e}")

    # ==========================================
    # SLASH COMMANDS
    # ==========================================

    @welcome_group.command(name="setup", description="Full setup wizard for welcome and goodbye messages")
    @is_admin_or_owner()
    @app_commands.describe(
        welcome_channel="Channel for welcome messages",
        goodbye_channel="Channel for goodbye messages",
        autorole="Role to automatically assign to new members",
        dm_enabled="Send welcome message as a DM to the user",
        use_embeds="Format welcome and goodbye messages inside embeds",
    )
    async def welcome_setup(
        self,
        interaction: discord.Interaction,
        welcome_channel: Optional[discord.TextChannel] = None,
        goodbye_channel: Optional[discord.TextChannel] = None,
        autorole: Optional[discord.Role] = None,
        dm_enabled: Optional[bool] = None,
        use_embeds: Optional[bool] = None,
    ):
        guild_id = interaction.guild.id
        updates = {}
        if welcome_channel:
            updates["welcome_channel_id"] = welcome_channel.id
        if goodbye_channel:
            updates["goodbye_channel_id"] = goodbye_channel.id
        if autorole:
            updates["autorole_id"] = autorole.id
        if dm_enabled is not None:
            updates["dm_enabled"] = int(dm_enabled)
        if use_embeds is not None:
            updates["embed_enabled"] = int(use_embeds)

        await self.bot.db.update_welcome_config(guild_id, **updates)
        await self.bot.db.update_guild_config(guild_id, welcome_enabled=True)

        embed = success_embed(
            "Welcome System Configured",
            f"**Welcome Channel:** {welcome_channel.mention if welcome_channel else 'Unchanged'}\n"
            f"**Goodbye Channel:** {goodbye_channel.mention if goodbye_channel else 'Unchanged'}\n"
            f"**Autorole:** {autorole.mention if autorole else 'Unchanged'}\n"
            f"**Welcome DM:** {'Enabled' if dm_enabled else 'Disabled' if dm_enabled is not None else 'Unchanged'}\n"
            f"**Embeds:** {'Enabled' if use_embeds else 'Disabled' if use_embeds is not None else 'Unchanged'}",
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @welcome_group.command(name="channel", description="Set welcome or goodbye channel")
    @is_admin_or_owner()
    @app_commands.describe(
        channel_type="Which channel to set",
        channel="Target text channel",
    )
    @app_commands.choices(
        channel_type=[
            app_commands.Choice(name="Welcome Channel", value="welcome"),
            app_commands.Choice(name="Goodbye Channel", value="goodbye"),
        ]
    )
    async def welcome_channel(
        self,
        interaction: discord.Interaction,
        channel_type: app_commands.Choice[str],
        channel: discord.TextChannel,
    ):
        if channel_type.value == "welcome":
            await self.bot.db.update_welcome_config(interaction.guild.id, welcome_channel_id=channel.id)
        else:
            await self.bot.db.update_welcome_config(interaction.guild.id, goodbye_channel_id=channel.id)

        await interaction.response.send_message(
            embed=success_embed(f"{channel_type.name} Set", f"Messages will be posted to {channel.mention}."),
            ephemeral=True,
        )

    @welcome_group.command(name="message", description="Customize welcome or goodbye message template")
    @is_admin_or_owner()
    @app_commands.describe(
        message_type="Which message template to edit",
        template="Text template. Variables: {user}, {username}, {server}, {member_count}",
    )
    @app_commands.choices(
        message_type=[
            app_commands.Choice(name="Welcome Message", value="welcome"),
            app_commands.Choice(name="Goodbye Message", value="goodbye"),
        ]
    )
    async def welcome_message(
        self,
        interaction: discord.Interaction,
        message_type: app_commands.Choice[str],
        template: str,
    ):
        if message_type.value == "welcome":
            await self.bot.db.update_welcome_config(interaction.guild.id, welcome_message=template)
        else:
            await self.bot.db.update_welcome_config(interaction.guild.id, goodbye_message=template)

        await interaction.response.send_message(
            embed=success_embed(f"{message_type.name} Updated", f"New template:\n> {template}"),
            ephemeral=True,
        )

    @welcome_group.command(name="role", description="Set or clear the automatic welcome role")
    @is_admin_or_owner()
    @app_commands.describe(role="Role to assign on join (leave empty to clear)")
    async def welcome_role(self, interaction: discord.Interaction, role: Optional[discord.Role] = None):
        role_id = role.id if role else None
        await self.bot.db.update_welcome_config(interaction.guild.id, autorole_id=role_id)
        if role:
            await interaction.response.send_message(
                embed=success_embed("Welcome Role Configured", f"New members will automatically receive {role.mention}."),
                ephemeral=True,
            )
        else:
            await interaction.response.send_message(
                embed=info_embed("Welcome Role Cleared", "New members will not receive an automatic role."),
                ephemeral=True,
            )


    @welcome_group.command(name="testboost", description="Preview the luxury server booster celebration announcement")
    @is_admin_or_owner()
    async def welcome_testboost(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        if isinstance(interaction.user, discord.Member):
            await self._handle_server_boost(interaction.user, is_test=True)
            await interaction.followup.send("✅ Test boost celebration dispatched to #general-chat.", ephemeral=True)
        else:
            await interaction.followup.send("Must be executed inside a server.", ephemeral=True)

    @welcome_group.command(name="enable", description="Enable welcome arrival announcements")
    @is_admin_or_owner()
    async def welcome_enable(self, interaction: discord.Interaction):
        await self.bot.db.update_guild_config(interaction.guild.id, welcome_enabled=True)
        await interaction.response.send_message(
            embed=success_embed("Welcome System Enabled", "Join announcements and autorole are now active."),
            ephemeral=True,
        )

    @welcome_group.command(name="disable", description="Disable welcome messages")
    @is_admin_or_owner()
    async def welcome_disable(self, interaction: discord.Interaction):
        await self.bot.db.update_guild_config(interaction.guild.id, welcome_enabled=False)
        await interaction.response.send_message(
            embed=info_embed("Welcome System Disabled", "Join announcements are now disabled."),
            ephemeral=True,
        )

    @welcome_group.command(name="config", description="Display current welcome configuration and channel health")
    @is_admin_or_owner()
    async def welcome_config_cmd(self, interaction: discord.Interaction):
        guild = interaction.guild
        g_cfg = await self.bot.db.get_or_create_guild_config(guild.id)
        w_cfg = await self.bot.db.get_welcome_config(guild.id)

        wch = guild.get_channel(w_cfg.welcome_channel_id) if w_cfg.welcome_channel_id else None
        role = guild.get_role(w_cfg.autorole_id) if w_cfg.autorole_id else None

        embed = create_embed(
            title=f"👋 Welcome Configuration — {guild.name}",
            color=Colors.PRIMARY,
        )
        embed.add_field(name="Module Standing", value="🟢 Enabled" if g_cfg.welcome_enabled else "🔴 Disabled", inline=True)
        embed.add_field(name="Welcome Channel", value=wch.mention if wch else "*Not Configured*", inline=True)
        embed.add_field(name="Autorole", value=role.mention if role else "*None*", inline=True)
        embed.add_field(name="Embed Mode", value="Enabled" if w_cfg.embed_enabled else "Plain Text", inline=True)
        embed.add_field(name="DM On Join", value="Enabled" if w_cfg.dm_enabled else "Disabled", inline=True)
        embed.add_field(
            name="Message Template",
            value=f"```{w_cfg.welcome_message or 'Default Template'}```",
            inline=False,
        )
        embed.set_footer(text="Placeholders: {user}, {username}, {server}, {membercount}, {userid}, {created_at}, {joined_at}")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @welcome_group.command(name="test", description="Send a preview test of welcome message with channel diagnostics")
    @is_admin_or_owner()
    async def welcome_test(self, interaction: discord.Interaction):
        w_cfg = await self.bot.db.get_welcome_config(interaction.guild.id)
        member = interaction.user

        raw_welcome = w_cfg.welcome_message or "Welcome to **{server}**, {user}! You are our **{membercount}**th member."
        welcome_text = format_template(raw_welcome, member, interaction.guild)

        channel_ok = False
        perms_ok = False
        if w_cfg.welcome_channel_id:
            target_ch = interaction.guild.get_channel(w_cfg.welcome_channel_id)
            if target_ch and isinstance(target_ch, discord.TextChannel):
                channel_ok = True
                p = target_ch.permissions_for(interaction.guild.me)
                perms_ok = p.send_messages and p.embed_links

        embed = create_embed(
            title=f"✦ Welcome to {interaction.guild.name}! (TEST PREVIEW) ✦",
            description=welcome_text,
            color=Colors.SUCCESS,
            thumbnail_url=member.display_avatar.url,
        )
        embed.add_field(name="👤 Username", value=f"`{member.name}`", inline=True)
        embed.add_field(name="🆔 User ID", value=f"`{member.id}`", inline=True)
        embed.add_field(name="👥 Member Count", value=f"**#{interaction.guild.member_count:,}**", inline=True)
        embed.add_field(name="🗓️ Account Created", value=discord.utils.format_dt(member.created_at, "R"), inline=True)
        embed.add_field(name="⚡ Joined Server", value=discord.utils.format_dt(discord.utils.utcnow(), "R"), inline=True)
        embed.add_field(
            name="🩺 Channel Diagnostics",
            value=(
                f"• Target Channel: {f'<#{w_cfg.welcome_channel_id}>' if channel_ok else '⚠️ Not Set or Deleted'}\n"
                f"• Permissions: {'✅ Send & Embed OK' if perms_ok else '⚠️ Bot lacks Send Messages or Embed Links'}"
            ),
            inline=False,
        )
        await interaction.response.send_message(content=f"**[Preview]** Mention: {member.mention}", embed=embed, ephemeral=True)

    # ==========================================
    # /GOODBYE COMMAND GROUP (MODULES 5 & 7)
    # ==========================================

    @goodbye_group.command(name="setup", description="Configure departure goodbye channel and embed format")
    @is_admin_or_owner()
    @app_commands.describe(
        channel="Channel to receive goodbye departure messages",
        message="Custom template ({username}, {server}, {membercount}, {userid}, {created_at})",
        use_embeds="Format goodbye message inside a sleek embed",
    )
    async def goodbye_setup(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
        message: Optional[str] = None,
        use_embeds: Optional[bool] = True,
    ):
        updates = {
            "goodbye_channel_id": channel.id,
            "goodbye_enabled": 1,
            "embed_enabled": int(use_embeds) if use_embeds is not None else 1,
        }
        if message:
            updates["goodbye_message"] = message

        await self.bot.db.update_welcome_config(interaction.guild.id, **updates)
        embed = success_embed(
            "Goodbye System Configured",
            f"**Channel:** {channel.mention}\n"
            f"**Embed Mode:** {'Enabled' if use_embeds else 'Plain Text'}\n"
            f"**Template:**\n> {message or 'Default Template'}"
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @goodbye_group.command(name="config", description="Display current goodbye settings and channel diagnostics")
    @is_admin_or_owner()
    async def goodbye_config_cmd(self, interaction: discord.Interaction):
        guild = interaction.guild
        w_cfg = await self.bot.db.get_welcome_config(guild.id)
        gch = guild.get_channel(w_cfg.goodbye_channel_id) if w_cfg.goodbye_channel_id else None

        embed = create_embed(
            title=f"👋 Goodbye Configuration — {guild.name}",
            color=Colors.DARK,
        )
        embed.add_field(name="Module Status", value="🟢 Enabled" if getattr(w_cfg, "goodbye_enabled", True) else "🔴 Disabled", inline=True)
        embed.add_field(name="Goodbye Channel", value=gch.mention if gch else "*Not Configured*", inline=True)
        embed.add_field(name="Embed Mode", value="Enabled" if w_cfg.embed_enabled else "Plain Text", inline=True)
        embed.add_field(
            name="Departure Template",
            value=f"```{w_cfg.goodbye_message or 'Default Template'}```",
            inline=False,
        )
        embed.set_footer(text="Placeholders: {username}, {server}, {membercount}, {userid}, {created_at}")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @goodbye_group.command(name="test", description="Send preview goodbye test with channel diagnostics")
    @is_admin_or_owner()
    async def goodbye_test(self, interaction: discord.Interaction):
        w_cfg = await self.bot.db.get_welcome_config(interaction.guild.id)
        member = interaction.user

        raw_goodbye = w_cfg.goodbye_message or "**{username}** has left {server}. We now have **{membercount}** members."
        goodbye_text = format_template(raw_goodbye, member, interaction.guild)

        channel_ok = False
        perms_ok = False
        if w_cfg.goodbye_channel_id:
            target_ch = interaction.guild.get_channel(w_cfg.goodbye_channel_id)
            if target_ch and isinstance(target_ch, discord.TextChannel):
                channel_ok = True
                p = target_ch.permissions_for(interaction.guild.me)
                perms_ok = p.send_messages and p.embed_links

        embed = create_embed(
            title=f"✦ Farewell from {interaction.guild.name} (TEST PREVIEW) ✦",
            description=goodbye_text,
            color=Colors.DARK,
            thumbnail_url=member.display_avatar.url,
        )
        embed.add_field(name="👤 Username", value=f"`{member.name}`", inline=True)
        embed.add_field(name="🆔 User ID", value=f"`{member.id}`", inline=True)
        embed.add_field(name="👥 Remaining Members", value=f"**{interaction.guild.member_count:,}**", inline=True)
        embed.add_field(name="⏱️ Departure Time", value=discord.utils.format_dt(discord.utils.utcnow(), "F"), inline=True)
        embed.add_field(
            name="🩺 Channel Diagnostics",
            value=(
                f"• Target Channel: {f'<#{w_cfg.goodbye_channel_id}>' if channel_ok else '⚠️ Not Set or Deleted'}\n"
                f"• Permissions: {'✅ Send & Embed OK' if perms_ok else '⚠️ Bot lacks Send Messages or Embed Links'}"
            ),
            inline=False,
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @goodbye_group.command(name="enable", description="Enable departure goodbye announcements")
    @is_admin_or_owner()
    async def goodbye_enable(self, interaction: discord.Interaction):
        await self.bot.db.update_welcome_config(interaction.guild.id, goodbye_enabled=1)
        await interaction.response.send_message(embed=success_embed("Goodbye Enabled", "Departure messages are now active."), ephemeral=True)

    @goodbye_group.command(name="disable", description="Disable departure goodbye announcements")
    @is_admin_or_owner()
    async def goodbye_disable(self, interaction: discord.Interaction):
        await self.bot.db.update_welcome_config(interaction.guild.id, goodbye_enabled=0)
        await interaction.response.send_message(embed=info_embed("Goodbye Disabled", "Departure messages are now disabled."), ephemeral=True)

    # ==========================================
    # STICKY BANNER COMMANDS
    # ==========================================

    @sticky_group.command(name="refresh", description="Immediately refresh the stickied navigation banner in this channel")
    @is_admin_or_owner()
    async def sticky_refresh(self, interaction: discord.Interaction):
        if not isinstance(interaction.channel, discord.TextChannel):
            await interaction.response.send_message("Must be executed in a text channel.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        self._sticky_channels[interaction.channel.id] = 0
        await self._refresh_sticky_message(interaction.channel)
        await interaction.followup.send("✅ Stickied bulletin refreshed at the bottom of this channel.", ephemeral=True)

    @sticky_group.command(name="toggle", description="Toggle stickied navigation banner on or off for this channel")
    @is_admin_or_owner()
    async def sticky_toggle(self, interaction: discord.Interaction):
        ch_id = interaction.channel_id
        if ch_id in self._sticky_channels:
            self._sticky_channels.pop(ch_id, None)
            old_id = self._sticky_messages.pop(ch_id, None)
            if old_id and isinstance(interaction.channel, discord.TextChannel):
                try:
                    m = await interaction.channel.fetch_message(old_id)
                    await m.delete()
                except Exception:
                    pass
            await interaction.response.send_message("❌ Stickied bulletin disabled for this channel.", ephemeral=True)
        else:
            self._sticky_channels[ch_id] = 0
            if isinstance(interaction.channel, discord.TextChannel):
                await self._refresh_sticky_message(interaction.channel)
            await interaction.response.send_message("✅ Stickied bulletin enabled for this channel.", ephemeral=True)


async def setup(bot: SentinelBot):
    await bot.add_cog(WelcomeCog(bot))
