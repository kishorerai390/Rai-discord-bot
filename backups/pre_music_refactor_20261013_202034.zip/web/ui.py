"""
Rai Community OS — Discovery Platform V2 (The Raivora).
Top.gg-inspired discovery UX combined with Rai's signature midnight luxury identity.
Full-featured, responsive SPA with global debounced search, discovery cards,
subtle canvas particle background, desktop cursor interaction, and complete community modules.
"""

from __future__ import annotations

UI_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RAI ✦ THE RAIVORA — Community Discovery Platform</title>
  <meta name="description" content="Discover communities, creators, projects, gaming squads, and lossless music powered by Rai Community OS.">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-dark: #07080d;
      --bg-surface: #0f111a;
      --card-bg: rgba(18, 20, 32, 0.78);
      --card-border: rgba(147, 51, 234, 0.22);
      --card-border-hover: rgba(168, 85, 247, 0.55);
      --primary: #9333ea;
      --primary-hover: #a855f7;
      --primary-glow: rgba(147, 51, 234, 0.35);
      --cyan: #06b6d4;
      --cyan-glow: rgba(6, 182, 212, 0.28);
      --pink: #ec4899;
      --emerald: #10b981;
      --amber: #f59e0b;
      --danger: #ef4444;
      --text: #f8fafc;
      --text-muted: #94a3b8;
      --text-dim: #64748b;
      --blurple: #5865F2;
      --glass-nav: rgba(10, 11, 18, 0.88);
      --radius-sm: 8px;
      --radius-md: 12px;
      --radius-lg: 18px;
      --radius-full: 9999px;
    }

    * { margin: 0; padding: 0; box-sizing: border-box; }
    html { scroll-behavior: smooth; }

    body {
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(147, 51, 234, 0.14) 0px, transparent 55%),
        radial-gradient(at 100% 100%, rgba(6, 182, 212, 0.10) 0px, transparent 55%),
        radial-gradient(at 50% 50%, rgba(236, 72, 153, 0.04) 0px, transparent 65%);
      color: var(--text);
      font-family: 'Outfit', -apple-system, BlinkMacSystemFont, sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      overflow-x: hidden;
      position: relative;
    }

    /* SUBTLE CANVAS BACKGROUND */
    #bg-canvas {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 0;
      opacity: 0.65;
    }

    /* DESKTOP CURSOR GLOW */
    #cursor-glow {
      position: fixed;
      width: 380px;
      height: 380px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(147, 51, 234, 0.12) 0%, rgba(6, 182, 212, 0.04) 45%, transparent 70%);
      pointer-events: none;
      transform: translate(-50%, -50%);
      z-index: 1;
      transition: opacity 0.3s ease;
      opacity: 0;
    }

    /* TOP NAVIGATION */
    nav.top-nav {
      position: sticky;
      top: 0;
      z-index: 100;
      background: var(--glass-nav);
      backdrop-filter: blur(24px);
      -webkit-backdrop-filter: blur(24px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      padding: 0.75rem 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1.5rem;
    }
    .brand {
      display: flex;
      align-items: center;
      gap: 0.85rem;
      text-decoration: none;
      color: inherit;
      cursor: pointer;
      flex-shrink: 0;
    }
    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, var(--primary), #7c3aed);
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.3rem;
      box-shadow: 0 0 18px var(--primary-glow);
    }
    .brand-title h1 {
      font-size: 1.25rem;
      font-weight: 800;
      letter-spacing: 0.8px;
      background: linear-gradient(to right, #ffffff, #d8b4fe, #a5f3fc);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: flex;
      align-items: center;
      gap: 0.35rem;
    }
    .brand-title p {
      font-size: 0.7rem;
      color: var(--text-muted);
      letter-spacing: 0.6px;
      text-transform: uppercase;
    }

    /* NAV LINKS */
    .nav-links {
      display: flex;
      align-items: center;
      gap: 0.35rem;
      list-style: none;
      flex-shrink: 0;
    }
    .nav-item {
      padding: 0.45rem 0.85rem;
      border-radius: 8px;
      text-decoration: none;
      color: var(--text-muted);
      font-size: 0.9rem;
      font-weight: 500;
      transition: all 0.2s ease;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 0.3rem;
    }
    .nav-item:hover, .nav-item.active {
      color: #fff;
      background: rgba(147, 51, 234, 0.18);
      border: 1px solid rgba(147, 51, 234, 0.35);
    }

    /* MORE DROPDOWN */
    .nav-dropdown {
      position: relative;
      display: inline-block;
    }
    .nav-dropdown-menu {
      display: none;
      position: absolute;
      top: 100%;
      right: 0;
      min-width: 200px;
      background: rgba(15, 17, 26, 0.96);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(147, 51, 234, 0.3);
      border-radius: var(--radius-md);
      box-shadow: 0 12px 35px rgba(0, 0, 0, 0.65);
      padding: 0.5rem;
      z-index: 150;
      margin-top: 0.5rem;
    }
    .nav-dropdown.open .nav-dropdown-menu { display: block; }
    .nav-dropdown-item {
      padding: 0.55rem 0.9rem;
      border-radius: var(--radius-sm);
      color: var(--text-muted);
      font-size: 0.86rem;
      display: flex;
      align-items: center;
      gap: 0.6rem;
      cursor: pointer;
      text-decoration: none;
      transition: all 0.15s ease;
    }
    .nav-dropdown-item:hover {
      background: rgba(147, 51, 234, 0.2);
      color: #fff;
    }

    /* GLOBAL NAV SEARCH BAR */
    .nav-search-box {
      flex: 1;
      max-width: 360px;
      position: relative;
    }
    .nav-search-input {
      width: 100%;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.12);
      border-radius: var(--radius-full);
      padding: 0.45rem 2.4rem 0.45rem 2.2rem;
      font-size: 0.85rem;
      color: #fff;
      font-family: inherit;
      outline: none;
      transition: all 0.25s ease;
    }
    .nav-search-input:focus {
      background: rgba(255, 255, 255, 0.08);
      border-color: var(--primary);
      box-shadow: 0 0 15px rgba(147, 51, 234, 0.3);
    }
    .nav-search-icon {
      position: absolute;
      left: 0.75rem;
      top: 50%;
      transform: translateY(-50%);
      color: var(--text-dim);
      font-size: 0.9rem;
      pointer-events: none;
    }
    .nav-search-badge {
      position: absolute;
      right: 0.6rem;
      top: 50%;
      transform: translateY(-50%);
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.14);
      border-radius: 4px;
      padding: 1px 5px;
      font-size: 0.68rem;
      color: var(--text-dim);
      font-family: monospace;
    }

    /* AUTOCOMPLETE SEARCH DROPDOWN OVERLAY */
    .search-suggestions-panel {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: rgba(14, 16, 26, 0.98);
      backdrop-filter: blur(28px);
      border: 1px solid rgba(147, 51, 234, 0.35);
      border-radius: var(--radius-md);
      box-shadow: 0 16px 45px rgba(0, 0, 0, 0.85);
      margin-top: 0.5rem;
      max-height: 480px;
      overflow-y: auto;
      z-index: 200;
      padding: 0.75rem;
    }
    .search-suggestions-panel.active { display: block; }
    .search-section-header {
      font-size: 0.72rem;
      font-weight: 700;
      color: var(--cyan);
      text-transform: uppercase;
      letter-spacing: 0.6px;
      margin: 0.6rem 0.4rem 0.3rem 0.4rem;
    }
    .search-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.5rem 0.75rem;
      border-radius: var(--radius-sm);
      cursor: pointer;
      text-decoration: none;
      color: var(--text);
      transition: background 0.15s ease;
    }
    .search-item:hover {
      background: rgba(147, 51, 234, 0.22);
    }
    .search-item-info {
      display: flex;
      flex-direction: column;
      gap: 0.15rem;
    }
    .search-item-title {
      font-size: 0.88rem;
      font-weight: 600;
      color: #fff;
    }
    .search-item-snippet {
      font-size: 0.75rem;
      color: var(--text-muted);
      max-width: 280px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    /* NAV ACTIONS */
    .nav-actions {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      flex-shrink: 0;
    }

    /* BUTTONS */
    .btn {
      padding: 0.52rem 1.1rem;
      border-radius: 10px;
      font-size: 0.88rem;
      font-weight: 600;
      font-family: inherit;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      text-decoration: none;
      border: none;
      white-space: nowrap;
    }
    .btn-primary {
      background: linear-gradient(135deg, var(--primary), #7c3aed);
      color: #fff;
      box-shadow: 0 4px 15px var(--primary-glow);
    }
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 22px rgba(147, 51, 234, 0.55);
    }
    .btn-discord {
      background: var(--blurple);
      color: #fff;
      box-shadow: 0 4px 14px rgba(88, 101, 242, 0.35);
    }
    .btn-discord:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(88, 101, 242, 0.5);
    }
    .btn-outline {
      background: rgba(255, 255, 255, 0.05);
      color: var(--text);
      border: 1px solid rgba(255, 255, 255, 0.12);
    }
    .btn-outline:hover {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.28);
      transform: translateY(-2px);
    }
    .btn-sm {
      padding: 0.35rem 0.75rem;
      font-size: 0.8rem;
      border-radius: 8px;
    }
    .btn-lg {
      padding: 0.85rem 1.8rem;
      font-size: 1rem;
      border-radius: 12px;
    }

    /* USER PROFILE BADGE */
    .user-profile-btn {
      display: flex;
      align-items: center;
      gap: 0.55rem;
      background: rgba(255, 255, 255, 0.06);
      border: 1px solid rgba(255, 255, 255, 0.14);
      padding: 0.3rem 0.8rem 0.3rem 0.4rem;
      border-radius: var(--radius-full);
      cursor: pointer;
      color: inherit;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    .user-profile-btn:hover {
      background: rgba(147, 51, 234, 0.2);
      border-color: rgba(147, 51, 234, 0.4);
    }
    .user-avatar {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: var(--primary);
      object-fit: cover;
    }
    .badge-count {
      background: var(--pink);
      color: #fff;
      font-size: 0.7rem;
      font-weight: 700;
      padding: 0.1rem 0.45rem;
      border-radius: var(--radius-full);
    }

    /* MAIN CONTAINER */
    main.main-content {
      flex: 1;
      width: 100%;
      max-width: 1320px;
      margin: 0 auto;
      padding: 2rem 1.5rem 5rem 1.5rem;
      position: relative;
      z-index: 10;
    }

    /* HERO SECTION */
    .discovery-hero {
      text-align: center;
      padding: 4.5rem 1rem 3rem 1rem;
      position: relative;
    }
    .hero-badge {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      background: rgba(147, 51, 234, 0.12);
      border: 1px solid rgba(147, 51, 234, 0.32);
      color: #d8b4fe;
      padding: 0.35rem 1rem;
      border-radius: var(--radius-full);
      font-size: 0.82rem;
      font-weight: 600;
      letter-spacing: 0.8px;
      margin-bottom: 1.4rem;
      text-transform: uppercase;
    }
    .hero-title {
      font-size: 3.6rem;
      font-weight: 900;
      line-height: 1.12;
      margin-bottom: 1rem;
      background: linear-gradient(135deg, #ffffff 10%, #e2e8f0 45%, #c084fc 80%, #67e8f9 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      letter-spacing: -0.5px;
    }
    .hero-subtitle {
      font-size: 1.2rem;
      color: var(--text-muted);
      max-width: 650px;
      margin: 0 auto 2.2rem auto;
      line-height: 1.6;
    }

    /* HERO SEARCH BAR */
    .hero-search-wrapper {
      max-width: 680px;
      margin: 0 auto 2rem auto;
      position: relative;
    }
    .hero-search-box {
      display: flex;
      align-items: center;
      background: rgba(18, 20, 32, 0.92);
      border: 1.5px solid rgba(147, 51, 234, 0.4);
      box-shadow: 0 10px 35px rgba(0, 0, 0, 0.6), 0 0 25px rgba(147, 51, 234, 0.2);
      border-radius: var(--radius-full);
      padding: 0.45rem 0.6rem 0.45rem 1.4rem;
      transition: all 0.3s ease;
    }
    .hero-search-box:focus-within {
      border-color: var(--primary-hover);
      box-shadow: 0 12px 45px rgba(0, 0, 0, 0.75), 0 0 35px rgba(147, 51, 234, 0.35);
      transform: translateY(-2px);
    }
    .hero-search-input {
      flex: 1;
      background: transparent;
      border: none;
      color: #fff;
      font-size: 1.05rem;
      font-family: inherit;
      outline: none;
      padding: 0.5rem 0;
    }
    .hero-search-input::placeholder { color: var(--text-dim); }

    .hero-actions {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1.2rem;
      flex-wrap: wrap;
    }

    /* CATEGORY PILLS BAR */
    .category-pills-bar {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      overflow-x: auto;
      padding: 1.5rem 0 2rem 0;
      scrollbar-width: none;
    }
    .category-pills-bar::-webkit-scrollbar { display: none; }
    .cat-pill {
      display: inline-flex;
      align-items: center;
      gap: 0.6rem;
      background: rgba(18, 20, 32, 0.8);
      border: 1px solid rgba(255, 255, 255, 0.09);
      padding: 0.65rem 1.15rem;
      border-radius: var(--radius-full);
      color: var(--text);
      font-size: 0.9rem;
      font-weight: 600;
      text-decoration: none;
      cursor: pointer;
      white-space: nowrap;
      transition: all 0.25s ease;
    }
    .cat-pill:hover, .cat-pill.active {
      background: rgba(147, 51, 234, 0.22);
      border-color: rgba(147, 51, 234, 0.5);
      color: #fff;
      transform: translateY(-2px);
      box-shadow: 0 6px 18px rgba(147, 51, 234, 0.25);
    }
    .cat-pill-count {
      background: rgba(255, 255, 255, 0.1);
      border-radius: var(--radius-full);
      padding: 0.1rem 0.45rem;
      font-size: 0.72rem;
      color: var(--text-muted);
    }

    /* SECTION TITLES */
    .section-title {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin: 3.5rem 0 1.5rem 0;
    }
    .title-group {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    .title-text {
      font-size: 1.45rem;
      font-weight: 800;
      color: #fff;
      letter-spacing: -0.2px;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .title-desc {
      font-size: 0.85rem;
      color: var(--text-muted);
      margin-top: 0.2rem;
    }

    /* DISCOVERY CARD SYSTEM (Reusable across all modules) */
    .discovery-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 1.4rem;
    }
    .discovery-card {
      background: var(--card-bg);
      backdrop-filter: blur(16px);
      border: 1px solid var(--card-border);
      border-radius: var(--radius-lg);
      padding: 1.4rem;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      overflow: hidden;
    }
    .discovery-card:hover {
      transform: translateY(-4px);
      border-color: var(--card-border-hover);
      box-shadow: 0 14px 35px rgba(0, 0, 0, 0.65), 0 0 25px rgba(147, 51, 234, 0.2);
    }
    .card-top {
      display: flex;
      align-items: flex-start;
      gap: 1rem;
      margin-bottom: 0.85rem;
    }
    .card-media-icon {
      width: 52px;
      height: 52px;
      border-radius: var(--radius-md);
      background: linear-gradient(135deg, rgba(147, 51, 234, 0.25), rgba(6, 182, 212, 0.2));
      border: 1px solid rgba(255, 255, 255, 0.1);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.8rem;
      flex-shrink: 0;
      overflow: hidden;
    }
    .card-media-icon img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .card-heading {
      flex: 1;
      overflow: hidden;
    }
    .card-name {
      font-size: 1.1rem;
      font-weight: 700;
      color: #fff;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      display: flex;
      align-items: center;
      gap: 0.4rem;
    }
    .card-subtitle {
      font-size: 0.78rem;
      color: var(--cyan);
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-top: 0.15rem;
    }
    .card-desc {
      font-size: 0.88rem;
      color: var(--text-muted);
      line-height: 1.5;
      margin-bottom: 1rem;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
    .card-tags {
      display: flex;
      align-items: center;
      gap: 0.4rem;
      flex-wrap: wrap;
      margin-bottom: 1.1rem;
    }
    .tag-badge {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: var(--radius-full);
      padding: 0.15rem 0.55rem;
      font-size: 0.72rem;
      color: var(--text-dim);
      font-weight: 500;
    }
    .card-metrics {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      padding-top: 0.85rem;
      font-size: 0.8rem;
      color: var(--text-muted);
    }
    .card-bottom-actions {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin-top: 0.85rem;
    }

    /* PILLS & BADGES */
    .pill {
      font-size: 0.7rem;
      font-weight: 700;
      padding: 0.2rem 0.55rem;
      border-radius: var(--radius-full);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      display: inline-flex;
      align-items: center;
      gap: 0.3rem;
    }
    .pill-purple { background: rgba(147, 51, 234, 0.18); color: #d8b4fe; border: 1px solid rgba(147, 51, 234, 0.35); }
    .pill-cyan { background: rgba(6, 182, 212, 0.15); color: #67e8f9; border: 1px solid rgba(6, 182, 212, 0.3); }
    .pill-pink { background: rgba(236, 72, 153, 0.15); color: #f472b6; border: 1px solid rgba(236, 72, 153, 0.3); }
    .pill-green { background: rgba(16, 185, 129, 0.15); color: #6ee7b7; border: 1px solid rgba(16, 185, 129, 0.3); }
    .pill-amber { background: rgba(245, 158, 11, 0.15); color: #fcd34d; border: 1px solid rgba(245, 158, 11, 0.3); }

    /* FEATURED SPOTLIGHT CARD */
    .spotlight-card {
      background: linear-gradient(135deg, rgba(28, 22, 50, 0.9), rgba(12, 15, 28, 0.95));
      border: 1px solid rgba(168, 85, 247, 0.35);
      box-shadow: 0 16px 45px rgba(0, 0, 0, 0.7), 0 0 30px rgba(147, 51, 234, 0.22);
      border-radius: var(--radius-lg);
      padding: 2.2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 2rem;
      margin-bottom: 2.5rem;
      position: relative;
      overflow: hidden;
    }
    .spotlight-badge {
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
      background: rgba(236, 72, 153, 0.2);
      color: #f472b6;
      border: 1px solid rgba(236, 72, 153, 0.35);
      border-radius: var(--radius-full);
      padding: 0.25rem 0.75rem;
      font-size: 0.78rem;
      font-weight: 700;
      margin-bottom: 0.75rem;
    }
    .spotlight-content h3 {
      font-size: 2rem;
      font-weight: 800;
      color: #fff;
      margin-bottom: 0.6rem;
      letter-spacing: -0.3px;
    }
    .spotlight-content p {
      font-size: 1rem;
      color: var(--text-muted);
      max-width: 620px;
      line-height: 1.6;
      margin-bottom: 1.4rem;
    }

    /* RYTHM AUDIO PREVIEW WIDGET */
    .player-widget {
      background: linear-gradient(135deg, rgba(20, 24, 40, 0.92), rgba(10, 12, 22, 0.98));
      border: 1px solid rgba(147, 51, 234, 0.35);
      box-shadow: 0 16px 45px rgba(0, 0, 0, 0.7), 0 0 30px rgba(147, 51, 234, 0.18);
      border-radius: var(--radius-lg);
      padding: 1.4rem 1.8rem;
      backdrop-filter: blur(20px);
      margin-bottom: 2rem;
    }
    .player-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 1rem;
      padding-bottom: 0.75rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }
    .player-main {
      display: flex;
      align-items: center;
      gap: 1.2rem;
    }
    .player-disc {
      width: 58px;
      height: 58px;
      border-radius: 50%;
      background: radial-gradient(circle, #0f172a 25%, #581c87 65%, #06b6d4 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.6rem;
      box-shadow: 0 0 20px rgba(147, 51, 234, 0.5);
      animation: spin 6s linear infinite;
    }
    .player-disc.paused { animation-play-state: paused; }
    @keyframes spin { 100% { transform: rotate(360deg); } }
    .player-info { flex: 1; }
    .player-title { font-size: 1.05rem; font-weight: 700; color: #fff; }
    .player-artist { font-size: 0.82rem; color: var(--text-muted); margin-top: 0.2rem; }
    .player-controls { display: flex; align-items: center; gap: 0.6rem; }
    .ctrl-icon-btn {
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.12);
      color: #fff;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 0.95rem;
      transition: all 0.2s;
    }
    .ctrl-icon-btn:hover { background: rgba(147, 51, 234, 0.3); border-color: var(--primary); }
    .play-btn {
      width: 44px;
      height: 44px;
      border-radius: 50%;
      background: linear-gradient(135deg, var(--primary), #7c3aed);
      color: #fff;
      border: none;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 1.1rem;
      box-shadow: 0 4px 15px var(--primary-glow);
      transition: all 0.2s;
    }
    .play-btn:hover { transform: scale(1.08); box-shadow: 0 6px 20px rgba(147, 51, 234, 0.6); }

    /* EQUALIZER BARS */
    .eq-bars { display: flex; align-items: flex-end; gap: 2px; height: 16px; }
    .eq-bar {
      width: 3px;
      background: var(--cyan);
      border-radius: 2px;
      animation: equalize 0.8s infinite ease-in-out alternate;
    }
    .eq-bar:nth-child(1) { height: 60%; animation-delay: 0.1s; }
    .eq-bar:nth-child(2) { height: 100%; animation-delay: 0.3s; }
    .eq-bar:nth-child(3) { height: 40%; animation-delay: 0.2s; }
    .eq-bar:nth-child(4) { height: 80%; animation-delay: 0.4s; }
    .eq-bar.paused { animation-play-state: paused; height: 30% !important; }
    @keyframes equalize { 0% { height: 20%; } 100% { height: 100%; } }

    /* FILTERS & SEARCH ROW */
    .filters-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
      margin-bottom: 1.8rem;
      background: rgba(15, 17, 26, 0.6);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: var(--radius-md);
      padding: 0.85rem 1.2rem;
    }
    .filter-group { display: flex; align-items: center; gap: 0.6rem; flex-wrap: wrap; }
    .select-field, .input-field {
      background: rgba(0, 0, 0, 0.35);
      border: 1px solid rgba(255, 255, 255, 0.12);
      border-radius: var(--radius-sm);
      color: #fff;
      padding: 0.45rem 0.85rem;
      font-size: 0.85rem;
      font-family: inherit;
      outline: none;
      transition: border-color 0.2s;
    }
    .select-field:focus, .input-field:focus { border-color: var(--primary); }

    /* SKELETON LOADERS */
    .skeleton-card {
      background: rgba(18, 20, 32, 0.5);
      border: 1px solid rgba(255, 255, 255, 0.05);
      border-radius: var(--radius-lg);
      padding: 1.4rem;
      min-height: 200px;
      animation: pulse 1.6s infinite ease-in-out;
    }
    @keyframes pulse { 0%, 100% { opacity: 0.5; } 50% { opacity: 0.85; } }

    /* EMPTY & ERROR STATES */
    .state-box {
      text-align: center;
      padding: 3.5rem 1.5rem;
      background: rgba(15, 17, 26, 0.6);
      border: 1px dashed rgba(255, 255, 255, 0.12);
      border-radius: var(--radius-lg);
      grid-column: 1 / -1;
    }
    .state-icon { font-size: 2.8rem; margin-bottom: 0.75rem; }
    .state-title { font-size: 1.25rem; font-weight: 700; color: #fff; margin-bottom: 0.4rem; }
    .state-desc { font-size: 0.88rem; color: var(--text-muted); max-width: 440px; margin: 0 auto 1.4rem auto; line-height: 1.5; }

    /* MODAL */
    .modal-overlay {
      position: fixed;
      top: 0; left: 0; width: 100vw; height: 100vh;
      background: rgba(4, 5, 8, 0.85);
      backdrop-filter: blur(16px);
      z-index: 1000;
      display: none;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
    }
    .modal-overlay.active { display: flex; }
    .modal-card {
      background: rgba(15, 17, 26, 0.98);
      border: 1px solid rgba(147, 51, 234, 0.4);
      box-shadow: 0 25px 60px rgba(0, 0, 0, 0.85), 0 0 35px rgba(147, 51, 234, 0.25);
      border-radius: var(--radius-lg);
      width: 100%;
      max-width: 600px;
      max-height: 88vh;
      overflow-y: auto;
      padding: 1.8rem;
      position: relative;
    }
    .modal-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 1.2rem;
      padding-bottom: 0.8rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }
    .modal-close {
      background: transparent;
      border: none;
      color: var(--text-muted);
      font-size: 1.5rem;
      cursor: pointer;
      line-height: 1;
    }
    .modal-close:hover { color: #fff; }

    /* KANBAN BOARD */
    .kanban-board {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 1rem;
      margin-top: 1rem;
    }
    .kanban-col {
      background: rgba(0, 0, 0, 0.35);
      border: 1px solid rgba(255, 255, 255, 0.07);
      border-radius: var(--radius-md);
      padding: 0.8rem;
      min-height: 240px;
    }
    .kanban-header {
      font-size: 0.78rem;
      font-weight: 700;
      color: var(--cyan);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 0.8rem;
      display: flex;
      justify-content: space-between;
    }
    .kanban-task {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: var(--radius-sm);
      padding: 0.7rem;
      margin-bottom: 0.6rem;
      font-size: 0.82rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .kanban-task:hover {
      background: rgba(147, 51, 234, 0.2);
      border-color: var(--primary);
    }

    /* FOOTER */
    footer.site-footer {
      background: rgba(10, 11, 18, 0.95);
      border-top: 1px solid rgba(255, 255, 255, 0.08);
      padding: 4rem 2rem 2rem 2rem;
      margin-top: auto;
      position: relative;
      z-index: 10;
    }
    .footer-content {
      max-width: 1320px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr;
      gap: 3rem;
      margin-bottom: 3rem;
    }
    .footer-col h4 {
      color: #fff;
      font-size: 0.92rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.6px;
      margin-bottom: 1.1rem;
    }
    .footer-col ul { list-style: none; display: flex; flex-direction: column; gap: 0.65rem; }
    .footer-col a {
      color: var(--text-muted);
      text-decoration: none;
      font-size: 0.86rem;
      transition: color 0.2s;
      cursor: pointer;
    }
    .footer-col a:hover { color: #fff; }
    .footer-bottom {
      max-width: 1320px;
      margin: 0 auto;
      padding-top: 1.8rem;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: var(--text-dim);
      font-size: 0.82rem;
      flex-wrap: wrap;
      gap: 1rem;
    }

    /* MOBILE NAV TOGGLE */
    .mobile-nav-toggle {
      display: none;
      background: transparent;
      border: 1px solid rgba(255, 255, 255, 0.15);
      color: #fff;
      padding: 0.4rem 0.65rem;
      border-radius: var(--radius-sm);
      font-size: 1.2rem;
      cursor: pointer;
    }

    /* RESPONSIVE DESIGN */
    @media (max-width: 1024px) {
      .footer-content { grid-template-columns: 1fr 1fr; }
      .nav-links { display: none; }
      .mobile-nav-toggle { display: block; }
      nav.top-nav { padding: 0.75rem 1.2rem; }
    }

    @media (max-width: 768px) {
      .hero-title { font-size: 2.5rem; }
      .nav-search-box { display: none; }
      .footer-content { grid-template-columns: 1fr; }
      .spotlight-card { flex-direction: column; text-align: center; }
      .discovery-grid { grid-template-columns: 1fr; }
    }

    /* ==========================================
       V3 PLATFORM UPGRADE: PULSE, LIVE NOW & RT
       ========================================== */
    /* REALTIME STATUS PILL */
    .rt-status-pill {
      display: inline-flex;
      align-items: center;
      gap: 0.45rem;
      padding: 0.32rem 0.8rem;
      border-radius: var(--radius-full);
      font-size: 0.78rem;
      font-weight: 600;
      background: rgba(15, 17, 26, 0.85);
      border: 1px solid rgba(255, 255, 255, 0.12);
      color: var(--text-muted);
      cursor: default;
      transition: all 0.25s ease;
      white-space: nowrap;
    }
    .rt-dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      display: inline-block;
    }
    .rt-dot.live {
      background: var(--emerald);
      box-shadow: 0 0 10px rgba(16, 185, 129, 0.7);
      animation: slowPulse 2s infinite ease-in-out;
    }
    .rt-dot.reconnecting {
      background: var(--amber);
      box-shadow: 0 0 10px rgba(245, 158, 11, 0.6);
      animation: slowPulse 1.2s infinite ease-in-out;
    }
    .rt-dot.unavailable {
      background: var(--text-dim);
      box-shadow: none;
    }
    @keyframes slowPulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.3; transform: scale(0.88); }
    }

    /* ✦ RAI PULSE SECTION */
    .pulse-section {
      background: linear-gradient(135deg, rgba(17, 19, 32, 0.95), rgba(11, 13, 22, 0.98));
      border: 1px solid rgba(147, 51, 234, 0.35);
      box-shadow: 0 12px 35px rgba(0, 0, 0, 0.4), 0 0 25px rgba(147, 51, 234, 0.15);
      border-radius: var(--radius-lg);
      padding: 1.8rem;
      margin: 2.5rem 0;
      position: relative;
      overflow: hidden;
    }
    .pulse-section::before {
      content: '';
      position: absolute;
      top: -60px;
      right: -60px;
      width: 220px;
      height: 220px;
      background: radial-gradient(circle, rgba(147, 51, 234, 0.22) 0%, transparent 70%);
      pointer-events: none;
    }
    .pulse-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 1rem;
      margin-bottom: 1.5rem;
      padding-bottom: 1rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.07);
    }
    .pulse-title-wrap h3 {
      font-size: 1.35rem;
      font-weight: 800;
      color: #fff;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      letter-spacing: 0.4px;
    }
    .pulse-title-wrap p {
      font-size: 0.84rem;
      color: var(--text-muted);
      margin-top: 0.25rem;
    }
    .pulse-badge-live {
      display: inline-flex;
      align-items: center;
      gap: 0.45rem;
      padding: 0.35rem 0.9rem;
      border-radius: var(--radius-full);
      background: rgba(16, 185, 129, 0.12);
      border: 1px solid rgba(16, 185, 129, 0.4);
      color: var(--emerald);
      font-size: 0.78rem;
      font-weight: 700;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    .pulse-badge-live .live-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--emerald);
      box-shadow: 0 0 10px rgba(16, 185, 129, 0.8);
      animation: slowPulse 2s infinite ease-in-out;
    }
    .pulse-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
      gap: 1rem;
      margin-bottom: 1.6rem;
    }
    .pulse-stat-card {
      background: rgba(0, 0, 0, 0.3);
      border: 1px solid rgba(255, 255, 255, 0.06);
      border-radius: var(--radius-md);
      padding: 1rem;
      text-align: center;
      transition: all 0.25s ease;
    }
    .pulse-stat-card:hover {
      border-color: rgba(147, 51, 234, 0.4);
      background: rgba(147, 51, 234, 0.08);
      transform: translateY(-2px);
    }
    .pulse-stat-icon {
      font-size: 1.4rem;
      margin-bottom: 0.3rem;
      display: block;
    }
    .pulse-stat-val {
      font-size: 1.55rem;
      font-weight: 800;
      color: #fff;
      font-family: 'JetBrains Mono', monospace;
      line-height: 1.2;
      transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .pulse-val-updated {
      color: var(--cyan) !important;
      text-shadow: 0 0 14px rgba(6, 182, 212, 0.8);
      transform: scale(1.08);
      display: inline-block;
    }
    .live-card-enter {
      animation: liveCardEnter 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }
    @keyframes liveCardEnter {
      from { opacity: 0; transform: translateY(-12px) scale(0.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    .live-card-leave {
      animation: liveCardLeave 0.4s ease-out forwards;
    }
    @keyframes liveCardLeave {
      from { opacity: 1; transform: scale(1); max-height: 250px; }
      to { opacity: 0; transform: scale(0.92); max-height: 0; margin-bottom: 0; padding: 0; }
    }
    .pulse-stat-label {
      font-size: 0.74rem;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-top: 0.3rem;
      font-weight: 600;
    }

    /* ACTIVITY DNA BAR */
    .pulse-dna-box {
      background: rgba(0, 0, 0, 0.35);
      border: 1px solid rgba(255, 255, 255, 0.06);
      border-radius: var(--radius-md);
      padding: 1.1rem 1.4rem;
    }
    .pulse-dna-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 0.8rem;
    }
    .pulse-dna-title {
      font-size: 0.82rem;
      font-weight: 700;
      color: var(--text);
      text-transform: uppercase;
      letter-spacing: 0.6px;
      display: flex;
      align-items: center;
      gap: 0.4rem;
    }
    .dna-bars-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 0.9rem;
    }
    .dna-bar-item {
      display: flex;
      flex-direction: column;
      gap: 0.3rem;
    }
    .dna-bar-labels {
      display: flex;
      justify-content: space-between;
      font-size: 0.76rem;
      color: var(--text-muted);
    }
    .dna-track {
      height: 8px;
      background: rgba(255, 255, 255, 0.08);
      border-radius: 4px;
      overflow: hidden;
    }
    .dna-fill {
      height: 100%;
      border-radius: 4px;
      transition: width 0.6s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .dna-fill.voice { background: linear-gradient(90deg, #10b981, #059669); }
    .dna-fill.gaming { background: linear-gradient(90deg, #06b6d4, #0284c7); }
    .dna-fill.music { background: linear-gradient(90deg, #9333ea, #c084fc); }
    .dna-fill.creating { background: linear-gradient(90deg, #ec4899, #f43f5e); }

    /* 🟢 LIVE NOW CARDS */
    .live-now-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 1.2rem;
      margin-top: 1rem;
    }
    .live-now-card {
      background: rgba(18, 20, 32, 0.85);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: var(--radius-lg);
      padding: 1.4rem;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      gap: 1rem;
      transition: all 0.25s ease;
      position: relative;
      overflow: hidden;
    }
    .live-now-card:hover {
      transform: translateY(-4px);
      border-color: rgba(16, 185, 129, 0.6);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5), 0 0 20px rgba(16, 185, 129, 0.2);
    }
    .live-now-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 0.5rem;
    }
    .live-now-type {
      font-size: 0.72rem;
      font-weight: 700;
      color: var(--emerald);
      text-transform: uppercase;
      letter-spacing: 0.6px;
      display: flex;
      align-items: center;
      gap: 0.35rem;
    }
    .live-now-title {
      font-size: 1.1rem;
      font-weight: 700;
      color: #fff;
      margin-top: 0.4rem;
      line-height: 1.3;
    }
    .live-now-community {
      font-size: 0.82rem;
      color: var(--text-muted);
      margin-top: 0.25rem;
    }
    .live-now-meta {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 0.8rem;
      color: var(--text-dim);
      padding-top: 0.8rem;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
    }

    /* ⚡ HAPPENING AROUND RAI (ACTIVITY FEED) */
    .activity-feed-container {
      background: rgba(15, 17, 26, 0.7);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: var(--radius-lg);
      padding: 1.4rem;
      margin-top: 1rem;
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
    }
    .activity-feed-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      padding: 0.7rem 1rem;
      border-radius: var(--radius-sm);
      background: rgba(0, 0, 0, 0.25);
      border: 1px solid rgba(255, 255, 255, 0.04);
      transition: background 0.2s;
    }
    .activity-feed-item:hover {
      background: rgba(147, 51, 234, 0.08);
      border-color: rgba(147, 51, 234, 0.2);
    }
    .activity-feed-left {
      display: flex;
      align-items: center;
      gap: 0.8rem;
      font-size: 0.88rem;
      color: var(--text);
    }
    .activity-feed-time {
      font-size: 0.76rem;
      color: var(--text-dim);
      white-space: nowrap;
    }

    /* 🌌 CONSTELLATION BANNER & VIEW */
    .constellation-banner {
      background: radial-gradient(circle at 70% 50%, rgba(147, 51, 234, 0.25) 0%, rgba(6, 182, 212, 0.12) 40%, rgba(10, 12, 20, 0.95) 80%);
      border: 1px solid rgba(147, 51, 234, 0.4);
      border-radius: var(--radius-lg);
      padding: 2.8rem 2.2rem;
      margin: 3.5rem 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 2rem;
      box-shadow: 0 15px 40px rgba(0, 0, 0, 0.5), 0 0 35px rgba(147, 51, 234, 0.18);
    }
    .constellation-wrapper {
      position: relative;
      width: 100%;
      height: 75vh;
      min-height: 550px;
      background: #040509;
      border: 1px solid rgba(147, 51, 234, 0.3);
      border-radius: var(--radius-lg);
      overflow: hidden;
      margin-top: 1.5rem;
    }
    #constellation-canvas {
      width: 100%;
      height: 100%;
      display: block;
      cursor: grab;
    }
    #constellation-canvas:active { cursor: grabbing; }
    .constellation-drawer {
      position: absolute;
      top: 1.5rem;
      right: 1.5rem;
      width: 320px;
      max-width: 90%;
      background: rgba(15, 17, 26, 0.95);
      border: 1px solid rgba(147, 51, 234, 0.5);
      backdrop-filter: blur(20px);
      border-radius: var(--radius-md);
      padding: 1.4rem;
      display: none;
      box-shadow: 0 20px 50px rgba(0, 0, 0, 0.8), 0 0 25px rgba(147, 51, 234, 0.3);
      z-index: 10;
    }
    .constellation-drawer.active { display: block; }

    /* CREATE A SPACE MODAL */
    .space-type-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
      gap: 0.8rem;
      margin-bottom: 1.4rem;
    }
    .space-type-card {
      background: rgba(0, 0, 0, 0.35);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: var(--radius-md);
      padding: 0.9rem 0.6rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    .space-type-card:hover {
      border-color: var(--primary);
      background: rgba(147, 51, 234, 0.15);
      transform: translateY(-2px);
    }
    .space-type-card.selected {
      border-color: var(--cyan);
      background: rgba(6, 182, 212, 0.18);
      box-shadow: 0 0 15px rgba(6, 182, 212, 0.35);
    }
    .space-type-icon { font-size: 1.6rem; margin-bottom: 0.3rem; }
    .space-type-label { font-size: 0.78rem; font-weight: 700; color: #fff; }

    /* ✦ FLOATING RAI ASSISTANT WIDGET */
    #rai-assistant-widget {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 99;
      background: rgba(15, 17, 26, 0.92);
      border: 1px solid rgba(147, 51, 234, 0.45);
      backdrop-filter: blur(20px);
      border-radius: var(--radius-full);
      padding: 0.6rem 1rem 0.6rem 1.1rem;
      display: flex;
      align-items: center;
      gap: 0.8rem;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6), 0 0 25px rgba(147, 51, 234, 0.25);
      font-size: 0.85rem;
      transition: all 0.3s ease;
    }
    #rai-assistant-widget.hidden {
      display: none;
    }
    .rai-pill-icon {
      color: var(--cyan);
      font-weight: 800;
      font-size: 1.05rem;
    }
    .rai-pill-msg {
      color: #fff;
      font-weight: 500;
    }
    .rai-pill-btn {
      background: rgba(147, 51, 234, 0.25);
      border: 1px solid rgba(147, 51, 234, 0.5);
      color: #fff;
      padding: 0.25rem 0.65rem;
      border-radius: var(--radius-full);
      font-size: 0.75rem;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
    }
    .rai-pill-btn:hover {
      background: var(--primary);
    }
    .rai-pill-close {
      background: transparent;
      border: none;
      color: var(--text-muted);
      cursor: pointer;
      font-size: 1.1rem;
      line-height: 1;
      padding: 0 0.2rem;
    }
    .rai-pill-close:hover { color: #fff; }
  
    /* ==========================================
       V4 PLATFORM FEATURES: STUDIO, BOUNTIES, PASSPORT
       ========================================== */
    /* RAIVORA WEB STUDIO & IDE */
    .studio-layout {
      display: grid;
      grid-template-columns: 240px 1fr;
      gap: 1.2rem;
      min-height: 600px;
      margin-top: 1.2rem;
    }
    .studio-sidebar {
      background: rgba(15, 17, 26, 0.85);
      border: 1px solid rgba(147, 51, 234, 0.3);
      border-radius: var(--radius-md);
      padding: 1.1rem;
      display: flex;
      flex-direction: column;
      gap: 0.6rem;
    }
    .studio-file-item {
      padding: 0.6rem 0.8rem;
      border-radius: var(--radius-sm);
      font-size: 0.82rem;
      color: var(--text-muted);
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      transition: all 0.2s;
      border: 1px solid transparent;
    }
    .studio-file-item:hover, .studio-file-item.active {
      background: rgba(147, 51, 234, 0.18);
      color: #fff;
      border-color: rgba(147, 51, 234, 0.4);
    }
    .studio-editor-box {
      background: #090b12;
      border: 1px solid rgba(147, 51, 234, 0.35);
      border-radius: var(--radius-md);
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    .studio-editor-toolbar {
      background: rgba(15, 17, 26, 0.95);
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      padding: 0.6rem 1rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
    }
    .studio-code-area {
      flex: 1;
      width: 100%;
      min-height: 480px;
      background: transparent;
      border: none;
      outline: none;
      color: #e2e8f0;
      font-family: 'JetBrains Mono', monospace;
      font-size: 0.88rem;
      line-height: 1.6;
      padding: 1.2rem;
      resize: vertical;
    }
    .studio-status-box {
      padding: 0.6rem 1rem;
      border-top: 1px solid rgba(255, 255, 255, 0.08);
      background: rgba(10, 12, 18, 0.9);
      font-size: 0.78rem;
      color: var(--text-muted);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    /* CREATOR BOUNTIES & GIG MARKETPLACE */
    .bounties-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 1.4rem;
      margin-top: 1.5rem;
    }
    .bounty-card {
      background: rgba(18, 20, 32, 0.85);
      border: 1px solid rgba(147, 51, 234, 0.25);
      border-radius: var(--radius-lg);
      padding: 1.5rem;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      gap: 1.2rem;
      transition: all 0.25s ease;
    }
    .bounty-card:hover {
      border-color: rgba(168, 85, 247, 0.55);
      transform: translateY(-4px);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5), 0 0 20px rgba(147, 51, 234, 0.2);
    }
    .bounty-reward {
      font-size: 1.15rem;
      font-weight: 800;
      color: var(--emerald);
      display: flex;
      align-items: center;
      gap: 0.35rem;
    }

    /* 3D HOLOGRAPHIC PASSPORT */
    .passport-container {
      perspective: 1000px;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 2rem 1rem;
    }
    .passport-card-3d {
      width: 100%;
      max-width: 480px;
      min-height: 290px;
      background: linear-gradient(135deg, rgba(25, 22, 45, 0.95), rgba(12, 14, 25, 0.98));
      border: 1px solid rgba(168, 85, 247, 0.5);
      box-shadow: 0 20px 50px rgba(0, 0, 0, 0.8), 0 0 35px rgba(147, 51, 234, 0.3);
      border-radius: 20px;
      padding: 1.8rem;
      position: relative;
      overflow: hidden;
      transition: transform 0.15s ease-out, box-shadow 0.2s ease;
      transform-style: preserve-3d;
    }
    .passport-card-3d::before {
      content: '';
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: radial-gradient(circle, rgba(6, 182, 212, 0.12) 0%, transparent 60%);
      pointer-events: none;
    }
    .passport-holo-sheen {
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background: linear-gradient(105deg, transparent 20%, rgba(255, 255, 255, 0.08) 45%, rgba(6, 182, 212, 0.15) 50%, rgba(147, 51, 234, 0.12) 55%, transparent 80%);
      pointer-events: none;
      opacity: 0.75;
    }
    .passport-chip {
      width: 36px;
      height: 28px;
      background: linear-gradient(135deg, #f59e0b, #d97706);
      border-radius: 5px;
      border: 1px solid rgba(255, 255, 255, 0.3);
      position: relative;
    }
    .passport-chip::after {
      content: '';
      position: absolute;
      top: 6px; left: 6px; right: 6px; bottom: 6px;
      border: 1px solid rgba(0, 0, 0, 0.35);
      border-radius: 3px;
    }

  </style>
</head>
<body>

  <!-- SUBTLE CANVAS PARTICLES -->
  <canvas id="bg-canvas"></canvas>

  <!-- DESKTOP CURSOR GLOW -->
  <div id="cursor-glow"></div>

  <!-- TOP NAVIGATION -->
  <nav class="top-nav">
    <div class="brand" onclick="navigate('/')">
      <div class="brand-icon">✦</div>
      <div class="brand-title">
        <h1>RAI ✦</h1>
        <p>The Raivora</p>
      </div>
    </div>

    <!-- MAIN NAV LINKS -->
    <ul class="nav-links" id="main-nav-links">
      <li><a class="nav-item" onclick="navigate('/discover')">Discover</a></li>
      <li><a class="nav-item" onclick="navigate('/communities')">Communities</a></li>
      <li><a class="nav-item" onclick="navigate('/projects')">Projects</a></li>
      <li><a class="nav-item" onclick="navigate('/creators')">Creators</a></li>
      <li><a class="nav-item" onclick="navigate('/gaming')">Gaming</a></li>
      <li><a class="nav-item" onclick="navigate('/music')">Music</a></li>
      <li><a class="nav-item" onclick="navigate('/studio')">Studio</a></li>
      <li><a class="nav-item" onclick="navigate('/bounties')">Bounties</a></li>

      <!-- MORE DROPDOWN -->
      <li class="nav-dropdown" id="more-dropdown">
        <a class="nav-item" onclick="toggleMoreMenu(event)">More ▾</a>
        <div class="nav-dropdown-menu">
          <a class="nav-dropdown-item" onclick="navigate('/discover/constellation')">🌌 Community Constellation</a>
          <a class="nav-dropdown-item" onclick="navigate('/passport')">🎴 Holographic Passport</a>
          <a class="nav-dropdown-item" onclick="navigate('/media')">🎬 Media & Watch Parties</a>
          <a class="nav-dropdown-item" onclick="navigate('/resources')">📚 Resources & LUTs</a>
          <a class="nav-dropdown-item" onclick="navigate('/events')">📅 Events Calendar</a>
          <a class="nav-dropdown-item" onclick="navigate('/ideas')">💡 Ideas & Roadmap</a>
          <a class="nav-dropdown-item" onclick="navigate('/brain')">🧠 Rai Community Brain</a>
          <a class="nav-dropdown-item" onclick="navigate('/labs')">🔬 Labs & Constellation</a>
          <a class="nav-dropdown-item" onclick="navigate('/rai')">✦ Rai Product Platform</a>
          <a class="nav-dropdown-item" onclick="navigate('/wiki')">📖 Community Wiki</a>
          <a class="nav-dropdown-item" onclick="navigate('/status')">🩺 Subsystem Status</a>
        </div>
      </li>
    </ul>

    <!-- GLOBAL NAVBAR SEARCH -->
    <div class="nav-search-box">
      <span class="nav-search-icon">🔍</span>
      <input type="text" class="nav-search-input" id="global-nav-search" placeholder="Search communities, creators, projects..." oninput="onGlobalSearchInput(this.value)" onfocus="onGlobalSearchFocus()" autocomplete="off">
      <span class="nav-search-badge">Ctrl K</span>

      <!-- AUTOCOMPLETE SUGGESTIONS POPUP -->
      <div class="search-suggestions-panel" id="nav-search-suggestions">
        <div style="font-size:0.8rem; color:var(--text-muted); text-align:center; padding:0.5rem;">
          Type to search verified communities, projects, creators, games...
        </div>
      </div>
    </div>

    <!-- ACTIONS / USER -->
    <div class="nav-actions" id="nav-user-container">
      <div class="rt-status-pill" id="global-rt-pill" title="Realtime SSE Stream"><span class="rt-dot live"></span> Live</div>
      <button class="btn btn-primary btn-sm" onclick="openCreateSpaceModal()"><span>✦</span> + Create a Space</button>
      <a href="https://discord.com/oauth2/authorize?client_id=1554732669072445532&permissions=8&scope=bot%20applications.commands" target="_blank" class="btn btn-outline btn-sm">
        <span>+ Add to Discord</span>
      </a>
      <button class="btn btn-discord btn-sm" onclick="openLoginModal()">
        <span>👾 Log in with Discord</span>
      </button>
      <button class="mobile-nav-toggle" onclick="toggleMobileMenu()">☰</button>
    </div>
  </nav>

  <!-- MAIN VIEW CONTAINER -->
  <main class="main-content" id="view-container">
    <!-- Dynamic views render here -->
  </main>

  <!-- MODAL CONTAINER -->
  <div class="modal-overlay" id="modal-overlay">
    <div class="modal-card" id="modal-card">
      <div class="modal-header">
        <h3 id="modal-title" style="color:#fff;">Modal Title</h3>
        <button class="modal-close" onclick="closeModal()">&times;</button>
      </div>
      <div id="modal-body"></div>
    </div>
  </div>

  <!-- ✦ FLOATING RAI ASSISTANT WIDGET -->
  <div id="rai-assistant-widget">
    <span class="rai-pill-icon">✦ RAI</span>
    <span class="rai-pill-msg" id="rai-assistant-msg">What's happening across the Raivora right now</span>
    <button class="rai-pill-btn" id="rai-assistant-action" onclick="navigate('/discover/constellation')">Explore</button>
    <button class="rai-pill-close" onclick="dismissAssistant()" title="Dismiss">&times;</button>
  </div>

  <!-- RICH 4-COLUMN FOOTER -->
  <footer class="site-footer">
    <div class="footer-content">
      <div class="footer-col">
        <div style="display:flex; align-items:center; gap:0.6rem; margin-bottom:0.8rem;">
          <div style="width:30px; height:30px; border-radius:8px; background:linear-gradient(135deg, var(--primary), #7c3aed); display:flex; align-items:center; justify-content:center; font-size:1.1rem;">✦</div>
          <span style="font-size:1.15rem; font-weight:800; color:#fff;">RAI COMMUNITY OS</span>
        </div>
        <p style="color:var(--text-muted); font-size:0.88rem; line-height:1.6; max-width:340px; margin-bottom:1.2rem;">
          The Raivora — A community discovery platform and operating system powered by Rai.
          Connecting Discord servers, creators, gaming squads, and multimedia projects in a unified world.
        </p>
        <span class="pill pill-green">🟢 SQLite WAL & Discord Bot Connected</span>
      </div>

      <div class="footer-col">
        <h4>Explore</h4>
        <ul>
          <li><a onclick="navigate('/communities')">Communities Directory</a></li>
          <li><a onclick="navigate('/projects')">Active Projects</a></li>
          <li><a onclick="navigate('/creators')">Creator Portfolios</a></li>
          <li><a onclick="navigate('/gaming')">Gaming Hub & LFG</a></li>
          <li><a onclick="navigate('/music')">Music & Audio 320kbps</a></li>
          <li><a onclick="navigate('/events')">Events Calendar</a></li>
          <li><a onclick="navigate('/resources')">Resource Library</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h4>Rai Systems</h4>
        <ul>
          <li><a onclick="navigate('/rai')">✦ Rai AI Platform</a></li>
          <li><a onclick="navigate('/rai/features')">Features Directory</a></li>
          <li><a onclick="navigate('/brain')">Community Brain</a></li>
          <li><a onclick="navigate('/labs')">Labs & Constellation</a></li>
          <li><a onclick="navigate('/status')">Subsystem Status</a></li>
          <li><a onclick="navigate('/wiki')">Knowledge Base</a></li>
          <li><a href="https://discord.com/oauth2/authorize?client_id=1554732669072445532&permissions=8&scope=bot%20applications.commands" target="_blank">Invite Rai Bot ↗</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h4>Community & Legal</h4>
        <ul>
          <li><a href="https://discord.gg/raivora" target="_blank">Official Discord Server ↗</a></li>
          <li><a onclick="navigate('/wiki')">Server Rules & Safety</a></li>
          <li><a onclick="navigate('/ideas')">Feature Roadmap</a></li>
          <li><a onclick="navigate('/saved')">My Saved Bookmarks</a></li>
          <li><a onclick="navigate('/dashboard')">Member Dashboard</a></li>
        </ul>
      </div>
    </div>

    <div class="footer-bottom">
      <div>Powered by Rai • The Raivora Core 2.6 • Persistent Community Discovery Platform</div>
      <div>Single Source of Truth with SQLite WAL & Discord Bot Gateway. Discord remains the real-time interaction hub.</div>
    </div>
  </footer>

  <!-- SPA ROUTING & INTERACTIVE ENGINE -->
  <script>
    let currentUser = null;
    let currentRoute = '/';
    let searchDebounceTimer = null;

    // ==========================================
    // 1. CANVAS PARTICLE SYSTEM
    // ==========================================
    function initCanvasParticles() {
      const canvas = document.getElementById('bg-canvas');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      let w = canvas.width = window.innerWidth;
      let h = canvas.height = window.innerHeight;

      const particles = [];
      const count = Math.min(Math.floor(w / 45), 35);

      for (let i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * w,
          y: Math.random() * h,
          vx: (Math.random() - 0.5) * 0.35,
          vy: (Math.random() - 0.5) * 0.35,
          r: Math.random() * 2 + 1,
          color: Math.random() > 0.4 ? 'rgba(168, 85, 247, ' : 'rgba(6, 182, 212, ',
          alpha: Math.random() * 0.35 + 0.15
        });
      }

      function resize() {
        w = canvas.width = window.innerWidth;
        h = canvas.height = window.innerHeight;
      }
      window.addEventListener('resize', resize);

      let animId;
      function render() {
        if (document.hidden) {
          animId = requestAnimationFrame(render);
          return;
        }
        ctx.clearRect(0, 0, w, h);
        for (let p of particles) {
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < 0) p.x = w;
          if (p.x > w) p.x = 0;
          if (p.y < 0) p.y = h;
          if (p.y > h) p.y = 0;

          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = p.color + p.alpha + ')';
          ctx.fill();
        }
        animId = requestAnimationFrame(render);
      }
      render();
    }

    // ==========================================
    // 2. DESKTOP CURSOR GLOW
    // ==========================================
    function initCursorGlow() {
      const glow = document.getElementById('cursor-glow');
      if (!glow || window.matchMedia('(pointer: coarse)').matches) return;

      document.addEventListener('mousemove', e => {
        glow.style.left = e.clientX + 'px';
        glow.style.top = e.clientY + 'px';
        glow.style.opacity = '1';
      });

      document.addEventListener('mouseleave', () => {
        glow.style.opacity = '0';
      });
    }

    // ==========================================
    // 3. AUTHENTICATION CONTROLLER
    // ==========================================
    async function initAuth() {
      try {
        const res = await fetch('/api/auth/me');
        const data = await res.json();
        if (data.success && data.data && data.data.authenticated) {
          currentUser = data.data.user;
          renderNavUser();
        }
      } catch (e) {
        console.error('Failed to init auth:', e);
      }
    }

    function renderNavUser() {
      const container = document.getElementById('nav-user-container');
      if (currentUser) {
        container.innerHTML = `
          <div class="rt-status-pill" id="global-rt-pill" title="Realtime SSE Stream"><span class="rt-dot live"></span> Live</div>
          <button class="btn btn-primary btn-sm" onclick="openCreateSpaceModal()"><span>✦</span> + Create a Space</button>
          <a href="https://discord.com/oauth2/authorize?client_id=1554732669072445532&permissions=8&scope=bot%20applications.commands" target="_blank" class="btn btn-outline btn-sm">
            <span>+ Add Bot</span>
          </a>
          <a onclick="navigate('/dashboard')" class="user-profile-btn" title="Open Personal Dashboard">
            <img class="user-avatar" src="${currentUser.avatar_url || 'https://cdn.discordapp.com/embed/avatars/0.png'}" alt="Avatar">
            <span style="font-weight: 600; font-size: 0.85rem;">${currentUser.display_name}</span>
          </a>
          <button class="btn btn-outline btn-sm" onclick="navigate('/saved')" title="Saved Bookmarks">
            🔖
          </button>
          <button class="btn btn-outline btn-sm" onclick="navigate('/notifications')" title="Notifications">
            🔔 <span id="unread-pill" class="badge-count" style="display:none;">0</span>
          </button>
          ${currentUser.is_admin ? '<button class="btn btn-primary btn-sm" onclick="navigate(\'/mission-control\')">🛡️ Mission Control</button>' : ''}
          <button class="btn btn-outline btn-sm" onclick="logout()">Logout</button>
        `;
        fetchUnreadCount();
      }
    }

    async function fetchUnreadCount() {
      try {
        const res = await fetch('/api/notifications');
        const data = await res.json();
        if (data.success && data.data) {
          const pill = document.getElementById('unread-pill');
          if (pill && data.data.unread_count > 0) {
            pill.innerText = data.data.unread_count;
            pill.style.display = 'inline-block';
          }
        }
      } catch (e) {}
    }

    function openLoginModal() {
      openModal('👾 Discord Login & Community Hub Access', `
        <div style="text-align:center; margin-bottom:1.5rem;">
          <div style="font-size:2.8rem; margin-bottom:0.4rem;">🌌</div>
          <h4 style="font-size:1.2rem; color:#fff; font-weight:800; letter-spacing:0.5px;">Sign In to Rai Community OS</h4>
          <p style="color:var(--text-muted); font-size:0.85rem; margin-top:0.3rem;">
            Connect your Discord identity to manage portfolios, join project boards, save favorites, and collaborate.
          </p>
        </div>

        <div style="display:flex; flex-direction:column; gap:1.2rem;">
          <!-- METHOD 1: OFFICIAL DISCORD OAUTH2 -->
          <div class="card" style="padding:1.25rem; border-color:var(--blurple); background:rgba(88, 101, 242, 0.08); border-radius:14px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
              <div style="font-weight:700; color:#fff; display:flex; align-items:center; gap:0.5rem; font-size:0.95rem;">
                <span style="font-size:1.2rem;">👾</span> Discord OAuth2 Authorization
              </div>
              <span class="pill pill-purple">OFFICIAL OAUTH</span>
            </div>
            <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:0.9rem; line-height:1.4;">
              Authorizes via Discord with your identity, avatars, and verified guild permissions.
            </p>
            <button class="btn btn-discord" style="width:100%; justify-content:center; padding:0.75rem; font-size:0.95rem;" onclick="startDiscordOAuth()">
              <span>👾</span> Continue with Discord
            </button>
          </div>

          <!-- METHOD 2: DIRECT DISCORD USER ID LOGIN -->
          <div class="card" style="padding:1.25rem; border-color:rgba(6, 182, 212, 0.4); background:rgba(6, 182, 212, 0.05); border-radius:14px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
              <div style="font-weight:700; color:#fff; display:flex; align-items:center; gap:0.5rem; font-size:0.95rem;">
                <span style="font-size:1.2rem;">🆔</span> Instant Discord ID Login
              </div>
              <span class="pill pill-cyan">NO SETUP NEEDED</span>
            </div>
            <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:0.8rem; line-height:1.4;">
              Enter your Discord User ID (or username) to sign in directly:
            </p>
            <form onsubmit="submitDiscordIdLogin(event)">
              <div style="display:flex; gap:0.6rem;">
                <input type="text" id="discord-login-id" class="input-field" style="flex:1;" placeholder="Discord User ID (e.g. 1457382179981099090)" value="1457382179981099090" required>
                <button type="submit" class="btn btn-primary">Sign In</button>
              </div>
            </form>
          </div>

          <div style="display:flex; justify-content:space-between; align-items:center;">
            <button class="btn btn-outline btn-sm" onclick="devQuickLogin()">⚡ Admin / Founder Login</button>
            <button class="btn btn-outline btn-sm" onclick="toggleOAuthGuide()" style="color:var(--cyan);">ℹ️ OAuth Setup Guide</button>
          </div>

          <div id="oauth-setup-guide" style="display:none; background:rgba(0,0,0,0.5); padding:1rem; border-radius:8px; font-size:0.78rem; color:var(--text-muted); line-height:1.6; border:1px solid rgba(255,255,255,0.08);">
            <strong style="color:#fff; font-size:0.85rem;">Setting up Discord OAuth2 in Developer Portal:</strong><br>
            1. Open Discord Developer Portal & select your Rai Application.<br>
            2. Under OAuth2 &rarr; Redirects, add: <code style="color:var(--pink);">http://localhost:8080/api/auth/callback</code>.<br>
            3. Set DISCORD_CLIENT_SECRET in <code>.env</code> file.
          </div>
        </div>
      `);
    }

    function toggleOAuthGuide() {
      const g = document.getElementById('oauth-setup-guide');
      if (g) g.style.display = g.style.display === 'none' ? 'block' : 'none';
    }

    async function startDiscordOAuth() {
      try {
        const res = await fetch('/api/auth/url');
        const data = await res.json();
        if (data.success && data.data.url) window.location.href = data.data.url;
        else alert('Could not start Discord OAuth: ' + (data.error?.message || 'Check configuration'));
      } catch (e) { alert('Could not start Discord OAuth flow: ' + e); }
    }

    async function submitDiscordIdLogin(e) {
      if (e) e.preventDefault();
      const inputEl = document.getElementById('discord-login-id');
      const val = inputEl ? inputEl.value.trim() : '';
      if (!val) return;
      try {
        const res = await fetch('/api/auth/discord-id-login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ user_id: val, username: 'DiscordUser_' + val.slice(-4) })
        });
        const data = await res.json();
        if (data.success) {
          closeModal();
          await initAuth();
          navigate('/dashboard');
        } else alert('Login failed: ' + (data.error?.message || 'Server error'));
      } catch (err) { alert('Login error: ' + err); }
    }

    async function devQuickLogin() {
      try {
        const res = await fetch('/api/auth/dev-login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ user_id: 1457382179981099090, username: 'ServerFounder', is_admin: true })
        });
        const data = await res.json();
        if (data.success) {
          closeModal();
          await initAuth();
          navigate('/dashboard');
        }
      } catch (e) { alert('Quick login failed: ' + e); }
    }

    async function logout() {
      await fetch('/api/auth/logout', { method: 'POST' });
      currentUser = null;
      window.location.reload();
    }

    // ==========================================
    // 4. GLOBAL SEARCH & AUTOCOMPLETE SYSTEM
    // ==========================================
    function onGlobalSearchFocus() {
      const panel = document.getElementById('nav-search-suggestions');
      const val = document.getElementById('global-nav-search').value.trim();
      if (panel) {
        panel.classList.add('active');
        if (val) executeGlobalSearch(val);
      }
    }

    function onGlobalSearchInput(val) {
      clearTimeout(searchDebounceTimer);
      searchDebounceTimer = setTimeout(() => {
        executeGlobalSearch(val.trim());
      }, 240);
    }

    document.addEventListener('click', e => {
      const searchBox = document.querySelector('.nav-search-box');
      const panel = document.getElementById('nav-search-suggestions');
      if (panel && searchBox && !searchBox.contains(e.target)) {
        panel.classList.remove('active');
      }
      const moreDropdown = document.getElementById('more-dropdown');
      if (moreDropdown && !moreDropdown.contains(e.target)) {
        moreDropdown.classList.remove('open');
      }
    });

    document.addEventListener('keydown', e => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        const inp = document.getElementById('global-nav-search');
        if (inp) {
          inp.focus();
          inp.select();
        }
      }
      if (e.key === 'Escape') {
        const panel = document.getElementById('nav-search-suggestions');
        if (panel) panel.classList.remove('active');
        closeModal();
      }
    });

    async function executeGlobalSearch(q) {
      const panel = document.getElementById('nav-search-suggestions');
      if (!panel) return;
      if (!q) {
        panel.innerHTML = `
          <div style="padding:0.6rem; color:var(--text-muted); font-size:0.82rem; text-align:center;">
            Explore communities, creators, projects, gaming squads, and Rai systems.
          </div>
        `;
        return;
      }
      panel.innerHTML = `<div style="padding:0.8rem; color:var(--text-muted); font-size:0.82rem; text-align:center;">Searching Rai Community OS...</div>`;

      try {
        const res = await fetch('/api/brain/search?q=' + encodeURIComponent(q));
        const data = await res.json();
        if (data.success && data.data && data.data.total_matches > 0) {
          const cats = data.data.categories || {};
          let html = `<div style="font-size:0.75rem; color:var(--text-dim); padding:0.2rem 0.5rem 0.5rem 0.5rem; border-bottom:1px solid rgba(255,255,255,0.06);">Found ${data.data.total_matches} match(es) for "<strong>${q}</strong>"</div>`;

          const sections = [
            { key: 'communities', title: '👥 Communities', icon: '👥' },
            { key: 'projects', title: '🚀 Projects', icon: '🚀' },
            { key: 'creators', title: '🎨 Creators & Portfolios', icon: '🎨' },
            { key: 'gaming', title: '🎮 Gaming Squads', icon: '🎮' },
            { key: 'resources', title: '📚 Resources', icon: '📚' },
            { key: 'events', title: '📅 Events', icon: '📅' },
            { key: 'ideas', title: '💡 Ideas & Roadmap', icon: '💡' },
            { key: 'rai_features', title: '🧠 Rai Bot Systems', icon: '✦' }
          ];

          for (let s of sections) {
            const items = cats[s.key] || [];
            if (items.length > 0) {
              html += `<div class="search-section-header">${s.title}</div>`;
              for (let item of items.slice(0, 3)) {
                html += `
                  <div class="search-item" onclick="navigate('${item.link}'); document.getElementById('nav-search-suggestions').classList.remove('active');">
                    <div class="search-item-info">
                      <div class="search-item-title">${item.title}</div>
                      <div class="search-item-snippet">${item.snippet || ''}</div>
                    </div>
                    <span class="pill pill-purple" style="font-size:0.65rem;">${item.type}</span>
                  </div>
                `;
              }
            }
          }
          panel.innerHTML = html;
        } else {
          panel.innerHTML = `
            <div style="padding:1rem; text-align:center; color:var(--text-muted); font-size:0.85rem;">
              No results discovered for "${q}". Try another keyword or browse categories below.
            </div>
          `;
        }
      } catch (e) {
        panel.innerHTML = `<div style="padding:0.8rem; color:var(--danger); font-size:0.82rem;">Search request error: ${e}</div>`;
      }
    }

    function toggleMoreMenu(e) {
      if (e) e.stopPropagation();
      const dd = document.getElementById('more-dropdown');
      if (dd) dd.classList.toggle('open');
    }

    function toggleMobileMenu() {
      const links = document.getElementById('main-nav-links');
      if (links) {
        links.style.display = links.style.display === 'flex' ? 'none' : 'flex';
        links.style.flexDirection = 'column';
        links.style.position = 'absolute';
        links.style.top = '100%';
        links.style.left = '0';
        links.style.width = '100%';
        links.style.background = 'rgba(10, 11, 18, 0.98)';
        links.style.padding = '1rem';
        links.style.borderBottom = '1px solid rgba(255,255,255,0.1)';
      }
    }

    // ==========================================
    // 5. BOOKMARKS / SAVED ITEMS HELPER
    // ==========================================
    async function toggleSaveItem(itemType, itemId, title, category) {
      if (!currentUser) {
        alert('Please sign in with Discord to bookmark items.');
        openLoginModal();
        return;
      }
      try {
        const res = await fetch('/api/saved/toggle', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ item_type: itemType, item_id: String(itemId), title, category })
        });
        const data = await res.json();
        if (data.success) {
          alert(data.data.saved ? `Saved "${title}" to your bookmarks!` : `Removed "${title}" from your bookmarks.`);
          if (currentRoute === '/saved') renderSaved(document.getElementById('view-container'));
        }
      } catch (e) {
        alert('Could not update bookmark: ' + e);
      }
    }

    // ==========================================
    // 6. MODAL UTILITIES
    // ==========================================
    function openModal(title, contentHtml) {
      document.getElementById('modal-title').innerText = title;
      document.getElementById('modal-body').innerHTML = contentHtml;
      document.getElementById('modal-overlay').classList.add('active');
    }
    function closeModal() {
      document.getElementById('modal-overlay').classList.remove('active');
    }

    // ==========================================
    // 7. CLIENT ROUTER DISPATCHER
    // ==========================================
    function navigate(route) {
      currentRoute = route;
      window.location.hash = route;

      // Update active nav indicators
      document.querySelectorAll('.nav-item').forEach(el => {
        el.classList.remove('active');
        const oc = el.getAttribute('onclick') || '';
        if (oc.includes(route) && route !== '/') el.classList.add('active');
      });

      const container = document.getElementById('view-container');
      window.scrollTo(0, 0);

      // Route Dispatching
      if (route === '/' || route === '') renderHome(container);
      else if (route === '/discover/constellation') renderConstellation(container);
      else if (route === '/studio') renderStudio(container);
      else if (route === '/bounties') renderBounties(container);
      else if (route === '/passport' || route.startsWith('/passport/')) renderPassport(container, route.split('/')[2]);
      else if (route === '/discover') renderDiscover(container);
      else if (route === '/communities') renderCommunities(container);
      else if (route.startsWith('/communities/')) renderCommunityDetail(container, route.split('/')[2]);
      else if (route === '/projects') renderProjects(container);
      else if (route.startsWith('/projects/')) renderProjectDetail(container, route.split('/')[2]);
      else if (route === '/creators') renderCreators(container);
      else if (route === '/gaming') renderGaming(container);
      else if (route === '/music') renderMusic(container);
      else if (route === '/media') renderMedia(container);
      else if (route === '/resources') renderResources(container);
      else if (route === '/events') renderEvents(container);
      else if (route === '/ideas') renderIdeas(container);
      else if (route === '/rai') renderRaiProduct(container);
      else if (route === '/rai/features') renderRaiFeatures(container);
      else if (route === '/brain') renderBrain(container);
      else if (route === '/labs') renderLabs(container);
      else if (route === '/status') renderStatus(container);
      else if (route === '/wiki') renderWiki(container);
      else if (route === '/saved') renderSaved(container);
      else if (route === '/dashboard' || route === '/workspace') renderDashboard(container);
      else if (route === '/notifications') renderNotifications(container);
      else if (route === '/mission-control') renderMissionControl(container);
      else if (route.startsWith('/login')) { renderHome(container); openLoginModal(); }
      else renderHome(container);
    }

    // ==========================================
    // 8. HOMEPAGE VIEW (THE RAIVORA V3 LIVE UNIVERSE)
    // ==========================================
    async function renderHome(container) {
      container.innerHTML = `
        <!-- 1. HERO SECTION -->
        <section class="discovery-hero">
          <div class="hero-badge">✦ THE RAIVORA • LIVE COMMUNITY UNIVERSE ✦</div>
          <h2 class="hero-title">DISCOVER THE RAIVORA</h2>
          <p class="hero-subtitle">
            Communities, creators, projects and experiences powered by Rai.
          </p>

          <!-- HERO LARGE SEARCH BOX WITH SMART INTENT -->
          <div class="hero-search-wrapper">
            <form onsubmit="onHeroSearchSubmit(event)" class="hero-search-box">
              <span style="font-size:1.2rem; color:var(--cyan); margin-right:0.75rem;">🔍</span>
              <input type="text" id="hero-search-input" class="hero-search-input" placeholder="Search communities, creators, projects, games, music..." autocomplete="off">
              <button type="submit" class="btn btn-primary" style="border-radius:var(--radius-full); padding:0.6rem 1.4rem;">
                Explore
              </button>
            </form>
          </div>

          <div class="hero-actions">
            <button class="btn btn-primary btn-lg" onclick="navigate('/communities')">
              <span>✦</span> Explore Communities
            </button>
            <button class="btn btn-outline btn-lg" onclick="openCreateSpaceModal()">
              <span>+</span> Create a Space
            </button>
            <a href="https://discord.com/oauth2/authorize?client_id=1554732669072445532&permissions=8&scope=bot%20applications.commands" target="_blank" class="btn btn-discord btn-lg">
              <span>👾</span> Add to Discord
            </a>
          </div>
        </section>

        <!-- 2. CATEGORIES -->
        <div class="category-pills-bar">
          <a class="cat-pill" onclick="navigate('/gaming')">🎮 Gaming <span class="cat-pill-count" id="count-gaming">LFG</span></a>
          <a class="cat-pill" onclick="navigate('/music')">🎵 Music <span class="cat-pill-count" id="count-music">Hi-Fi</span></a>
          <a class="cat-pill" onclick="navigate('/creators')">🎨 Creators <span class="cat-pill-count" id="count-creators">Portfolios</span></a>
          <a class="cat-pill" onclick="navigate('/projects')">🚀 Projects <span class="cat-pill-count" id="count-projects">Active</span></a>
          <a class="cat-pill" onclick="navigate('/media')">🎬 Media <span class="cat-pill-count" id="count-media">Watch</span></a>
          <a class="cat-pill" onclick="navigate('/events')">📅 Events <span class="cat-pill-count" id="count-events">Events</span></a>
          <a class="cat-pill" onclick="navigate('/resources')">📚 Resources <span class="cat-pill-count" id="count-resources">LUTs</span></a>
          <a class="cat-pill" onclick="navigate('/discover/constellation')">🌌 Constellation <span class="cat-pill-count">Galaxy</span></a>
          <a class="cat-pill" onclick="navigate('/brain')">🧠 AI Brain <span class="cat-pill-count">Q&A</span></a>
          <a class="cat-pill" onclick="navigate('/status')">🩺 Status <span class="cat-pill-count">Live</span></a>
        </div>

        <!-- 3. ✦ RAI PULSE -->
        <section class="pulse-section" id="pulse-section">
          <div class="pulse-header">
            <div class="pulse-title-wrap">
              <h3>✦ RAI PULSE</h3>
              <p>What's happening across the Raivora right now. <span id="pulse-last-updated" style="color:var(--text-muted); font-size:0.8rem; margin-left:0.5rem;">Updated just now</span></p>
            </div>
            <div class="pulse-badge-live">
              <span class="live-dot"></span>
              <span>LIVE</span>
            </div>
          </div>
          <div class="pulse-grid">
            <div class="pulse-stat-card">
              <span class="pulse-stat-icon">👥</span>
              <div class="pulse-stat-val" id="pulse-members">—</div>
              <div class="pulse-stat-label">Members Online</div>
            </div>
            <div class="pulse-stat-card">
              <span class="pulse-stat-icon">🎙️</span>
              <div class="pulse-stat-val" id="pulse-voice">—</div>
              <div class="pulse-stat-label">In Voice</div>
            </div>
            <div class="pulse-stat-card">
              <span class="pulse-stat-icon">🎵</span>
              <div class="pulse-stat-val" id="pulse-listening">—</div>
              <div class="pulse-stat-label">Listening</div>
            </div>
            <div class="pulse-stat-card">
              <span class="pulse-stat-icon">🎮</span>
              <div class="pulse-stat-val" id="pulse-gaming">—</div>
              <div class="pulse-stat-label">Gaming</div>
            </div>
            <div class="pulse-stat-card">
              <span class="pulse-stat-icon">🎨</span>
              <div class="pulse-stat-val" id="pulse-creating">—</div>
              <div class="pulse-stat-label">Creating</div>
            </div>
            <div class="pulse-stat-card">
              <span class="pulse-stat-icon">🚀</span>
              <div class="pulse-stat-val" id="pulse-projects">—</div>
              <div class="pulse-stat-label">Active Projects</div>
            </div>
            <div class="pulse-stat-card">
              <span class="pulse-stat-icon">📅</span>
              <div class="pulse-stat-val" id="pulse-events">—</div>
              <div class="pulse-stat-label">Live Events</div>
            </div>
          </div>

          <!-- ACTIVITY DNA -->
          <div class="pulse-dna-box" id="pulse-dna-box">
            <div class="pulse-dna-header">
              <div class="pulse-dna-title">
                <span>⚡</span> Community Activity DNA
              </div>
              <span style="font-size:0.75rem; color:var(--text-dim);" id="pulse-dna-status">Real aggregate distribution</span>
            </div>
            <div class="dna-bars-grid" id="pulse-dna-grid">
              <div class="dna-bar-item">
                <div class="dna-bar-labels">
                  <span>🎙️ Voice</span>
                  <span id="dna-pct-voice">—</span>
                </div>
                <div class="dna-track"><div class="dna-fill voice" id="dna-fill-voice" style="width:0%;"></div></div>
              </div>
              <div class="dna-bar-item">
                <div class="dna-bar-labels">
                  <span>🎮 Gaming</span>
                  <span id="dna-pct-gaming">—</span>
                </div>
                <div class="dna-track"><div class="dna-fill gaming" id="dna-fill-gaming" style="width:0%;"></div></div>
              </div>
              <div class="dna-bar-item">
                <div class="dna-bar-labels">
                  <span>🎵 Music</span>
                  <span id="dna-pct-music">—</span>
                </div>
                <div class="dna-track"><div class="dna-fill music" id="dna-fill-music" style="width:0%;"></div></div>
              </div>
              <div class="dna-bar-item">
                <div class="dna-bar-labels">
                  <span>🎨 Creating</span>
                  <span id="dna-pct-creating">—</span>
                </div>
                <div class="dna-track"><div class="dna-fill creating" id="dna-fill-creating" style="width:0%;"></div></div>
              </div>
            </div>
          </div>
        </section>

        <!-- 4. 🟢 LIVE NOW -->
        <div class="section-title">
          <div class="title-group">
            <span class="title-text">🟢 LIVE NOW</span>
            <span class="pulse-badge-live" style="font-size:0.7rem; padding:0.25rem 0.65rem;"><span class="live-dot"></span> REAL SESSIONS</span>
          </div>
          <button class="btn btn-primary btn-sm" onclick="openCreateSpaceModal()">+ Start Session</button>
        </div>
        <p style="color:var(--text-muted); font-size:0.88rem; margin-top:-0.5rem; margin-bottom:1.2rem;">Happening across the Raivora right now.</p>
        <div class="live-now-grid" id="live-now-grid">
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
        </div>

        <!-- 5. ⚡ HAPPENING AROUND RAI -->
        <div class="section-title" style="margin-top:3rem;">
          <div class="title-group">
            <span class="title-text">⚡ HAPPENING AROUND RAI</span>
            <span class="pill pill-purple">REALTIME ACTIVITY FEED</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="loadActivityFeed()">Refresh Feed ⟳</button>
        </div>
        <div class="activity-feed-container" id="activity-feed-list">
          <div style="padding:1rem; text-align:center; color:var(--text-muted); font-size:0.85rem;">Connecting to Raivora event stream...</div>
        </div>

        <!-- 6. 🔥 TRENDING NOW -->
        <div class="section-title" style="margin-top:3rem;">
          <div class="title-group">
            <span class="title-text">🔥 Trending Now</span>
            <span class="pill pill-cyan">ACTIVE COMMUNITIES</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="navigate('/communities')">View All Communities &rarr;</button>
        </div>
        <div class="discovery-grid" id="trending-grid">
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
        </div>

        <!-- 7. 🌌 DISCOVER THE CONSTELLATION -->
        <div class="constellation-banner">
          <div style="max-width:620px;">
            <div class="spotlight-badge" style="background:rgba(6, 182, 212, 0.15); border-color:var(--cyan); color:var(--cyan); margin-bottom:0.8rem;">🌌 INTERACTIVE GALAXY</div>
            <h3 style="font-size:1.85rem; font-weight:800; color:#fff; margin-bottom:0.6rem;">Discover the Community Constellation</h3>
            <p style="color:var(--text-muted); font-size:0.95rem; line-height:1.6; margin-bottom:1.4rem;">
              Explore the Raivora through an interactive node universe connecting communities, creators, projects, gaming squads, and live voice spaces.
            </p>
            <div style="display:flex; gap:0.8rem; flex-wrap:wrap;">
              <button class="btn btn-primary btn-lg" onclick="navigate('/discover/constellation')">
                <span>🌌</span> Open Community Constellation &rarr;
              </button>
              <button class="btn btn-outline btn-lg" onclick="openCreateSpaceModal()">
                <span>✦</span> Create a Space
              </button>
            </div>
          </div>
          <div style="font-size:5rem; text-shadow:0 0 35px var(--primary-glow); display:none;" id="spotlight-icon">🌌</div>
        </div>

        <!-- 8. 👥 POPULAR COMMUNITIES -->
        <div class="section-title">
          <div class="title-group">
            <span class="title-text">👥 Popular Communities</span>
            <span class="pill pill-cyan">DISCORD HUBS</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="navigate('/communities')">Browse Directory &rarr;</button>
        </div>
        <div class="discovery-grid" id="home-communities-grid">
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
        </div>

        <!-- 9. 🎨 CREATORS THIS WEEK -->
        <div class="section-title" style="margin-top:3rem;">
          <div class="title-group">
            <span class="title-text">🎨 CREATORS THIS WEEK</span>
            <span class="pill pill-purple">VERIFIED PORTFOLIOS</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="navigate('/creators')">Meet All Creators &rarr;</button>
        </div>
        <div class="discovery-grid" id="home-creators-grid">
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
        </div>

        <!-- 10. 🎮 LOOKING FOR GROUP -->
        <div class="section-title" style="margin-top:3rem;">
          <div class="title-group">
            <span class="title-text">🎮 LOOKING FOR GROUP</span>
            <span class="pill pill-green">LIVE LFG SQUADS</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="navigate('/gaming')">Join Matchmaker &rarr;</button>
        </div>
        <div class="discovery-grid" id="home-gaming-grid">
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
        </div>

        <!-- 11. 🚀 ACTIVE PROJECTS -->
        <div class="section-title" style="margin-top:3rem;">
          <div class="title-group">
            <span class="title-text">🚀 ACTIVE PROJECTS</span>
            <span class="pill pill-pink">COLLABORATIVE SPACES</span>
          </div>
          <button class="btn btn-primary btn-sm" onclick="openCreateProjectModal()">+ Launch Project</button>
        </div>
        <div class="discovery-grid" id="home-projects-grid">
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
        </div>

        <!-- 12. 🎵 MUSIC -->
        <div class="section-title" style="margin-top:3rem;">
          <div class="title-group">
            <span class="title-text">🎵 PLAYING NOW & LISTENING ROOMS</span>
            <span class="pill pill-purple">320kbps OPUS</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="navigate('/music')">Music Hub &rarr;</button>
        </div>

        <div class="player-widget">
          <div class="player-header">
            <div style="display:flex; align-items:center; gap:0.6rem;">
              <span class="pill pill-green" id="home-music-vc">🟢 Music Room Active • 320kbps Audio</span>
              <span class="pill pill-cyan">Lossless Audio</span>
            </div>
            <div style="display:flex; align-items:center; gap:0.5rem; font-size:0.8rem; color:var(--text-muted);">
              <span>Equalizer</span>
              <div class="eq-bars" id="music-eq-bars">
                <div class="eq-bar paused"></div>
                <div class="eq-bar paused"></div>
                <div class="eq-bar paused"></div>
                <div class="eq-bar paused"></div>
              </div>
            </div>
          </div>
          <div class="player-main">
            <div class="player-disc paused" id="home-player-disc">💿</div>
            <div class="player-info">
              <div class="player-title" id="home-track-title">Lossless Stream</div>
              <div class="player-artist" id="home-track-artist">The Raivora Audio Service • Hi-Fi</div>
            </div>
            <div class="player-controls">
              <button class="ctrl-icon-btn" onclick="nextDemoTrack()" title="Previous Track">⏮</button>
              <button class="play-btn" id="home-play-btn" onclick="toggleAudioPreview()" title="Play / Pause">▶</button>
              <button class="ctrl-icon-btn" onclick="nextDemoTrack()" title="Next Track">⏭</button>
            </div>
          </div>
        </div>

        <!-- 13. 📅 EVENTS -->
        <div class="section-title" style="margin-top:3rem;">
          <div class="title-group">
            <span class="title-text">📅 Community Events</span>
            <span class="pill pill-pink">SCHEDULED</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="navigate('/events')">All Events &rarr;</button>
        </div>
        <div class="discovery-grid" id="home-events-grid">
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
        </div>

        <!-- 14. ✦ RAI PLATFORM HIGHLIGHT -->
        <div style="margin-top:4.5rem; padding:3.5rem 2.2rem; background:linear-gradient(135deg, rgba(20,24,38,0.85), rgba(12,14,24,0.95)); border:1px solid rgba(147,51,234,0.3); border-radius:var(--radius-lg); text-align:center;">
          <div style="font-size:2.5rem; margin-bottom:0.5rem;">✦</div>
          <h3 style="font-size:2.2rem; font-weight:800; color:#fff; margin-bottom:0.6rem;">THE RAIVORA — A LIVE COMMUNITY UNIVERSE</h3>
          <p style="color:var(--text-muted); max-width:680px; margin:0 auto 1.8rem auto; font-size:1.05rem; line-height:1.6;">
            A unified operating system engineered for Discord servers, content creators, competitive gaming teams, and collaborative ventures. Real activity, real communities, real data.
          </p>
          <div style="display:flex; justify-content:center; gap:1rem; flex-wrap:wrap;">
            <button class="btn btn-primary" onclick="openCreateSpaceModal()">+ Create a Space</button>
            <button class="btn btn-outline" onclick="navigate('/discover/constellation')">🌌 View Constellation</button>
            <button class="btn btn-outline" onclick="navigate('/status')">🩺 System Status</button>
          </div>
        </div>
      `;

      loadHomeData();
    }

    function onHeroSearchSubmit(e) {
      if (e) e.preventDefault();
      const val = document.getElementById('hero-search-input').value.trim();
      if (!val) return;
      navigate('/discover');
      setTimeout(() => {
        const inp = document.getElementById('discover-input');
        if (inp) {
          inp.value = val;
          onDiscoverSearch(val);
        }
      }, 60);
    }

    function formatTimeAgo(ts) {
      if (!ts) return 'just now';
      const d = new Date(ts);
      const diffMs = Date.now() - d.getTime();
      const secs = Math.floor(diffMs / 1000);
      if (secs < 5) return 'just now';
      if (secs < 60) return `${secs}s ago`;
      const mins = Math.floor(secs / 60);
      if (mins < 60) return `${mins}m ago`;
      const hrs = Math.floor(mins / 60);
      if (hrs < 24) return `${hrs}h ago`;
      return `${Math.floor(hrs / 24)}d ago`;
    }

    function updatePulseUI(data) {
      if (!data) return;
      const setMetric = (id, val) => {
        const el = document.getElementById(id);
        if (!el) return;
        const textVal = (val === null || val === undefined) ? '—' : Number(val).toLocaleString();
        if (el.innerText !== textVal) {
          el.innerText = textVal;
          el.classList.add('pulse-val-updated');
          setTimeout(() => el.classList.remove('pulse-val-updated'), 700);
        }
        el.title = (val === null || val === undefined) ? 'Data temporarily unavailable' : '';
      };

      setMetric('pulse-members', data.members_online);
      setMetric('pulse-voice', data.users_in_voice !== undefined ? data.users_in_voice : data.in_voice);
      setMetric('pulse-listening', data.music_listeners !== undefined ? data.music_listeners : data.listening);
      setMetric('pulse-gaming', data.gaming_players !== undefined ? data.gaming_players : data.gaming);
      setMetric('pulse-creating', data.creators_active !== undefined ? data.creators_active : data.creating);
      setMetric('pulse-projects', data.active_projects);
      setMetric('pulse-events', data.live_events);

      // DNA Bars
      const dna = data.dna || {};
      const setDnaBar = (cat, pct) => {
        const fillEl = document.getElementById(`dna-fill-${cat}`);
        const pctEl = document.getElementById(`dna-pct-${cat}`);
        if (fillEl && pct !== null && pct !== undefined) fillEl.style.width = Math.min(100, Math.max(0, pct)) + '%';
        if (pctEl && pct !== null && pct !== undefined) pctEl.innerText = pct > 0 ? pct + '%' : '—';
      };
      setDnaBar('voice', dna.voice);
      setDnaBar('gaming', dna.gaming);
      setDnaBar('music', dna.music);
      setDnaBar('creating', dna.creating);

      // Update timestamp
      const updatedEl = document.getElementById('pulse-last-updated');
      if (updatedEl && data.updated_at) {
        updatedEl.innerText = `Updated ${formatTimeAgo(data.updated_at)}`;
      }
    }

    function updateLiveNowUI(sessions) {
      const grid = document.getElementById('live-now-grid');
      if (!grid) return;
      if (!sessions || sessions.length === 0) {
        grid.innerHTML = `
          <div class="state-box" style="grid-column:1/-1; padding:2rem 1.5rem;">
            <div class="state-icon">🟢</div>
            <div class="state-title">No Active Live Sessions Right Now</div>
            <div class="state-desc">Start a Gaming Squad, Creator Workspace, Listening Party, or Community Room with Discord automation.</div>
            <button class="btn btn-primary btn-sm" onclick="openCreateSpaceModal()">+ Start a Session</button>
          </div>
        `;
        return;
      }

      grid.innerHTML = sessions.map(s => `
        <div class="live-now-card">
          <div>
            <div class="live-now-top">
              <span class="live-now-type">
                <span class="live-dot"></span> ${s.type || 'SESSION'}
              </span>
              <span class="tag-badge" style="font-size:0.7rem;">👥 ${s.participants} live</span>
            </div>
            <div class="live-now-title">${s.title}</div>
            <div class="live-now-community">📍 ${s.community || 'Rai Community OS'}</div>
          </div>
          <div>
            <div class="live-now-meta">
              <span>Started: ${s.started_at ? s.started_at.split('T')[0] : 'Live now'}</span>
              <span class="pill pill-green" style="font-size:0.68rem;">ACTIVE</span>
            </div>
            <div class="card-bottom-actions" style="margin-top:0.8rem;">
              <button class="btn btn-primary btn-sm" style="flex:1;" onclick="navigate('${s.destination || '/communities'}')">Join Space ↗</button>
              <a href="https://discord.gg/raivora" target="_blank" class="btn btn-discord btn-sm" style="flex:1;">Join Discord</a>
            </div>
          </div>
        </div>
      `).join('');
    }

    async function loadActivityFeed() {
      const listEl = document.getElementById('activity-feed-list');
      if (!listEl) return;
      try {
        const res = await fetch('/api/activity');
        const json = await res.json();
        if (json.success && json.data && json.data.events) {
          updateActivityUI(json.data.events);
        }
      } catch (e) {
        console.warn('Failed to load activity feed:', e);
      }
    }

    function updateActivityUI(events) {
      const listEl = document.getElementById('activity-feed-list');
      if (!listEl) return;
      if (!events || events.length === 0) {
        listEl.innerHTML = `<div style="padding:1rem; text-align:center; color:var(--text-muted); font-size:0.85rem;">No recent community activity recorded yet.</div>`;
        return;
      }

      const formatTimeAgo = (ts) => {
        if (!ts) return 'Just now';
        const d = new Date(ts);
        const diffMs = Date.now() - d.getTime();
        const mins = Math.floor(diffMs / 60000);
        if (mins < 1) return 'Just now';
        if (mins < 60) return `${mins}m ago`;
        const hrs = Math.floor(mins / 60);
        if (hrs < 24) return `${hrs}h ago`;
        return `${Math.floor(hrs / 24)}d ago`;
      };

      listEl.innerHTML = events.slice(0, 8).map(ev => `
        <div class="activity-feed-item">
          <div class="activity-feed-left">
            <span class="pill ${ev.badge_color || 'pill-purple'}" style="font-size:0.68rem; padding:0.2rem 0.5rem;">
              ${ev.icon || '⚡'} ${ev.event_type}
            </span>
            <span>${ev.title}</span>
          </div>
          <div class="activity-feed-time">${formatTimeAgo(ev.created_at)}</div>
        </div>
      `).join('');
    }

    async function loadHomeData() {
      // 1. Fetch ✦ RAI PULSE (Real Aggregate Telemetry)
      try {
        const pRes = await fetch('/api/pulse');
        const pJson = await pRes.json();
        if (pJson.success && pJson.data) {
          updatePulseUI(pJson.data);
        }
      } catch (e) {
        console.warn('Failed to load pulse metrics:', e);
      }

      // 2. Fetch 🟢 LIVE NOW SESSIONS
      try {
        const lRes = await fetch('/api/live');
        const lJson = await lRes.json();
        if (lJson.success && lJson.data) {
          updateLiveNowUI(lJson.data.sessions || []);
        }
      } catch (e) {
        console.warn('Failed to load live sessions:', e);
      }

      // 3. Fetch ⚡ HAPPENING AROUND RAI
      await loadActivityFeed();

      // 4. Fetch Communities (Trending + Popular)
      try {
        const cRes = await fetch('/api/communities');
        const cData = await cRes.json();
        if (cData.success && cData.data) {
          const comms = cData.data;
          const trGrid = document.getElementById('trending-grid');
          const hcGrid = document.getElementById('home-communities-grid');

          if (trGrid) {
            trGrid.innerHTML = comms.slice(0, 3).map(c => `
              <div class="discovery-card">
                <div>
                  <div class="card-top">
                    <div class="card-media-icon">${c.icon && c.icon.length > 5 ? `<img src="${c.icon}">` : (c.icon || '✦')}</div>
                    <div class="card-heading">
                      <div class="card-name">${c.name} ${c.verified ? '✓' : ''}</div>
                      <div class="card-subtitle">${c.type}</div>
                    </div>
                  </div>
                  <div class="card-desc">${c.description}</div>
                  <div class="card-tags">
                    ${c.tags.slice(0, 3).map(t => `<span class="tag-badge">${t}</span>`).join('')}
                  </div>
                </div>
                <div>
                  <div class="card-metrics">
                    <span>👥 ${c.members} members</span>
                    <span style="color:var(--cyan);">${c.activity_status}</span>
                  </div>
                  <div class="card-bottom-actions">
                    <button class="btn btn-outline btn-sm" style="flex:1;" onclick="navigate('/communities/${c.id}')">View</button>
                    <a href="${c.invite_url}" target="_blank" class="btn btn-discord btn-sm" style="flex:1;">Join Discord</a>
                    <button class="btn btn-outline btn-sm" onclick="toggleSaveItem('community', '${c.id}', '${c.name}', '${c.category}')">🔖</button>
                  </div>
                </div>
              </div>
            `).join('');
          }

          if (hcGrid) {
            hcGrid.innerHTML = comms.map(c => `
              <div class="discovery-card">
                <div>
                  <div class="card-top">
                    <div class="card-media-icon">${c.icon && c.icon.length > 5 ? `<img src="${c.icon}">` : (c.icon || '✦')}</div>
                    <div class="card-heading">
                      <div class="card-name">${c.name}</div>
                      <div class="card-subtitle">${c.badge || c.type}</div>
                    </div>
                  </div>
                  <div class="card-desc">${c.description}</div>
                  <div class="card-tags">
                    ${c.tags.map(t => `<span class="tag-badge">${t}</span>`).join('')}
                  </div>
                </div>
                <div>
                  <div class="card-metrics">
                    <span>👥 ${c.members} members</span>
                    <span>🚀 ${c.active_projects} projects</span>
                  </div>
                  <div class="card-bottom-actions">
                    <button class="btn btn-outline btn-sm" style="flex:1;" onclick="navigate('/communities/${c.id}')">Explore Hub</button>
                    <a href="${c.invite_url}" target="_blank" class="btn btn-discord btn-sm" style="flex:1;">Join Server</a>
                  </div>
                </div>
              </div>
            `).join('');
          }
        }
      } catch (e) {}

      // 5. Fetch 🎨 CREATORS THIS WEEK
      try {
        const crRes = await fetch('/api/creators');
        const crData = await crRes.json();
        const crGrid = document.getElementById('home-creators-grid');
        if (crGrid && crData.success && crData.data && crData.data.length > 0) {
          crGrid.innerHTML = crData.data.slice(0, 3).map(c => `
            <div class="discovery-card">
              <div>
                <div class="card-top">
                  <div class="card-media-icon">🎨</div>
                  <div class="card-heading">
                    <div class="card-name">${c.title}</div>
                    <div class="card-subtitle">${c.category.toUpperCase()}</div>
                  </div>
                </div>
                <div class="card-desc">${c.description || 'Verified showcase piece on Rai Community OS.'}</div>
                <div class="card-tags">
                  <span class="tag-badge">Tools: ${c.tools_used || 'Software'}</span>
                </div>
              </div>
              <div class="card-bottom-actions">
                <button class="btn btn-outline btn-sm" style="flex:1;" onclick="openPortfolioModal(${JSON.stringify(c).replace(/"/g, '&quot;')})">View Portfolio</button>
                <button class="btn btn-outline btn-sm" onclick="toggleSaveItem('creator', '${c.id}', '${c.title}', '${c.category}')">🔖</button>
              </div>
            </div>
          `).join('');
        } else if (crGrid) {
          crGrid.innerHTML = `
            <div class="state-box">
              <div class="state-icon">🎨</div>
              <div class="state-title">No Creator Showcases Yet</div>
              <div class="state-desc">Publish your editing, VFX, 3D, or audio work to be featured in the community showcase.</div>
              <button class="btn btn-primary" onclick="openCreatePortfolioModal()">+ Add Portfolio Item</button>
            </div>
          `;
        }
      } catch (e) {}

      // 6. Fetch 🎮 GAMING LFG
      try {
        const gRes = await fetch('/api/gaming/lfg');
        const gData = await gRes.json();
        const gGrid = document.getElementById('home-gaming-grid');
        if (gGrid && gData.success && gData.data && gData.data.length > 0) {
          gGrid.innerHTML = gData.data.slice(0, 3).map(g => `
            <div class="discovery-card">
              <div>
                <div class="card-top">
                  <div class="card-media-icon">🎮</div>
                  <div class="card-heading">
                    <div class="card-name">${g.game_name}</div>
                    <div class="card-subtitle">${g.mode || 'Ranked Squad'}</div>
                  </div>
                </div>
                <div class="card-desc">${g.description || 'Looking for team members for competitive and casual matches.'}</div>
                <div class="card-tags">
                  <span class="pill pill-green">ACTIVE</span>
                  <span class="tag-badge">${g.current_players}/${g.max_players} Players</span>
                </div>
              </div>
              <div>
                <div class="card-metrics">
                  <span>Host: #${g.creator_id}</span>
                  <span>Voice Match Ready</span>
                </div>
                <div class="card-bottom-actions">
                  <button class="btn btn-primary btn-sm" style="width:100%;" onclick="joinSquad(${g.id})">Join Squad</button>
                </div>
              </div>
            </div>
          `).join('');
        } else if (gGrid) {
          gGrid.innerHTML = `
            <div class="state-box" style="grid-column:1/-1;">
              <div class="state-icon">🎮</div>
              <div class="state-title">No Active Gaming Squads</div>
              <div class="state-desc">No squads looking for players right now. Host a squad or queue with Rai LFG.</div>
              <button class="btn btn-primary btn-sm" onclick="openCreateSpaceModal()">+ Host a Squad</button>
            </div>
          `;
        }
      } catch (e) {}

      // 7. Fetch 🚀 ACTIVE PROJECTS
      try {
        const pRes = await fetch('/api/projects');
        const pData = await pRes.json();
        const pGrid = document.getElementById('home-projects-grid');
        if (pGrid && pData.success && pData.data && pData.data.length > 0) {
          pGrid.innerHTML = pData.data.slice(0, 3).map(p => `
            <div class="discovery-card">
              <div>
                <div class="card-top">
                  <div class="card-media-icon">🚀</div>
                  <div class="card-heading">
                    <div class="card-name">${p.name}</div>
                    <div class="card-subtitle">${p.project_type.toUpperCase()}</div>
                  </div>
                </div>
                <div class="card-desc">Connected Discord workspace with synchronized chat, voice rooms, and Kanban board.</div>
                <div class="card-tags">
                  <span class="pill pill-purple">${p.status.toUpperCase()}</span>
                  <span class="tag-badge">Discord Sync</span>
                </div>
              </div>
              <div>
                <div class="card-metrics">
                  <span>Owner: #${p.owner_id}</span>
                  <span style="color:var(--text-dim);">${p.created_at.split('T')[0]}</span>
                </div>
                <div class="card-bottom-actions">
                  <button class="btn btn-outline btn-sm" style="flex:1;" onclick="openProjectWorkspace(${p.id})">Open Board</button>
                  <button class="btn btn-outline btn-sm" onclick="toggleSaveItem('project', '${p.id}', '${p.name}', '${p.project_type}')">🔖</button>
                </div>
              </div>
            </div>
          `).join('');
        } else if (pGrid) {
          pGrid.innerHTML = `
            <div class="state-box">
              <div class="state-icon">🚀</div>
              <div class="state-title">No Projects Discovered Yet</div>
              <div class="state-desc">Initiate a collaborative project to coordinate video editing, tournaments, or community tools.</div>
              <button class="btn btn-primary" onclick="openCreateProjectModal()">+ Launch Project</button>
            </div>
          `;
        }
      } catch (e) {}

      // 8. Fetch 📅 EVENTS
      try {
        const eRes = await fetch('/api/events');
        const eData = await eRes.json();
        const eGrid = document.getElementById('home-events-grid');
        if (eGrid && eData.success && eData.data && eData.data.length > 0) {
          eGrid.innerHTML = eData.data.slice(0, 3).map(ev => `
            <div class="discovery-card">
              <div>
                <div class="card-top">
                  <div class="card-media-icon">📅</div>
                  <div class="card-heading">
                    <div class="card-name">${ev.title}</div>
                    <div class="card-subtitle">${ev.event_type.toUpperCase()}</div>
                  </div>
                </div>
                <div class="card-desc">${ev.description || 'Community gathering scheduled in Discord channels.'}</div>
                <div class="card-tags">
                  <span class="pill pill-pink">${ev.status.toUpperCase()}</span>
                  <span class="tag-badge">Starts: ${ev.start_time.split('T')[0]}</span>
                </div>
              </div>
              <div class="card-bottom-actions">
                <button class="btn btn-outline btn-sm" style="flex:1;" onclick="rsvpEvent(${ev.id})">RSVP Interested</button>
                <a href="https://discord.gg/raivora" target="_blank" class="btn btn-discord btn-sm" style="flex:1;">Join Discord</a>
              </div>
            </div>
          `).join('');
        } else if (eGrid) {
          eGrid.innerHTML = `
            <div class="state-box" style="grid-column:1/-1;">
              <div class="state-icon">📅</div>
              <div class="state-title">No Scheduled Events</div>
              <div class="state-desc">No events are currently scheduled across community channels.</div>
              <button class="btn btn-primary btn-sm" onclick="openCreateSpaceModal()">+ Schedule Event</button>
            </div>
          `;
        }
      } catch (e) {}
    }
    // ==========================================
    // 9. COMMUNITIES DIRECTORY VIEW (/communities)
    // ==========================================
    async function renderCommunities(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">👥 Communities Directory</span>
            <span class="pill pill-purple">THE RAIVORA HUBS</span>
          </div>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem; line-height:1.6;">
          Discover official and verified community hubs connected with Rai. Join servers, explore creative studios, and find active gaming clans.
        </p>

        <!-- FILTERS & SORTING ROW -->
        <div class="filters-row">
          <div class="filter-group">
            <input type="text" id="comm-search" class="input-field" placeholder="Search communities..." oninput="filterCommunities()" style="width:220px;">
            <select id="comm-cat-filter" class="select-field" onchange="filterCommunities()">
              <option value="all">All Categories</option>
              <option value="creators">🎨 Creators & Media</option>
              <option value="gaming">🎮 Gaming & Esports</option>
              <option value="projects">🚀 Dev & Tech</option>
            </select>
          </div>
          <div class="filter-group">
            <span style="font-size:0.85rem; color:var(--text-muted);">Sort by:</span>
            <select id="comm-sort" class="select-field" onchange="filterCommunities()">
              <option value="trending">🔥 Trending</option>
              <option value="most_active">⚡ Most Active</option>
              <option value="members">👥 Member Count</option>
              <option value="newest">✨ Newest</option>
            </select>
          </div>
        </div>

        <div class="discovery-grid" id="communities-list-grid">
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
        </div>
      `;

      loadCommunitiesDirectory();
    }

    async function loadCommunitiesDirectory() {
      const q = document.getElementById('comm-search') ? document.getElementById('comm-search').value.trim() : '';
      const cat = document.getElementById('comm-cat-filter') ? document.getElementById('comm-cat-filter').value : 'all';
      const sort = document.getElementById('comm-sort') ? document.getElementById('comm-sort').value : 'trending';

      try {
        const res = await fetch(`/api/communities?q=${encodeURIComponent(q)}&category=${cat}&sort=${sort}`);
        const data = await res.json();
        const grid = document.getElementById('communities-list-grid');
        if (data.success && data.data && data.data.length > 0) {
          grid.innerHTML = data.data.map(c => `
            <div class="discovery-card">
              <div>
                <div class="card-top">
                  <div class="card-media-icon">${c.icon && c.icon.length > 5 ? `<img src="${c.icon}">` : (c.icon || '✦')}</div>
                  <div class="card-heading">
                    <div class="card-name">${c.name} ${c.verified ? '✓' : ''}</div>
                    <div class="card-subtitle">${c.badge || c.type}</div>
                  </div>
                </div>
                <div class="card-desc">${c.description}</div>
                <div class="card-tags">
                  ${c.tags.map(t => `<span class="tag-badge">${t}</span>`).join('')}
                </div>
              </div>
              <div>
                <div class="card-metrics">
                  <span>👥 ${c.members} members</span>
                  <span>🚀 ${c.active_projects} active projects</span>
                </div>
                <div class="card-bottom-actions">
                  <button class="btn btn-outline btn-sm" style="flex:1;" onclick="navigate('/communities/${c.id}')">View Details</button>
                  <a href="${c.invite_url}" target="_blank" class="btn btn-discord btn-sm" style="flex:1;">Join Server</a>
                  <button class="btn btn-outline btn-sm" onclick="toggleSaveItem('community', '${c.id}', '${c.name}', '${c.category}')">🔖</button>
                </div>
              </div>
            </div>
          `).join('');
        } else {
          grid.innerHTML = `
            <div class="state-box">
              <div class="state-icon">🔍</div>
              <div class="state-title">No Communities Found</div>
              <div class="state-desc">No communities match your current search filters. Try clearing your search term.</div>
            </div>
          `;
        }
      } catch (e) {
        document.getElementById('communities-list-grid').innerHTML = `<div class="state-box"><div class="state-title">Rai couldn't load communities</div><button class="btn btn-primary" onclick="loadCommunitiesDirectory()">Retry</button></div>`;
      }
    }

    function filterCommunities() {
      clearTimeout(searchDebounceTimer);
      searchDebounceTimer = setTimeout(loadCommunitiesDirectory, 200);
    }

    // ==========================================
    // 10. COMMUNITY DETAIL VIEW (/communities/:id)
    // ==========================================
    async function renderCommunityDetail(container, commId) {
      container.innerHTML = `<div class="state-box"><div class="state-icon">⏳</div><div class="state-title">Loading Community Hub...</div></div>`;

      try {
        const res = await fetch(`/api/communities/${commId}`);
        const data = await res.json();
        if (!data.success || !data.data) {
          container.innerHTML = `<div class="state-box"><div class="state-title">Community Not Found</div><button class="btn btn-outline" onclick="navigate('/communities')">Back to Directory</button></div>`;
          return;
        }

        const c = data.data.community;
        const projects = data.data.projects || [];
        const creators = data.data.creators || [];
        const events = data.data.events || [];

        container.innerHTML = `
          <!-- BANNER & HEADER -->
          <div style="background:url('${c.banner || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&q=80'}') center/cover; border-radius:var(--radius-lg); height:220px; position:relative; margin-bottom:4rem; border:1px solid rgba(255,255,255,0.1);">
            <div style="position:absolute; bottom:-35px; left:2.5rem; display:flex; align-items:flex-end; gap:1.2rem;">
              <div style="width:84px; height:84px; border-radius:var(--radius-lg); background:linear-gradient(135deg, var(--primary), #7c3aed); border:3px solid var(--bg-dark); display:flex; align-items:center; justify-content:center; font-size:2.8rem; box-shadow:0 8px 25px rgba(0,0,0,0.7);">
                ${c.icon && c.icon.length > 5 ? `<img src="${c.icon}" style="width:100%; height:100%; object-fit:cover; border-radius:inherit;">` : (c.icon || '✦')}
              </div>
              <div style="margin-bottom:0.5rem;">
                <h2 style="font-size:2rem; font-weight:800; color:#fff;">${c.name} ${c.verified ? '✓' : ''}</h2>
                <span class="pill pill-purple">${c.badge || c.type}</span>
              </div>
            </div>
            <div style="position:absolute; bottom:1rem; right:1.5rem; display:flex; gap:0.6rem;">
              <a href="${c.invite_url}" target="_blank" class="btn btn-discord btn-sm">Join Discord Server</a>
              <button class="btn btn-outline btn-sm" onclick="toggleSaveItem('community', '${c.id}', '${c.name}', '${c.category}')">🔖 Save</button>
            </div>
          </div>

          <div style="margin-bottom:2.5rem; max-width:850px;">
            <h4 style="color:#fff; margin-bottom:0.5rem; font-size:1.1rem;">About ${c.name}</h4>
            <p style="color:var(--text-muted); line-height:1.7; font-size:0.95rem;">${c.description}</p>
            <div style="display:flex; gap:0.5rem; margin-top:1rem; flex-wrap:wrap;">
              ${c.tags.map(t => `<span class="tag-badge">#${t}</span>`).join('')}
            </div>
          </div>

          <!-- COMMUNITY PROJECTS -->
          <div class="section-title">
            <span class="title-text">🚀 Active Projects in this Hub (${projects.length})</span>
            <button class="btn btn-primary btn-sm" onclick="openCreateProjectModal()">+ Launch Project</button>
          </div>
          <div class="discovery-grid" style="margin-bottom:3rem;">
            ${projects.length > 0 ? projects.map(p => `
              <div class="discovery-card">
                <div>
                  <div class="card-name">${p.name}</div>
                  <div class="card-subtitle">${p.project_type.toUpperCase()}</div>
                  <div class="card-desc" style="margin-top:0.6rem;">Discord synced project workspace.</div>
                </div>
                <div class="card-bottom-actions">
                  <button class="btn btn-outline btn-sm" style="width:100%;" onclick="openProjectWorkspace(${p.id})">Open Board</button>
                </div>
              </div>
            `).join('') : '<div class="state-box" style="grid-column:1/-1;"><div class="state-desc">No active projects launched in this hub yet.</div></div>'}
          </div>

          <!-- COMMUNITY CREATORS -->
          <div class="section-title">
            <span class="title-text">🎨 Featured Creators & Editors (${creators.length})</span>
            <button class="btn btn-outline btn-sm" onclick="navigate('/creators')">All Creators</button>
          </div>
          <div class="discovery-grid">
            ${creators.length > 0 ? creators.map(cr => `
              <div class="discovery-card">
                <div>
                  <div class="card-name">${cr.title}</div>
                  <div class="card-subtitle">${cr.category.toUpperCase()}</div>
                  <div class="card-desc" style="margin-top:0.6rem;">${cr.description || 'Creator portfolio showcase item.'}</div>
                </div>
                <div class="card-bottom-actions">
                  <button class="btn btn-outline btn-sm" style="width:100%;" onclick="openPortfolioModal(${JSON.stringify(cr).replace(/"/g, '&quot;')})">View Portfolio</button>
                </div>
              </div>
            `).join('') : '<div class="state-box" style="grid-column:1/-1;"><div class="state-desc">No creator showcases listed in this community yet.</div></div>'}
          </div>
        `;
      } catch (e) {
        container.innerHTML = `<div class="state-box"><div class="state-title">Error Loading Community</div><p style="color:var(--danger);">${e}</p></div>`;
      }
    }

    // ==========================================
    // 11. RAI PRODUCT PAGE (/rai)
    // ==========================================
    function renderRaiProduct(container) {
      container.innerHTML = `
        <div class="discovery-hero">
          <div class="hero-badge">✦ RAI COMMUNITY OS • PLATFORM SPECIFICATION ✦</div>
          <h2 class="hero-title">THE RAIVORA COMMUNITY AI</h2>
          <p class="hero-subtitle">
            An intelligent community operating system for Discord, creators, gaming squads, lossless music, and autonomous automation.
          </p>
          <div class="hero-actions">
            <a href="https://discord.com/oauth2/authorize?client_id=1554732669072445532&permissions=8&scope=bot%20applications.commands" target="_blank" class="btn btn-primary btn-lg">
              <span>✦</span> ADD TO DISCORD
            </a>
            <button class="btn btn-outline btn-lg" onclick="navigate('/rai/features')">
              <span>⚙</span> EXPLORE FEATURES
            </button>
          </div>
        </div>

        <!-- 10 CORE PILLARS GRID -->
        <div class="section-title">
          <span class="title-text">✦ Architecture & Core Pillars</span>
          <span class="pill pill-cyan">PRODUCTION VERIFIED</span>
        </div>

        <div class="discovery-grid">
          <div class="discovery-card">
            <div>
              <div class="card-top">
                <div class="card-media-icon">🛡️</div>
                <div class="card-heading">
                  <div class="card-name">Security & Anti-Nuke</div>
                  <div class="card-subtitle">PROTECTION</div>
                </div>
              </div>
              <div class="card-desc">Atomic quarantine role stripping, velocity tripwires, malicious webhook suppression, and instant rollback.</div>
            </div>
            <div class="card-bottom-actions">
              <button class="btn btn-outline btn-sm" style="width:100%;" onclick="navigate('/rai/features#security')">Inspect Subsystem</button>
            </div>
          </div>

          <div class="discovery-card">
            <div>
              <div class="card-top">
                <div class="card-media-icon">🎧</div>
                <div class="card-heading">
                  <div class="card-name">High-Fidelity Music</div>
                  <div class="card-subtitle">320KBPS OPUS</div>
                </div>
              </div>
              <div class="card-desc">Lossless 320kbps audio streaming in voice channels with zero buffering, collaborative queues, and Auto-DJ.</div>
            </div>
            <div class="card-bottom-actions">
              <button class="btn btn-outline btn-sm" style="width:100%;" onclick="navigate('/rai/features#music')">Inspect Subsystem</button>
            </div>
          </div>

          <div class="discovery-card">
            <div>
              <div class="card-top">
                <div class="card-media-icon">🔊</div>
                <div class="card-heading">
                  <div class="card-name">Dynamic Voice Channels</div>
                  <div class="card-subtitle">VOICE MATRIX</div>
                </div>
              </div>
              <div class="card-desc">Zero-latency temporary voice rooms spawned automatically when members join generators. Auto-garbage collection on empty.</div>
            </div>
            <div class="card-bottom-actions">
              <button class="btn btn-outline btn-sm" style="width:100%;" onclick="navigate('/rai/features#dynamic-vc')">Inspect Subsystem</button>
            </div>
          </div>

          <div class="discovery-card">
            <div>
              <div class="card-top">
                <div class="card-media-icon">💾</div>
                <div class="card-heading">
                  <div class="card-name">Backup & Recovery</div>
                  <div class="card-subtitle">RELIABILITY</div>
                </div>
              </div>
              <div class="card-desc">Automated SQLite WAL delta snapshotting, serialized role permissions, and one-click disaster recovery.</div>
            </div>
            <div class="card-bottom-actions">
              <button class="btn btn-outline btn-sm" style="width:100%;" onclick="navigate('/rai/features#backup')">Inspect Subsystem</button>
            </div>
          </div>

          <div class="discovery-card">
            <div>
              <div class="card-top">
                <div class="card-media-icon">🚀</div>
                <div class="card-heading">
                  <div class="card-name">Project Workspaces</div>
                  <div class="card-subtitle">PRODUCTIVITY</div>
                </div>
              </div>
              <div class="card-desc">Interactive Kanban task boards with asynchronous Outbox worker linking Discord channels automatically.</div>
            </div>
            <div class="card-bottom-actions">
              <button class="btn btn-outline btn-sm" style="width:100%;" onclick="navigate('/projects')">View Boards</button>
            </div>
          </div>

          <div class="discovery-card">
            <div>
              <div class="card-top">
                <div class="card-media-icon">🎮</div>
                <div class="card-heading">
                  <div class="card-name">Gaming LFG Matchmaker</div>
                  <div class="card-subtitle">COMMUNITY</div>
                </div>
              </div>
              <div class="card-desc">Live party recruitment for BGMI, Valorant, Helldivers, and Apex with automatic voice room coordination.</div>
            </div>
            <div class="card-bottom-actions">
              <button class="btn btn-outline btn-sm" style="width:100%;" onclick="navigate('/gaming')">Join Matchmaker</button>
            </div>
          </div>
        </div>
      `;
    }

    // ==========================================
    // 12. RAI FEATURES DIRECTORY (/rai/features)
    // ==========================================
    async function renderRaiFeatures(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">⚙ Rai Systems & Subsystems Directory</span>
            <span class="pill pill-purple">18+ REAL SUBSYSTEMS</span>
          </div>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem; line-height:1.6;">
          Complete architectural directory of Rai Community OS. All features documented here are truthfully implemented and supervised in the live bot.
        </p>

        <div class="discovery-grid" id="features-directory-grid">
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
        </div>
      `;

      try {
        const res = await fetch('/api/rai/features');
        const data = await res.json();
        const grid = document.getElementById('features-directory-grid');
        if (data.success && data.data) {
          grid.innerHTML = data.data.map(f => `
            <div class="discovery-card" id="${f.id}">
              <div>
                <div class="card-top">
                  <div class="card-media-icon">${f.icon}</div>
                  <div class="card-heading">
                    <div class="card-name">${f.name}</div>
                    <div class="card-subtitle">${f.category.toUpperCase()}</div>
                  </div>
                </div>
                <div class="card-desc">${f.summary}</div>
                <ul style="padding-left:1.2rem; font-size:0.82rem; color:var(--text-muted); margin-bottom:1rem; line-height:1.6;">
                  ${f.details.map(d => `<li>${d}</li>`).join('')}
                </ul>
              </div>
              <div class="card-metrics">
                <span class="pill pill-green">STATUS: ${f.status}</span>
                <span style="font-size:0.75rem; color:var(--cyan);">Rai Core Subsystem</span>
              </div>
            </div>
          `).join('');
        }
      } catch (e) {}
    }

    // ==========================================
    // 13. USER SAVED BOOKMARKS VIEW (/saved)
    // ==========================================
    async function renderSaved(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">🔖 My Saved Bookmarks</span>
            <span class="pill pill-purple">PERSISTENT SAVES</span>
          </div>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem;">
          Quickly access your saved communities, projects, creators, resources, and ideas.
        </p>
        <div class="discovery-grid" id="saved-items-grid">
          <div class="skeleton-card"></div>
        </div>
      `;

      if (!currentUser) {
        document.getElementById('saved-items-grid').innerHTML = `
          <div class="state-box">
            <div class="state-icon">🔒</div>
            <div class="state-title">Sign In to View Bookmarks</div>
            <div class="state-desc">Connect your Discord account to save communities, projects, and resources.</div>
            <button class="btn btn-discord" onclick="openLoginModal()">Log In with Discord</button>
          </div>
        `;
        return;
      }

      try {
        const res = await fetch('/api/saved');
        const data = await res.json();
        const grid = document.getElementById('saved-items-grid');
        if (data.success && data.data && data.data.saved && data.data.saved.length > 0) {
          grid.innerHTML = data.data.saved.map(item => `
            <div class="discovery-card">
              <div>
                <div class="card-top">
                  <div class="card-media-icon">🔖</div>
                  <div class="card-heading">
                    <div class="card-name">${item.title}</div>
                    <div class="card-subtitle">${item.item_type.toUpperCase()} • ${item.category || 'General'}</div>
                  </div>
                </div>
                <div class="card-desc">Saved on ${item.created_at.split('T')[0]}</div>
              </div>
              <div class="card-bottom-actions">
                <button class="btn btn-outline btn-sm" style="flex:1;" onclick="navigate('/${item.item_type === 'community' ? 'communities/' + item.item_id : (item.item_type === 'project' ? 'projects/' + item.item_id : item.item_type + 's')}')">Open</button>
                <button class="btn btn-outline btn-sm" onclick="toggleSaveItem('${item.item_type}', '${item.item_id}', '${item.title}', '${item.category}')">Remove</button>
              </div>
            </div>
          `).join('');
        } else {
          grid.innerHTML = `
            <div class="state-box">
              <div class="state-icon">🔖</div>
              <div class="state-title">No Saved Items Yet</div>
              <div class="state-desc">Click the bookmark icon (🔖) on any community, project, or resource to save it here.</div>
              <button class="btn btn-primary" onclick="navigate('/communities')">Discover Communities</button>
            </div>
          `;
        }
      } catch (e) {
        document.getElementById('saved-items-grid').innerHTML = `<div class="state-box"><div class="state-title">Error loading saved items</div></div>`;
      }
    }

    // ==========================================
    // 14. PERSONAL DASHBOARD (/dashboard)
    // ==========================================
    async function renderDashboard(container) {
      if (!currentUser) {
        container.innerHTML = `
          <div class="state-box">
            <div class="state-icon">👾</div>
            <div class="state-title">Personal Dashboard Access</div>
            <div class="state-desc">Sign in with Discord to access your personal workspace, manage your creator portfolio, and track collaboration requests.</div>
            <button class="btn btn-discord" onclick="openLoginModal()">Log In with Discord</button>
          </div>
        `;
        return;
      }

      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">⚡ Member Workspace & Dashboard</span>
            <span class="pill pill-green">AUTHENTICATED: ${currentUser.display_name}</span>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 2fr; gap:2rem; margin-bottom:3rem;" id="dashboard-layout">
          <!-- PROFILE CARD -->
          <div class="discovery-card" style="height:fit-content;">
            <div style="text-align:center; padding:1rem 0;">
              <img src="${currentUser.avatar_url || 'https://cdn.discordapp.com/embed/avatars/0.png'}" style="width:84px; height:84px; border-radius:50%; border:3px solid var(--primary); margin-bottom:0.8rem;">
              <h3 style="color:#fff; font-size:1.3rem;">${currentUser.display_name}</h3>
              <div style="font-size:0.8rem; color:var(--cyan); margin-top:0.2rem;">Discord ID: ${currentUser.id}</div>
              ${currentUser.is_admin ? '<span class="pill pill-purple" style="margin-top:0.6rem;">SERVER ADMIN</span>' : ''}
            </div>
            <div style="border-top:1px solid rgba(255,255,255,0.08); padding-top:1rem; display:flex; flex-direction:column; gap:0.6rem;">
              <button class="btn btn-outline btn-sm" onclick="openEditProfileModal()">Edit Public Profile</button>
              <button class="btn btn-outline btn-sm" onclick="openCreatePortfolioModal()">+ Add Portfolio Item</button>
              <button class="btn btn-outline btn-sm" onclick="navigate('/saved')">View Bookmarks (🔖)</button>
              <button class="btn btn-outline btn-sm" onclick="logout()">Log Out</button>
            </div>
          </div>

          <!-- SUMMARY & ACTIVITY -->
          <div>
            <div class="section-title" style="margin-top:0;">
              <span class="title-text" style="font-size:1.15rem;">📁 My Projects & Tasks</span>
              <button class="btn btn-primary btn-sm" onclick="openCreateProjectModal()">+ New Project</button>
            </div>
            <div id="dash-projects-grid" class="discovery-grid" style="grid-template-columns:1fr; margin-bottom:2rem;">
              <div class="skeleton-card" style="min-height:120px;"></div>
            </div>

            <div class="section-title">
              <span class="title-text" style="font-size:1.15rem;">🤝 Collaboration Requests</span>
            </div>
            <div id="dash-collabs-grid">
              <div style="color:var(--text-muted); font-size:0.88rem;">No pending collaboration requests.</div>
            </div>
          </div>
        </div>
      `;

      loadDashboardData();
    }

    async function loadDashboardData() {
      try {
        const res = await fetch('/api/workspace/summary');
        const data = await res.json();
        const pGrid = document.getElementById('dash-projects-grid');
        if (data.success && data.data) {
          const projs = data.data.my_projects || [];
          if (pGrid) {
            if (projs.length > 0) {
              pGrid.innerHTML = projs.map(p => `
                <div class="discovery-card" style="padding:1rem;">
                  <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div>
                      <div class="card-name">${p.name}</div>
                      <div class="card-subtitle">${p.project_type.toUpperCase()}</div>
                    </div>
                    <button class="btn btn-outline btn-sm" onclick="openProjectWorkspace(${p.id})">Open Board</button>
                  </div>
                </div>
              `).join('');
            } else {
              pGrid.innerHTML = `<div style="color:var(--text-muted); font-size:0.88rem;">You haven't created any projects yet.</div>`;
            }
          }
        }
      } catch (e) {}
    }

    function openEditProfileModal() {
      openModal('Edit Public Profile', `
        <form onsubmit="submitProfileUpdate(event)">
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Skills (comma-separated)</label>
            <input type="text" id="prof-skills" class="input-field" style="width:100%;" placeholder="e.g. Video Editing, After Effects, 3D">
          </div>
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Bio & Description</label>
            <textarea id="prof-bio" class="input-field" style="width:100%; height:90px;" placeholder="Tell the community about yourself..."></textarea>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;">Save Profile</button>
        </form>
      `);
    }

    async function submitProfileUpdate(e) {
      e.preventDefault();
      const skills = document.getElementById('prof-skills').value.trim();
      const bio = document.getElementById('prof-bio').value.trim();
      await fetch('/api/profiles/me', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ skills, bio })
      });
      closeModal();
      navigate('/dashboard');
    }

    // ==========================================
    // 15. DISCOVER VIEW (FULL SEARCH & BROWSE)
    // ==========================================
    async function renderDiscover(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">🔍 Global Community Discovery</span>
            <span class="pill pill-cyan">AUTHORIZED SEARCH</span>
          </div>
        </div>
        <p style="color:var(--text-muted); margin-bottom:1.8rem; line-height:1.6;">
          Search across authorized public communities, active projects, creator portfolios, gaming squads, and knowledge guides.
        </p>

        <div style="display:flex; gap:0.8rem; margin-bottom:2rem;">
          <input type="text" class="input-field" id="discover-input" placeholder="Search communities, creators, projects, games, resources..." oninput="onDiscoverSearch(this.value)" style="flex:1; padding:0.75rem 1.2rem; font-size:1rem; border-radius:var(--radius-full);">
        </div>

        <div class="discovery-grid" id="discover-results">
          <div style="color:var(--text-muted); grid-column:1/-1;">Type a search keyword to discover modules.</div>
        </div>
      `;
      onDiscoverSearch('');
    }

    async function onDiscoverSearch(q) {
      const resContainer = document.getElementById('discover-results');
      if (!resContainer) return;
      try {
        const res = await fetch('/api/brain/search?q=' + encodeURIComponent(q || 'community'));
        const data = await res.json();
        if (data.success && data.data && data.data.results.length > 0) {
          resContainer.innerHTML = data.data.results.map(item => `
            <div class="discovery-card">
              <div>
                <div class="card-top">
                  <div class="card-media-icon">✦</div>
                  <div class="card-heading">
                    <div class="card-name">${item.title}</div>
                    <div class="card-subtitle">${item.type}</div>
                  </div>
                </div>
                <div class="card-desc">${item.snippet || ''}</div>
              </div>
              <div class="card-bottom-actions">
                ${item.link ? `<button class="btn btn-outline btn-sm" style="width:100%;" onclick="navigate('${item.link}')">View Discovery</button>` : ''}
              </div>
            </div>
          `).join('');
        } else {
          resContainer.innerHTML = `<div class="state-box" style="grid-column:1/-1;"><div class="state-title">No matches found for "${q}"</div></div>`;
        }
      } catch (e) {}
    }

    // ==========================================
    // 16. BRAIN VIEW (/brain)
    // ==========================================
    function renderBrain(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">🧠 Rai Community Brain</span>
            <span class="pill pill-purple">PERMISSION-AWARE KNOWLEDGE</span>
          </div>
        </div>
        <p style="color:var(--text-muted); margin-bottom:1.5rem; line-height:1.6;">
          Ask questions about server rules, creators, editing tools, music production, or events.
          Rai Brain indexes approved community knowledge with full source citations. Zero fabricated facts.
        </p>

        <div style="display:flex; gap:0.8rem; margin-bottom:1.5rem;">
          <input type="text" class="input-field" id="brain-input" placeholder="e.g. 'Where can I find editing resources?', 'What are the server rules?'" onkeydown="if(event.key==='Enter')askBrain()" style="flex:1; border-radius:var(--radius-full); padding:0.75rem 1.2rem;">
          <button class="btn btn-primary" onclick="askBrain()">Ask Brain</button>
        </div>

        <div style="display:flex; gap:0.5rem; margin-bottom:2rem; flex-wrap:wrap;">
          <span class="pill pill-purple" style="cursor:pointer;" onclick="setBrainQuery('editing resources')">🎨 Editing resources</span>
          <span class="pill pill-cyan" style="cursor:pointer;" onclick="setBrainQuery('gaming events')">🎮 Gaming events</span>
          <span class="pill pill-green" style="cursor:pointer;" onclick="setBrainQuery('community rules')">📜 Community rules</span>
        </div>

        <div id="brain-response-box"></div>
      `;
    }

    function setBrainQuery(q) {
      document.getElementById('brain-input').value = q;
      askBrain();
    }

    async function askBrain() {
      const q = document.getElementById('brain-input').value.trim();
      const box = document.getElementById('brain-response-box');
      if (!q) return;
      box.innerHTML = `<div class="card" style="padding:1.5rem;"><p style="color:var(--text-muted);">Searching verified community citations...</p></div>`;

      try {
        const res = await fetch('/api/brain/search?q=' + encodeURIComponent(q));
        const data = await res.json();
        if (data.success && data.data && data.data.results.length > 0) {
          box.innerHTML = `
            <div class="card" style="border-color: rgba(147, 51, 234, 0.45); margin-bottom:1.5rem; padding:1.5rem; background:rgba(18,20,32,0.85); border-radius:var(--radius-lg);">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.8rem;">
                <div style="font-weight:800; font-size:1.1rem; color:#fff;">✦ Verified Knowledge Response</div>
                <span class="pill pill-green">HIGH CONFIDENCE</span>
              </div>
              <div style="font-size:0.95rem; color:#fff; line-height:1.7; margin-bottom:1rem;">
                Discovered ${data.data.total_matches} relevant community source(s) for your inquiry.
              </div>
              <div style="background:rgba(0,0,0,0.4); border-radius:12px; padding:1rem; margin-bottom:1rem;">
                <div style="font-size:0.8rem; font-weight:700; color:var(--cyan); margin-bottom:0.5rem;">SOURCES & CITATIONS:</div>
                <ul style="padding-left:1.2rem; font-size:0.85rem; color:var(--text-muted);">
                  ${data.data.citations.map(c => `<li>${c}</li>`).join('')}
                </ul>
              </div>
            </div>

            <div class="discovery-grid">
              ${data.data.results.map(r => `
                <div class="discovery-card">
                  <div>
                    <div class="card-name">${r.title}</div>
                    <div class="card-subtitle">${r.type}</div>
                    <div class="card-desc" style="margin-top:0.6rem;">${r.snippet}</div>
                  </div>
                  <div class="card-metrics">
                    <span>${r.source}</span>
                  </div>
                </div>
              `).join('')}
            </div>
          `;
        } else {
          box.innerHTML = `<div class="state-box"><div class="state-title">No verified knowledge found for "${q}"</div><div class="state-desc">Try another topic or browse the Community Wiki.</div></div>`;
        }
      } catch (e) {
        box.innerHTML = `<div class="state-box"><div class="state-title">Error querying Brain</div><p style="color:var(--danger);">${e}</p></div>`;
      }
    }

    // ==========================================
    // 17. PROJECTS VIEW (/projects)
    // ==========================================
    async function renderProjects(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">🚀 Projects Discovery</span>
            <span class="pill pill-purple">COMMUNITY WORKSPACES</span>
          </div>
          <button class="btn btn-primary btn-sm" onclick="openCreateProjectModal()">+ Launch Project</button>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem;">
          Discover and collaborate on community projects. Every project is automatically synchronized with Discord channels.
        </p>
        <div class="discovery-grid" id="projects-page-grid"><div class="skeleton-card"></div></div>
      `;

      try {
        const res = await fetch('/api/projects');
        const data = await res.json();
        const grid = document.getElementById('projects-page-grid');
        if (data.success && data.data && data.data.length > 0) {
          grid.innerHTML = data.data.map(p => `
            <div class="discovery-card">
              <div>
                <div class="card-top">
                  <div class="card-media-icon">🚀</div>
                  <div class="card-heading">
                    <div class="card-name">${p.name}</div>
                    <div class="card-subtitle">${p.project_type.toUpperCase()}</div>
                  </div>
                </div>
                <div class="card-desc">Collaborative space connected with Discord channels and task boards.</div>
                <div class="card-tags">
                  <span class="pill pill-purple">${p.status.toUpperCase()}</span>
                </div>
              </div>
              <div class="card-bottom-actions">
                <button class="btn btn-outline btn-sm" style="flex:1;" onclick="openProjectWorkspace(${p.id})">Open Board</button>
                <button class="btn btn-outline btn-sm" onclick="toggleSaveItem('project', '${p.id}', '${p.name}', '${p.project_type}')">🔖</button>
              </div>
            </div>
          `).join('');
        } else {
          grid.innerHTML = `<div class="state-box" style="grid-column:1/-1;"><div class="state-title">No Projects Launched Yet</div><button class="btn btn-primary" onclick="openCreateProjectModal()">+ Launch Project</button></div>`;
        }
      } catch (e) {}
    }

    function openCreateProjectModal() {
      if (!currentUser) { alert('Please sign in to launch a project.'); openLoginModal(); return; }
      openModal('Launch Community Project', `
        <form onsubmit="submitNewProject(event)">
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Project Name</label>
            <input type="text" id="new-proj-name" class="input-field" style="width:100%;" placeholder="e.g. YouTube Montage, BGMI Squad" required>
          </div>
          <div style="margin-bottom:1.5rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Category</label>
            <select id="new-proj-type" class="input-field" style="width:100%;">
              <option value="creator">Creator / Video Editing</option>
              <option value="gaming">Gaming Team / Esports</option>
              <option value="music">Music / Audio Production</option>
              <option value="community">Community Initiative</option>
              <option value="general">General Project</option>
            </select>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;">Launch Project</button>
        </form>
      `);
    }

    async function submitNewProject(e) {
      e.preventDefault();
      const name = document.getElementById('new-proj-name').value.trim();
      const project_type = document.getElementById('new-proj-type').value;
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, project_type })
      });
      const data = await res.json();
      if (data.success) {
        closeModal();
        navigate('/projects');
      } else alert(data.error?.message || 'Failed to create project');
    }

    async function openProjectWorkspace(projId) {
      const res = await fetch('/api/projects/' + projId);
      const data = await res.json();
      if (!data.success) return alert('Project not found');
      const p = data.data.project;
      const tasks = data.data.tasks || [];

      openModal(`📁 ${p.name} — Workspace`, `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
          <span class="pill pill-purple">${p.project_type.toUpperCase()}</span>
          ${data.data.discord_deep_link ? `<a href="${data.data.discord_deep_link}" target="_blank" class="btn btn-discord btn-sm">Open in Discord ↗</a>` : ''}
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
          <h4 style="color:#fff;">Project Tasks</h4>
          <button class="btn btn-primary btn-sm" onclick="promptAddTask(${projId})">+ Add Task</button>
        </div>
        <div class="kanban-board">
          <div class="kanban-col">
            <div class="kanban-header">TODO (${tasks.filter(t => t.status === 'TODO').length})</div>
            ${tasks.filter(t => t.status === 'TODO').map(t => `<div class="kanban-task" onclick="cycleTask(${projId}, ${t.id}, 'IN_PROGRESS')"><strong>${t.title}</strong><div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.3rem;">Advance &rarr;</div></div>`).join('')}
          </div>
          <div class="kanban-col">
            <div class="kanban-header">IN PROGRESS (${tasks.filter(t => t.status === 'IN_PROGRESS').length})</div>
            ${tasks.filter(t => t.status === 'IN_PROGRESS').map(t => `<div class="kanban-task" style="border-color:var(--amber);" onclick="cycleTask(${projId}, ${t.id}, 'DONE')"><strong>${t.title}</strong><div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.3rem;">Complete &rarr;</div></div>`).join('')}
          </div>
          <div class="kanban-col">
            <div class="kanban-header">DONE (${tasks.filter(t => t.status === 'DONE').length})</div>
            ${tasks.filter(t => t.status === 'DONE').map(t => `<div class="kanban-task" style="border-color:var(--emerald);"><strong>${t.title}</strong><div style="font-size:0.75rem; color:var(--emerald); margin-top:0.3rem;">✓ Done</div></div>`).join('')}
          </div>
        </div>
      `);
    }

    async function promptAddTask(projId) {
      const title = prompt('Enter task title:');
      if (!title) return;
      await fetch(`/api/projects/${projId}/tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, status: 'TODO' })
      });
      openProjectWorkspace(projId);
    }

    async function cycleTask(projId, taskId, nextStatus) {
      await fetch(`/api/projects/${projId}/tasks/${taskId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus })
      });
      openProjectWorkspace(projId);
    }

    // ==========================================
    // 18. CREATORS VIEW (/creators)
    // ==========================================
    async function renderCreators(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">🎨 Creator Showcase & Portfolios</span>
            <span class="pill pill-purple">EDITORS & ARTISTS</span>
          </div>
          <button class="btn btn-primary btn-sm" onclick="openCreatePortfolioModal()">+ Add Portfolio Item</button>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem;">
          Explore video editors, VFX motion designers, 3D modelers, beatmakers, and graphic designers in the Rai community.
        </p>
        <div class="discovery-grid" id="creators-page-grid"><div class="skeleton-card"></div></div>
      `;

      try {
        const res = await fetch('/api/creators');
        const data = await res.json();
        const grid = document.getElementById('creators-page-grid');
        if (data.success && data.data && data.data.length > 0) {
          grid.innerHTML = data.data.map(c => `
            <div class="discovery-card">
              <div>
                <div class="card-top">
                  <div class="card-media-icon">🎨</div>
                  <div class="card-heading">
                    <div class="card-name">${c.title}</div>
                    <div class="card-subtitle">${c.category.toUpperCase()}</div>
                  </div>
                </div>
                <div class="card-desc">${c.description || 'Showcase piece verified on Rai Community OS.'}</div>
                <div class="card-tags">
                  <span class="tag-badge">Tools: ${c.tools_used || 'Software'}</span>
                </div>
              </div>
              <div class="card-bottom-actions">
                <button class="btn btn-outline btn-sm" style="flex:1;" onclick="openPortfolioModal(${JSON.stringify(c).replace(/"/g, '&quot;')})">View Item</button>
                <button class="btn btn-outline btn-sm" onclick="toggleSaveItem('creator', '${c.id}', '${c.title}', '${c.category}')">🔖</button>
              </div>
            </div>
          `).join('');
        } else {
          grid.innerHTML = `<div class="state-box" style="grid-column:1/-1;"><div class="state-title">No creator showcases listed yet.</div><button class="btn btn-primary" onclick="openCreatePortfolioModal()">+ Add Portfolio Item</button></div>`;
        }
      } catch (e) {}
    }

    function openPortfolioModal(item) {
      openModal(`🎨 ${item.title}`, `
        <div style="margin-bottom:1rem;">
          <span class="pill pill-purple">${item.category.toUpperCase()}</span>
          ${item.tools_used ? `<span class="tag-badge" style="margin-left:0.5rem;">Tools: ${item.tools_used}</span>` : ''}
        </div>
        <p style="color:var(--text-muted); line-height:1.6; margin-bottom:1.2rem;">${item.description || 'No description provided.'}</p>
        ${item.external_links ? `<a href="${item.external_links}" target="_blank" class="btn btn-primary btn-sm">External Reel ↗</a>` : ''}
      `);
    }

    function openCreatePortfolioModal() {
      if (!currentUser) { alert('Please sign in to publish your portfolio.'); openLoginModal(); return; }
      openModal('Add Creator Portfolio Item', `
        <form onsubmit="submitPortfolioItem(event)">
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Title</label>
            <input type="text" id="port-title" class="input-field" style="width:100%;" placeholder="e.g. 2026 Gaming Montage, Cyber 3D Render" required>
          </div>
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Category</label>
            <select id="port-cat" class="input-field" style="width:100%;">
              <option value="Editing">Video Editing / VFX</option>
              <option value="Design">Graphic Design / Art</option>
              <option value="3D">3D Modeling / Motion</option>
              <option value="Audio">Audio / Beatmaking</option>
              <option value="Code">Development / Scripting</option>
            </select>
          </div>
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Tools Used</label>
            <input type="text" id="port-tools" class="input-field" style="width:100%;" placeholder="e.g. Premiere, After Effects, Blender">
          </div>
          <div style="margin-bottom:1.5rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Description</label>
            <textarea id="port-desc" class="input-field" style="width:100%; height:80px;" placeholder="Brief details on this showcase item..."></textarea>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;">Publish Portfolio Item</button>
        </form>
      `);
    }

    async function submitPortfolioItem(e) {
      e.preventDefault();
      const title = document.getElementById('port-title').value.trim();
      const category = document.getElementById('port-cat').value;
      const tools_used = document.getElementById('port-tools').value.trim();
      const description = document.getElementById('port-desc').value.trim();

      const res = await fetch('/api/creators/portfolio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, category, tools_used, description })
      });
      const data = await res.json();
      if (data.success) {
        closeModal();
        navigate('/creators');
      } else alert(data.error?.message || 'Failed to submit portfolio');
    }

    // ==========================================
    // 19. GAMING VIEW (/gaming)
    // ==========================================
    async function renderGaming(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">🎮 Gaming Hub & LFG Matchmaker</span>
            <span class="pill pill-green">SQUAD FINDER</span>
          </div>
          <button class="btn btn-primary btn-sm" onclick="openCreateLfgModal()">+ Create Squad Request</button>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem;">
          Find teammates, competitive scrims, and rank grinds for BGMI, Valorant, Helldivers 2, and Apex Legends.
        </p>
        <div class="discovery-grid" id="gaming-page-grid"><div class="skeleton-card"></div></div>
      `;

      try {
        const res = await fetch('/api/gaming/lfg');
        const data = await res.json();
        const grid = document.getElementById('gaming-page-grid');
        if (data.success && data.data && data.data.length > 0) {
          grid.innerHTML = data.data.map(g => `
            <div class="discovery-card">
              <div>
                <div class="card-top">
                  <div class="card-media-icon">🎮</div>
                  <div class="card-heading">
                    <div class="card-name">${g.game_name}</div>
                    <div class="card-subtitle">${g.mode || 'Ranked Match'}</div>
                  </div>
                </div>
                <div class="card-desc">${g.description || 'Looking for squad mates with voice chat.'}</div>
                <div class="card-tags">
                  <span class="pill pill-green">OPEN</span>
                  <span class="tag-badge">${g.current_players}/${g.max_players} Players</span>
                </div>
              </div>
              <div class="card-bottom-actions">
                <button class="btn btn-primary btn-sm" style="width:100%;" onclick="joinSquad(${g.id})">Join Squad</button>
              </div>
            </div>
          `).join('');
        } else {
          grid.innerHTML = `<div class="state-box" style="grid-column:1/-1;"><div class="state-title">No Active Squads Right Now</div><button class="btn btn-primary" onclick="openCreateLfgModal()">+ Create Squad Request</button></div>`;
        }
      } catch (e) {}
    }

    function openCreateLfgModal() {
      if (!currentUser) { alert('Please sign in to recruit a squad.'); openLoginModal(); return; }
      openModal('Recruit Gaming Squad (LFG)', `
        <form onsubmit="submitLfg(event)">
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Game</label>
            <input type="text" id="lfg-game" class="input-field" style="width:100%;" placeholder="e.g. BGMI, Valorant, Helldivers 2" required>
          </div>
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Mode / Rank Requirement</label>
            <input type="text" id="lfg-mode" class="input-field" style="width:100%;" placeholder="e.g. Competitive, Diamond+, Casual">
          </div>
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Max Squad Size</label>
            <input type="number" id="lfg-max" class="input-field" style="width:100%;" value="4" min="2" max="10">
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;">Create Squad</button>
        </form>
      `);
    }

    async function submitLfg(e) {
      e.preventDefault();
      const game_name = document.getElementById('lfg-game').value.trim();
      const mode = document.getElementById('lfg-mode').value.trim();
      const max_players = parseInt(document.getElementById('lfg-max').value, 10);
      const res = await fetch('/api/gaming/lfg', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ game_name, mode, max_players, description: 'LFG recruited from Discovery Platform' })
      });
      const data = await res.json();
      if (data.success) {
        closeModal();
        navigate('/gaming');
      } else alert(data.error?.message || 'Could not create squad');
    }

    async function joinSquad(lfgId) {
      if (!currentUser) { alert('Please sign in to join squads.'); openLoginModal(); return; }
      const res = await fetch(`/api/gaming/lfg/${lfgId}/join`, { method: 'POST' });
      const data = await res.json();
      if (data.success) alert('Joined squad successfully! Coordinate in the Discord Voice Room.');
      else alert(data.error?.message || 'Could not join squad');
    }

    // ==========================================
    // ==========================================
    // 20. RAIVORA MUSIC WEB PLATFORM (/music) — PHASE 2 & 3
    // ==========================================
    let musicPollInterval = null;
    let selectedMusicGuildId = '1525030316845301781';
    let currentMusicSession = null;
    let isScrubbingMusic = false;
    let visualizerAnimId = null;

    async function renderMusic(container) {
      if (musicPollInterval) clearInterval(musicPollInterval);
      if (visualizerAnimId) cancelAnimationFrame(visualizerAnimId);

      container.innerHTML = `
        <style>
          .music-shell {
            display: flex;
            flex-direction: column;
            gap: 1.8rem;
            margin-top: 0.5rem;
            max-width: 1200px;
            margin-left: auto;
            margin-right: auto;
          }
          .music-top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            background: rgba(15, 17, 26, 0.7);
            border: 1px solid rgba(147, 51, 234, 0.25);
            backdrop-filter: blur(16px);
            padding: 1rem 1.4rem;
            border-radius: var(--radius-md);
          }
          .music-hero-card {
            background: linear-gradient(135deg, rgba(20, 15, 35, 0.85) 0%, rgba(10, 14, 25, 0.95) 100%);
            border: 1px solid rgba(147, 51, 234, 0.35);
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6), 0 0 30px rgba(147, 51, 234, 0.15);
            backdrop-filter: blur(25px);
            border-radius: var(--radius-lg);
            padding: 2rem;
            display: grid;
            grid-template-columns: 240px 1fr;
            gap: 2.2rem;
            align-items: center;
            position: relative;
            overflow: hidden;
          }
          @media (max-width: 820px) {
            .music-hero-card { grid-template-columns: 1fr; justify-items: center; text-align: center; }
          }
          .music-art-wrap {
            position: relative;
            width: 210px;
            height: 210px;
            border-radius: 50%;
            padding: 8px;
            background: radial-gradient(circle, rgba(147, 51, 234, 0.4) 0%, rgba(6, 182, 212, 0.2) 60%, transparent 100%);
            box-shadow: 0 10px 30px rgba(0,0,0,0.7), 0 0 25px rgba(147, 51, 234, 0.3);
          }
          .music-vinyl {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(255, 255, 255, 0.15);
            transition: transform 0.5s ease;
          }
          .music-vinyl.spinning {
            animation: spinVinyl 12s linear infinite;
          }
          @keyframes spinVinyl {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
          .music-meta-col {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            width: 100%;
          }
          .music-track-title {
            font-size: 1.85rem;
            font-weight: 800;
            color: #fff;
            letter-spacing: -0.5px;
            line-height: 1.2;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
            word-break: break-word;
          }
          .music-track-artist {
            font-size: 1.05rem;
            color: var(--cyan);
            font-weight: 600;
          }
          .music-badges-row {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
            align-items: center;
          }
          .scrub-container {
            display: flex;
            flex-direction: column;
            gap: 0.4rem;
            width: 100%;
          }
          .scrub-slider {
            -webkit-appearance: none;
            width: 100%;
            height: 7px;
            border-radius: 4px;
            background: rgba(255, 255, 255, 0.12);
            outline: none;
            cursor: pointer;
            transition: background 0.2s;
          }
          .scrub-slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background: var(--cyan);
            box-shadow: 0 0 10px var(--cyan);
            cursor: pointer;
            transition: transform 0.15s ease;
          }
          .scrub-slider::-webkit-slider-thumb:hover {
            transform: scale(1.3);
          }
          .scrub-times {
            display: flex;
            justify-content: space-between;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.82rem;
            color: var(--text-muted);
          }
          .controls-cluster {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
          }
          .ctrl-btn {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.12);
            color: #fff;
            width: 44px;
            height: 44px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 1.15rem;
            transition: all 0.2s ease;
          }
          .ctrl-btn:hover {
            background: rgba(147, 51, 234, 0.3);
            border-color: var(--primary);
            transform: translateY(-2px);
          }
          .ctrl-btn.play-master {
            width: 58px;
            height: 58px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--cyan) 100%);
            border: none;
            box-shadow: 0 0 20px rgba(147, 51, 234, 0.5);
            font-size: 1.5rem;
          }
          .ctrl-btn.play-master:hover {
            transform: scale(1.08);
            box-shadow: 0 0 25px rgba(6, 182, 212, 0.6);
          }
          .ctrl-btn.active {
            border-color: var(--cyan);
            background: rgba(6, 182, 212, 0.25);
            color: var(--cyan);
          }
          .volume-bar-row {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            width: 100%;
            max-width: 380px;
          }
          .vol-chip {
            padding: 0.2rem 0.6rem;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: var(--radius-sm);
            font-size: 0.75rem;
            color: var(--text-muted);
            cursor: pointer;
            transition: all 0.15s;
          }
          .vol-chip:hover, .vol-chip.active {
            background: var(--primary);
            color: #fff;
            border-color: var(--primary);
          }
          .music-tabs-nav {
            display: flex;
            gap: 0.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            padding-bottom: 0.6rem;
            margin-top: 1rem;
            overflow-x: auto;
          }
          .m-tab-btn {
            background: transparent;
            border: none;
            color: var(--text-muted);
            padding: 0.6rem 1.2rem;
            border-radius: var(--radius-md);
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
          }
          .m-tab-btn:hover { color: #fff; background: rgba(255, 255, 255, 0.05); }
          .m-tab-btn.active {
            color: #fff;
            background: rgba(147, 51, 234, 0.25);
            border: 1px solid rgba(147, 51, 234, 0.4);
          }
          .music-tab-content { display: none; margin-top: 1.2rem; }
          .music-tab-content.active { display: block; }
          .queue-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: rgba(15, 17, 26, 0.65);
            border: 1px solid rgba(255, 255, 255, 0.07);
            border-radius: var(--radius-md);
            padding: 0.75rem 1rem;
            gap: 1rem;
            transition: all 0.15s ease;
          }
          .queue-item:hover {
            border-color: rgba(147, 51, 234, 0.4);
            background: rgba(147, 51, 234, 0.08);
          }
          .eq-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
            gap: 0.8rem;
          }
          .eq-card {
            background: rgba(15, 17, 26, 0.8);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: var(--radius-md);
            padding: 1rem 0.8rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s ease;
          }
          .eq-card:hover, .eq-card.active {
            border-color: var(--cyan);
            background: rgba(6, 182, 212, 0.18);
            box-shadow: 0 0 15px rgba(6, 182, 212, 0.3);
            transform: translateY(-2px);
          }
          #visualizer-canvas {
            width: 100%;
            height: 48px;
            border-radius: 6px;
            background: rgba(0, 0, 0, 0.35);
          }
        </style>

        <div class="music-shell">
          <!-- TOP BAR: GUILD SELECTOR & STATUS -->
          <div class="music-top-bar">
            <div style="display:flex; align-items:center; gap:0.9rem;">
              <span style="font-size:1.6rem;">🎧</span>
              <div>
                <div style="font-weight:800; color:#fff; font-size:1.15rem;">RAIVORA HI-FI MUSIC PLATFORM</div>
                <div style="font-size:0.8rem; color:var(--text-muted);">Independent 320kbps Opus Voice Engine • Rythm-Style Memory</div>
              </div>
            </div>

            <div style="display:flex; align-items:center; gap:0.8rem; flex-wrap:wrap;">
              <label style="font-size:0.82rem; color:var(--text-muted); font-weight:600;">ACTIVE SERVER:</label>
              <select id="music-guild-select" class="input-field" style="padding:0.45rem 0.8rem; min-width:210px;" onchange="onMusicGuildChanged(this.value)">
                <option value="1525030316845301781">THOR APEX ⚡ (Active)</option>
                <option value="1457382179981099090">✦ ʀᴀɪ ʀᴀᴍ ✦</option>
                <option value="1428058914141900860">ABIJITH 777</option>
                <option value="1494692962041467005">SUPPORT SERVER FOR RAIVORA</option>
              </select>
              <button class="btn btn-outline btn-sm" onclick="fetchMusicSessionState()" title="Instant Sync">⟳ Sync</button>
            </div>
          </div>

          <!-- HERO NOW PLAYING DECK -->
          <div class="music-hero-card">
            <div class="music-art-wrap">
              <img id="music-album-art" class="music-vinyl spinning" src="https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=500" alt="Album Cover">
            </div>

            <div class="music-meta-col">
              <div class="music-badges-row">
                <span class="pill pill-green" id="music-badge-state">🟢 PLAYING</span>
                <span class="pill pill-purple" id="music-badge-vc">📍 In #❄️. Fun Time !</span>
                <span class="pill pill-cyan" id="music-badge-filter">🎛️ Filter: Flat</span>
                <span class="pill pill-pink" id="music-badge-autodj">🎧 Auto-DJ: OFF</span>
              </div>

              <div>
                <div class="music-track-title" id="music-live-title">Innimey Ippadithaan - Paatha Oru Lookula Video</div>
                <div class="music-track-artist" id="music-live-artist">Santhanam, Ashna Zaveri • Neko Songs</div>
              </div>

              <!-- REALTIME CANVAS AUDIO VISUALIZER -->
              <canvas id="visualizer-canvas"></canvas>

              <!-- PROGRESS SLIDER -->
              <div class="scrub-container">
                <input type="range" id="music-scrub" class="scrub-slider" min="0" max="100" value="0" oninput="onMusicScrubInput()" onchange="onMusicScrubChange(this.value)">
                <div class="scrub-times">
                  <span id="music-time-elapsed">00:00</span>
                  <span id="music-time-total">00:00 (-00:00)</span>
                </div>
              </div>

              <!-- 13-BUTTON MASTER CONTROLS MATRIX -->
              <div class="controls-cluster">
                <button class="ctrl-btn" onclick="sendMusicAction('PREVIOUS')" title="Previous Track">⏮</button>
                <button class="ctrl-btn" onclick="sendMusicSeekRelative(-10)" title="Rewind 10s">⏪</button>
                <button class="ctrl-btn play-master" id="music-master-play-btn" onclick="toggleMusicPlayPause()" title="Play / Pause">▶</button>
                <button class="ctrl-btn" onclick="sendMusicSeekRelative(10)" title="Fast Forward 10s">⏩</button>
                <button class="ctrl-btn" onclick="sendMusicAction('SKIP')" title="Skip Current Song">⏭</button>

                <div style="width:1px; height:28px; background:rgba(255,255,255,0.15); margin:0 0.3rem;"></div>

                <button class="ctrl-btn" id="music-btn-shuffle" onclick="sendMusicAction('SHUFFLE')" title="Shuffle Queue">🔀</button>
                <button class="ctrl-btn" id="music-btn-loop" onclick="cycleMusicLoop()" title="Toggle Loop Mode">🔁</button>
                <button class="ctrl-btn" id="music-btn-favorite" onclick="toggleCurrentFavorite()" title="Add to Favorites" style="color:var(--pink);">❤️</button>
                <button class="ctrl-btn" onclick="openLyricsModal()" title="View Song Lyrics">💬</button>
                <button class="ctrl-btn" onclick="sendMusicAction('STOP')" title="Stop & Clear Voice Channel" style="color:var(--danger);">⏹</button>
              </div>

              <!-- REAL-TIME MASTER VOLUME BAR -->
              <div class="volume-bar-row">
                <span style="font-size:1.1rem;" id="music-vol-icon">🔊</span>
                <input type="range" id="music-vol-slider" class="scrub-slider" min="0" max="100" value="80" oninput="onMusicVolSlider(this.value)">
                <span style="font-family:'JetBrains Mono',monospace; font-size:0.85rem; width:45px;" id="music-vol-label">80%</span>
                <div style="display:flex; gap:0.3rem;">
                  <button class="vol-chip" onclick="setMusicVolumePreset(20)">20%</button>
                  <button class="vol-chip" onclick="setMusicVolumePreset(50)">50%</button>
                  <button class="vol-chip" onclick="setMusicVolumePreset(80)">80%</button>
                  <button class="vol-chip" onclick="setMusicVolumePreset(100)">100%</button>
                </div>
              </div>
            </div>
          </div>

          <!-- TABS NAVIGATION -->
          <div class="music-tabs-nav">
            <button class="m-tab-btn active" onclick="switchMusicTab('queue', this)">📜 Live Queue (<span id="tab-queue-count">0</span>)</button>
            <button class="m-tab-btn" onclick="switchMusicTab('eq', this)">🎛️ Equalizer & DSP</button>
            <button class="m-tab-btn" onclick="switchMusicTab('autodj', this)">🎧 Auto-DJ & 24/7 Radio</button>
            <button class="m-tab-btn" onclick="switchMusicTab('history', this)">🕒 Listening History</button>
            <button class="m-tab-btn" onclick="switchMusicTab('favorites', this)">❤️ My Favorites</button>
            <button class="m-tab-btn" onclick="switchMusicTab('health', this)">🩺 Bot Health & Telemetry</button>
          </div>

          <!-- TAB 1: LIVE QUEUE & SEARCH -->
          <div class="music-tab-content active" id="mtab-queue">
            <!-- QUICK ENQUEUE SEARCH BAR -->
            <div style="display:flex; gap:0.8rem; margin-bottom:1.5rem;">
              <input type="text" id="music-search-input" class="input-field" style="flex:1;" placeholder="Search YouTube or paste URL (e.g. Kaappaan - Hey Amigo, Spotify, Soundcloud)..." onkeydown="if(event.key==='Enter') quickEnqueueTrack()">
              <button class="btn btn-primary" onclick="quickEnqueueTrack()"><span>+</span> Add to Queue</button>
            </div>

            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
              <div style="font-size:0.9rem; color:var(--text-muted);" id="queue-summary-text">0 tracks queued • Total duration: 0m</div>
              <button class="btn btn-outline btn-sm" onclick="sendMusicAction('CLEAR')" style="color:var(--danger); border-color:rgba(239,68,68,0.4);">Clear Queue</button>
            </div>

            <div id="queue-items-list" style="display:flex; flex-direction:column; gap:0.6rem;">
              <div class="state-box"><div class="state-desc">Loading live queue...</div></div>
            </div>
          </div>

          <!-- TAB 2: EQUALIZER & DSP SUITE -->
          <div class="music-tab-content" id="mtab-eq">
            <div class="section-title">
              <span class="title-text">🎛️ 10-Band DSP Equalizer Presets</span>
              <span class="pill pill-cyan">REAL-TIME HOT SWAP</span>
            </div>
            <p style="color:var(--text-muted); font-size:0.88rem; margin-bottom:1.4rem;">
              Click any DSP filter to switch audio profiles without interrupting the track.
            </p>

            <div class="eq-grid">
              <div class="eq-card active" onclick="applyMusicEQ('flat', 'Flat / Normal', this)">
                <div style="font-size:1.8rem; margin-bottom:0.4rem;">🔄</div>
                <div style="font-weight:700; color:#fff; font-size:0.9rem;">Flat / Normal</div>
                <div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.2rem;">Studio Neutral</div>
              </div>
              <div class="eq-card" onclick="applyMusicEQ('bassboost', 'Bass Boost', this)">
                <div style="font-size:1.8rem; margin-bottom:0.4rem;">🎧</div>
                <div style="font-weight:700; color:#fff; font-size:0.9rem;">Bass Boost</div>
                <div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.2rem;">+10dB Sub-60Hz</div>
              </div>
              <div class="eq-card" onclick="applyMusicEQ('nightcore', 'Nightcore', this)">
                <div style="font-size:1.8rem; margin-bottom:0.4rem;">⚡</div>
                <div style="font-weight:700; color:#fff; font-size:0.9rem;">Nightcore</div>
                <div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.2rem;">1.25x Pitch & Speed</div>
              </div>
              <div class="eq-card" onclick="applyMusicEQ('8d', '8D Audio', this)">
                <div style="font-size:1.8rem; margin-bottom:0.4rem;">🌌</div>
                <div style="font-weight:700; color:#fff; font-size:0.9rem;">8D Audio</div>
                <div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.2rem;">Pulsating 360° Pan</div>
              </div>
              <div class="eq-card" onclick="applyMusicEQ('vaporwave', 'Lo-Fi Relax', this)">
                <div style="font-size:1.8rem; margin-bottom:0.4rem;">☕</div>
                <div style="font-weight:700; color:#fff; font-size:0.9rem;">Lo-Fi Relax</div>
                <div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.2rem;">0.85x Warm Chill</div>
              </div>
              <div class="eq-card" onclick="applyMusicEQ('vocal', 'Clear Vocal', this)">
                <div style="font-size:1.8rem; margin-bottom:0.4rem;">🎤</div>
                <div style="font-weight:700; color:#fff; font-size:0.9rem;">Clear Vocal</div>
                <div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.2rem;">+6dB Midrange</div>
              </div>
              <div class="eq-card" onclick="applyMusicEQ('rock', 'Rock / Metal', this)">
                <div style="font-size:1.8rem; margin-bottom:0.4rem;">🎸</div>
                <div style="font-weight:700; color:#fff; font-size:0.9rem;">Rock / Metal</div>
                <div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.2rem;">Punchy V-Curve</div>
              </div>
              <div class="eq-card" onclick="applyMusicEQ('pop', 'Pop Boost', this)">
                <div style="font-size:1.8rem; margin-bottom:0.4rem;">✨</div>
                <div style="font-weight:700; color:#fff; font-size:0.9rem;">Pop Boost</div>
                <div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.2rem;">Highs & Presence</div>
              </div>
            </div>
          </div>

          <!-- TAB 3: AUTO-DJ & 24/7 RADIO -->
          <div class="music-tab-content" id="mtab-autodj">
            <div class="section-title">
              <span class="title-text">🎧 Autonomous Auto-DJ & Circadian Radio</span>
              <span class="pill pill-green">AI VIBE ENGINE</span>
            </div>
            <p style="color:var(--text-muted); font-size:0.88rem; margin-bottom:1.4rem;">
              When the manual queue empties, Auto-DJ keeps the music going with diverse, non-repeating recommendations.
            </p>

            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:1.2rem;">
              <div class="card" style="padding:1.4rem;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.8rem;">
                  <span style="font-weight:700; color:#fff; font-size:1.05rem;">Auto-DJ Non-Stop</span>
                  <span class="pill pill-cyan">Continuous</span>
                </div>
                <p style="font-size:0.82rem; color:var(--text-muted); margin-bottom:1.2rem; line-height:1.5;">
                  Uses algorithmic audio vectors to recommend tracks based on recent history with zero repetition.
                </p>
                <button class="btn btn-primary btn-sm" onclick="sendMusicAction('AUTODJ_TOGGLE')">Toggle Auto-DJ Mode</button>
              </div>

              <div class="card" style="padding:1.4rem;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.8rem;">
                  <span style="font-weight:700; color:#fff; font-size:1.05rem;">24/7 Voice Channel Anchor</span>
                  <span class="pill pill-purple">Always Connected</span>
                </div>
                <p style="font-size:0.82rem; color:var(--text-muted); margin-bottom:1.2rem; line-height:1.5;">
                  The bot remains in the voice channel permanently, resuming automatically even after bot restarts.
                </p>
                <button class="btn btn-outline btn-sm" onclick="sendMusicAction('247_TOGGLE')">Toggle 24/7 Mode</button>
              </div>
            </div>
          </div>

          <!-- TAB 4: LISTENING HISTORY -->
          <div class="music-tab-content" id="mtab-history">
            <div class="section-title">
              <span class="title-text">🕒 Server Playback History</span>
              <span class="pill pill-cyan">LAST 25 TRACKS</span>
            </div>
            <div id="history-items-list" style="display:flex; flex-direction:column; gap:0.6rem; margin-top:1rem;">
              <div class="state-box"><div class="state-desc">Loading playback history...</div></div>
            </div>
          </div>

          <!-- TAB 5: MY FAVORITES -->
          <div class="music-tab-content" id="mtab-favorites">
            <div class="section-title">
              <span class="title-text">❤️ Saved Favorites</span>
              <span class="pill pill-pink">PERSONAL PLAYLIST</span>
            </div>
            <div id="favorites-items-list" style="display:flex; flex-direction:column; gap:0.6rem; margin-top:1rem;">
              <div class="state-box"><div class="state-desc">Loading personal favorites...</div></div>
            </div>
          </div>

          <!-- TAB 6: BOT HEALTH & TELEMETRY -->
          <div class="music-tab-content" id="mtab-health">
            <div class="section-title">
              <span class="title-text">🩺 Audio Engine Health & Observability</span>
              <span class="pill pill-green">SELF-HEALING</span>
            </div>
            <div class="discovery-grid" id="telemetry-grid">
              <div class="discovery-card">
                <div class="card-name">Gateway Latency</div>
                <div style="font-size:2rem; font-weight:800; color:var(--cyan); margin:0.4rem 0;" id="stat-latency">18ms</div>
                <div class="card-desc">Zero packet-loss connection to Discord Mumbai/Singapore voice gateways.</div>
              </div>
              <div class="discovery-card">
                <div class="card-name">Audio Decoder</div>
                <div style="font-size:1.1rem; font-weight:700; color:#fff; margin:0.4rem 0;">FFmpeg 9.0 + PyNaCl</div>
                <div class="card-desc">Lossless 320kbps stereo PCM frames validated before output.</div>
              </div>
              <div class="discovery-card">
                <div class="card-name">yt-dlp Extractor Engine</div>
                <div style="font-size:1.1rem; font-weight:700; color:var(--emerald); margin:0.4rem 0;">v2026.08.19 (Patched)</div>
                <div class="card-desc">Autonomous background updater active with Node.js EJS challenge solver.</div>
              </div>
              <div class="discovery-card">
                <div class="card-name">Session Resilience</div>
                <div style="font-size:1.1rem; font-weight:700; color:var(--pink); margin:0.4rem 0;">Rythm-Style WAL Memory</div>
                <div class="card-desc">Persisted to SQLite WAL for zero-loss recovery across bot restarts.</div>
              </div>
            </div>
          </div>
        </div>
      `;

      initVisualizer();
      await loadMusicGuilds();
      await fetchMusicSessionState();
      await fetchMusicQueue();

      // Launch real-time background sync loop every 1.5 seconds
      musicPollInterval = setInterval(fetchMusicSessionState, 1500);
    }

    // ==========================================
    // AUDIO VISUALIZER CANVAS ANIMATION
    // ==========================================
    function initVisualizer() {
      const canvas = document.getElementById('visualizer-canvas');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      canvas.width = canvas.parentElement.clientWidth || 600;
      canvas.height = 48;

      let bars = Array.from({ length: 48 }, () => Math.random() * 0.4);

      function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        const isPlaying = currentMusicSession && currentMusicSession.is_playing;
        const barWidth = canvas.width / bars.length;

        for (let i = 0; i < bars.length; i++) {
          if (isPlaying) {
            bars[i] = Math.max(0.1, Math.min(1.0, bars[i] + (Math.random() - 0.48) * 0.25));
          } else {
            bars[i] = Math.max(0.05, bars[i] * 0.95);
          }

          const h = bars[i] * canvas.height * 0.85;
          const x = i * barWidth;
          const y = canvas.height - h;

          const grad = ctx.createLinearGradient(0, y, 0, canvas.height);
          grad.addColorStop(0, '#06b6d4');
          grad.addColorStop(1, '#9333ea');

          ctx.fillStyle = grad;
          ctx.fillRect(x + 1, y, barWidth - 2, h);
        }
        visualizerAnimId = requestAnimationFrame(draw);
      }
      draw();
    }

    // ==========================================
    // CLIENT MUSIC CONTROLLERS & DATA FETCHING
    // ==========================================
    async function loadMusicGuilds() {
      try {
        const res = await fetch('/api/music/guilds');
        const json = await res.json();
        if (json.success && json.data.guilds) {
          const select = document.getElementById('music-guild-select');
          if (select) {
            select.innerHTML = json.data.guilds.map(g => `
              <option value="${g.id}" ${g.id === selectedMusicGuildId ? 'selected' : ''}>
                ${g.name} ${g.has_active_playback ? '🟢 (Playing)' : ''}
              </option>
            `).join('');
          }
        }
      } catch (e) {}
    }

    function onMusicGuildChanged(guildId) {
      selectedMusicGuildId = guildId;
      fetchMusicSessionState();
      fetchMusicQueue();
    }

    async function fetchMusicSessionState() {
      try {
        const res = await fetch('/api/music/session?guild_id=' + selectedMusicGuildId);
        const json = await res.json();
        if (!json.success || !json.data) return;

        const data = json.data;
        currentMusicSession = data;

        const titleEl = document.getElementById('music-live-title');
        const artistEl = document.getElementById('music-live-artist');
        const artEl = document.getElementById('music-album-art');
        const badgeState = document.getElementById('music-badge-state');
        const badgeVc = document.getElementById('music-badge-vc');
        const badgeFilter = document.getElementById('music-badge-filter');
        const badgeAutodj = document.getElementById('music-badge-autodj');
        const playBtn = document.getElementById('music-master-play-btn');
        const scrub = document.getElementById('music-scrub');
        const elapsedEl = document.getElementById('music-time-elapsed');
        const totalEl = document.getElementById('music-time-total');
        const volSlider = document.getElementById('music-vol-slider');
        const volLabel = document.getElementById('music-vol-label');
        const tabQueueCount = document.getElementById('tab-queue-count');

        if (data.current_track) {
          if (titleEl) titleEl.innerText = data.current_track.title;
          if (artistEl) artistEl.innerText = `${data.current_track.artist || 'Unknown'} • Req by ${data.current_track.requester_name || 'User'}`;
          if (artEl && data.current_track.thumbnail) artEl.src = data.current_track.thumbnail;
        } else {
          if (titleEl) titleEl.innerText = 'Queue is finished / Idle';
          if (artistEl) artistEl.innerText = 'Use search bar below or /music play to queue audio';
        }

        if (badgeState) {
          badgeState.innerText = data.is_playing ? '🟢 PLAYING' : (data.is_paused ? '⏸️ PAUSED' : '⏹️ IDLE');
          badgeState.className = data.is_playing ? 'pill pill-green' : (data.is_paused ? 'pill pill-cyan' : 'pill pill-purple');
        }
        if (badgeVc) badgeVc.innerText = data.voice_channel_name ? `📍 In ${data.voice_channel_name}` : '📍 Voice Not Connected';
        if (badgeFilter) badgeFilter.innerText = `🎛️ Filter: ${data.eq_preset || 'Flat'}`;
        if (badgeAutodj) badgeAutodj.innerText = `🎧 Auto-DJ: ${data.auto_dj ? 'ON' : 'OFF'}`;

        if (artEl) {
          if (data.is_playing) artEl.classList.add('spinning');
          else artEl.classList.remove('spinning');
        }

        if (playBtn) playBtn.innerHTML = data.is_playing ? '⏸' : '▶';

        if (!isScrubbingMusic && scrub && data.duration_seconds > 0) {
          scrub.max = data.duration_seconds;
          scrub.value = data.position_seconds;
          if (elapsedEl) elapsedEl.innerText = formatTimeSec(data.position_seconds);
          if (totalEl) totalEl.innerText = `${formatTimeSec(data.duration_seconds)} (-${formatTimeSec(data.remaining_seconds)})`;
        }

        if (volSlider && !document.activeElement?.isSameNode(volSlider)) {
          volSlider.value = data.volume;
          if (volLabel) volLabel.innerText = data.volume + '%';
        }

        if (tabQueueCount) tabQueueCount.innerText = data.queue_count || 0;

        const loopBtn = document.getElementById('music-btn-loop');
        if (loopBtn) {
          loopBtn.className = 'ctrl-btn' + (data.loop_mode !== 'off' ? ' active' : '');
          loopBtn.title = `Loop: ${data.loop_mode.toUpperCase()}`;
        }
      } catch (e) {}
    }

    async function fetchMusicQueue() {
      try {
        const res = await fetch('/api/music/queue?guild_id=' + selectedMusicGuildId);
        const json = await res.json();
        const list = document.getElementById('queue-items-list');
        const summary = document.getElementById('queue-summary-text');
        if (!list) return;

        if (json.success && json.data.tracks && json.data.tracks.length > 0) {
          const tracks = json.data.tracks;
          if (summary) summary.innerText = `${tracks.length} tracks queued • Total playtime: ${formatTimeSec(json.data.total_duration)}`;
          list.innerHTML = tracks.map(t => `
            <div class="queue-item">
              <div style="display:flex; align-items:center; gap:0.9rem;">
                <span style="font-family:'JetBrains Mono',monospace; font-weight:700; color:var(--text-muted); width:24px;">#${t.index + 1}</span>
                <img src="${t.thumbnail || 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=100'}" style="width:42px; height:42px; border-radius:6px; object-fit:cover;" alt="Thumb">
                <div>
                  <div style="font-weight:700; color:#fff; font-size:0.92rem;">${t.title}</div>
                  <div style="font-size:0.78rem; color:var(--text-muted);">${t.artist || 'Unknown'} • Req by ${t.requester_name || 'User'}</div>
                </div>
              </div>
              <div style="display:flex; align-items:center; gap:0.8rem;">
                <span style="font-family:'JetBrains Mono',monospace; font-size:0.82rem; color:var(--cyan);">${formatTimeSec(t.duration)}</span>
                <button class="btn btn-outline btn-sm" onclick="sendMusicRemoveTrack(${t.index})" style="padding:0.25rem 0.5rem; color:var(--danger); border-color:rgba(239,68,68,0.3);">✕</button>
              </div>
            </div>
          `).join('');
        } else {
          if (summary) summary.innerText = '0 tracks queued • Queue is currently empty';
          list.innerHTML = `
            <div class="state-box" style="padding:2.5rem 1rem;">
              <div style="font-size:2rem; margin-bottom:0.5rem;">🐾</div>
              <div class="state-title">Queue is Empty</div>
              <div class="state-desc">Give Neko another song! Type in the box above or use /music play in Discord.</div>
            </div>
          `;
        }
      } catch (e) {}
    }

    async function sendMusicAction(action, payload = {}) {
      try {
        const res = await fetch('/api/music/control', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            guild_id: selectedMusicGuildId,
            action: action,
            payload: payload
          })
        });
        const json = await res.json();
        if (json.success) {
          setTimeout(() => {
            fetchMusicSessionState();
            fetchMusicQueue();
          }, 350);
        } else {
          alert('Action error: ' + (json.error?.message || 'Failed'));
        }
      } catch (err) {
        alert('Communication error: ' + err);
      }
    }

    function toggleMusicPlayPause() {
      if (!currentMusicSession) return;
      if (currentMusicSession.is_playing) sendMusicAction('PAUSE');
      else sendMusicAction('RESUME');
    }

    function sendMusicSeekRelative(deltaSec) {
      if (!currentMusicSession) return;
      const target = Math.max(0, (currentMusicSession.position_seconds || 0) + deltaSec);
      sendMusicAction('SEEK', { seconds: target });
    }

    function onMusicScrubInput() {
      isScrubbingMusic = true;
    }

    function onMusicScrubChange(val) {
      isScrubbingMusic = false;
      sendMusicAction('SEEK', { seconds: parseInt(val, 10) });
    }

    function onMusicVolSlider(val) {
      const label = document.getElementById('music-vol-label');
      if (label) label.innerText = val + '%';
      sendMusicAction('VOLUME', { volume: parseInt(val, 10) });
    }

    function setMusicVolumePreset(val) {
      const slider = document.getElementById('music-vol-slider');
      if (slider) slider.value = val;
      onMusicVolSlider(val);
    }

    function cycleMusicLoop() {
      if (!currentMusicSession) return;
      const current = currentMusicSession.loop_mode || 'off';
      let next = 'off';
      if (current === 'off') next = 'track';
      else if (current === 'track') next = 'queue';
      else next = 'off';
      sendMusicAction('LOOP', { mode: next });
    }

    function applyMusicEQ(presetKey, displayName, cardEl) {
      document.querySelectorAll('.eq-card').forEach(c => c.classList.remove('active'));
      if (cardEl) cardEl.classList.add('active');
      sendMusicAction('FILTER', { preset: presetKey, name: displayName });
    }

    async function quickEnqueueTrack() {
      const inp = document.getElementById('music-search-input');
      if (!inp || !inp.value.trim()) return;
      const query = inp.value.trim();
      inp.value = '';
      await fetch('/api/music/enqueue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guild_id: selectedMusicGuildId, query: query })
      });
      setTimeout(() => {
        fetchMusicSessionState();
        fetchMusicQueue();
      }, 500);
    }

    function sendMusicRemoveTrack(idx) {
      sendMusicAction('REMOVE', { index: idx });
    }

    async function toggleCurrentFavorite() {
      if (!currentMusicSession || !currentMusicSession.current_track) return;
      const t = currentMusicSession.current_track;
      const res = await fetch('/api/music/favorites/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(t)
      });
      const json = await res.json();
      if (json.success) alert(json.data.message);
    }

    async function openLyricsModal() {
      if (!currentMusicSession || !currentMusicSession.current_track) {
        alert('No track is currently playing.');
        return;
      }
      const t = currentMusicSession.current_track;
      openModal(`💬 Lyrics: ${t.title}`, `
        <div style="padding:1rem; text-align:center; color:var(--text-muted);">Fetching synchronized lyrics...</div>
      `);
      try {
        const res = await fetch(`/api/music/lyrics?title=${encodeURIComponent(t.title)}&artist=${encodeURIComponent(t.artist || '')}`);
        const json = await res.json();
        const bodyEl = document.getElementById('modal-body');
        if (bodyEl && json.success) {
          bodyEl.innerHTML = `
            <pre style="white-space:pre-wrap; font-family:'Outfit',sans-serif; font-size:0.95rem; line-height:1.7; color:#fff; max-height:450px; overflow-y:auto; padding:0.5rem;">${json.data.lyrics}</pre>
          `;
        }
      } catch (e) {}
    }

    function switchMusicTab(tabName, btnEl) {
      document.querySelectorAll('.m-tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.music-tab-content').forEach(c => c.classList.remove('active'));
      if (btnEl) btnEl.classList.add('active');
      const target = document.getElementById('mtab-' + tabName);
      if (target) target.classList.add('active');

      if (tabName === 'history') loadMusicHistory();
      if (tabName === 'favorites') loadMusicFavorites();
      if (tabName === 'health') loadMusicHealth();
    }

    async function loadMusicHistory() {
      const container = document.getElementById('history-items-list');
      if (!container) return;
      try {
        const res = await fetch('/api/music/history?guild_id=' + selectedMusicGuildId);
        const json = await res.json();
        if (json.success && json.data.history && json.data.history.length > 0) {
          container.innerHTML = json.data.history.map(t => `
            <div class="queue-item">
              <div>
                <div style="font-weight:700; color:#fff; font-size:0.92rem;">${t.title}</div>
                <div style="font-size:0.78rem; color:var(--text-muted);">${t.artist || 'Unknown'} • Req by ${t.requester_name || 'User'}</div>
              </div>
              <div style="display:flex; align-items:center; gap:0.8rem;">
                <span style="font-family:'JetBrains Mono',monospace; font-size:0.82rem; color:var(--cyan);">${formatTimeSec(t.duration)}</span>
                <button class="btn btn-primary btn-sm" onclick="quickReplayHistory('${t.url || t.title}')">Play Again</button>
              </div>
            </div>
          `).join('');
        } else {
          container.innerHTML = `<div class="state-box"><div class="state-desc">No playback history recorded yet.</div></div>`;
        }
      } catch (e) {}
    }

    async function quickReplayHistory(query) {
      await fetch('/api/music/enqueue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guild_id: selectedMusicGuildId, query: query })
      });
      setTimeout(() => {
        fetchMusicSessionState();
        fetchMusicQueue();
      }, 500);
    }

    async function loadMusicFavorites() {
      const container = document.getElementById('favorites-items-list');
      if (!container) return;
      try {
        const res = await fetch('/api/music/favorites');
        const json = await res.json();
        if (json.success && json.data && json.data.length > 0) {
          container.innerHTML = json.data.map(f => `
            <div class="queue-item">
              <div>
                <div style="font-weight:700; color:#fff; font-size:0.92rem;">${f.title}</div>
                <div style="font-size:0.78rem; color:var(--text-muted);">${f.artist || 'Unknown'}</div>
              </div>
              <button class="btn btn-primary btn-sm" onclick="quickReplayHistory('${f.url}')">Queue Track</button>
            </div>
          `).join('');
        } else {
          container.innerHTML = `<div class="state-box"><div class="state-desc">No favorites saved yet. Click ❤️ on the now playing bar to save tracks!</div></div>`;
        }
      } catch (e) {}
    }

    async function loadMusicHealth() {
      try {
        const res = await fetch('/api/music/stats');
        const json = await res.json();
        if (json.success && json.data) {
          const latEl = document.getElementById('stat-latency');
          if (latEl) latEl.innerText = `${json.data.gateway_latency_ms}ms`;
        }
      } catch (e) {}
    }

    function formatTimeSec(sec) {
      if (!sec || isNaN(sec) || sec <= 0) return '00:00';
      const m = Math.floor(sec / 60);
      const s = Math.floor(sec % 60);
      return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
    }

    // ==========================================
    // 21. MEDIA VIEW (/media)
    // ==========================================
    function renderMedia(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">🎬 Media Hub & Watch Parties</span>
            <span class="pill pill-pink">CINEMA VC</span>
          </div>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem;">
          Community watch parties, anime discussions, and movie nights. All streams point to authorized external platforms.
        </p>
        <div class="discovery-grid">
          <div class="discovery-card">
            <div>
              <div class="card-name">Weekend Anime Watch Party</div>
              <div class="card-subtitle">WEEKLY EVENT</div>
              <div class="card-desc" style="margin-top:0.6rem;">Community watch party every Saturday evening in Discord Cinema VC.</div>
            </div>
            <div class="card-bottom-actions">
              <a href="https://discord.gg/raivora" target="_blank" class="btn btn-discord btn-sm" style="width:100%;">Join Cinema VC</a>
            </div>
          </div>
        </div>
      `;
    }

    // ==========================================
    // 22. RESOURCES VIEW (/resources)
    // ==========================================
    async function renderResources(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">📚 Resource Library</span>
            <span class="pill pill-cyan">LUTs & ASSETS</span>
          </div>
          <button class="btn btn-primary btn-sm" onclick="openSubmitResourceModal()">+ Submit Resource</button>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem;">
          Verified editing assets, color grading LUTs, production sound packs, and community guides.
        </p>
        <div class="discovery-grid" id="resources-page-grid"><div class="skeleton-card"></div></div>
      `;

      try {
        const res = await fetch('/api/resources');
        const data = await res.json();
        const grid = document.getElementById('resources-page-grid');
        if (data.success && data.data && data.data.length > 0) {
          grid.innerHTML = data.data.map(r => `
            <div class="discovery-card">
              <div>
                <div class="card-name">${r.title}</div>
                <div class="card-subtitle">${r.category.toUpperCase()}</div>
                <div class="card-desc" style="margin-top:0.6rem;">${r.description || 'Verified resource download.'}</div>
              </div>
              <div class="card-bottom-actions">
                ${r.link ? `<a href="${r.link}" target="_blank" class="btn btn-outline btn-sm" style="flex:1;">Get Link ↗</a>` : ''}
                <button class="btn btn-outline btn-sm" onclick="toggleSaveItem('resource', '${r.id}', '${r.title}', '${r.category}')">🔖</button>
              </div>
            </div>
          `).join('');
        } else {
          grid.innerHTML = `<div class="state-box" style="grid-column:1/-1;"><div class="state-title">No resources submitted yet.</div></div>`;
        }
      } catch (e) {}
    }

    function openSubmitResourceModal() {
      if (!currentUser) { alert('Please sign in to submit resources.'); openLoginModal(); return; }
      openModal('Submit Community Resource', `
        <form onsubmit="submitResource(event)">
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Title</label>
            <input type="text" id="res-title" class="input-field" style="width:100%;" placeholder="e.g. Cyberpunk Color Grade LUT Pack" required>
          </div>
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Category</label>
            <select id="res-cat" class="input-field" style="width:100%;">
              <option value="Editing">Video Editing / LUTs</option>
              <option value="Audio">Audio / SFX Pack</option>
              <option value="Design">Design / Presets</option>
              <option value="Guide">Tutorial / Guide</option>
            </select>
          </div>
          <div style="margin-bottom:1.5rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">External Resource Link</label>
            <input type="url" id="res-link" class="input-field" style="width:100%;" placeholder="https://..." required>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;">Submit Resource</button>
        </form>
      `);
    }

    async function submitResource(e) {
      e.preventDefault();
      const title = document.getElementById('res-title').value.trim();
      const category = document.getElementById('res-cat').value;
      const link = document.getElementById('res-link').value.trim();
      const res = await fetch('/api/resources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, category, link, description: 'Community submitted resource' })
      });
      const data = await res.json();
      if (data.success) {
        closeModal();
        navigate('/resources');
      } else alert(data.error?.message || 'Could not submit resource');
    }

    // ==========================================
    // 23. EVENTS VIEW (/events)
    // ==========================================
    async function renderEvents(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">📅 Community Events Calendar</span>
            <span class="pill pill-pink">TOURNAMENTS & WORKSHOPS</span>
          </div>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem;">
          RSVP to competitive gaming brackets, editing workshops, and community listening parties.
        </p>
        <div class="discovery-grid" id="events-page-grid"><div class="skeleton-card"></div></div>
      `;

      try {
        const res = await fetch('/api/events');
        const data = await res.json();
        const grid = document.getElementById('events-page-grid');
        if (data.success && data.data && data.data.length > 0) {
          grid.innerHTML = data.data.map(ev => `
            <div class="discovery-card">
              <div>
                <div class="card-name">${ev.title}</div>
                <div class="card-subtitle">${ev.event_type.toUpperCase()}</div>
                <div class="card-desc" style="margin-top:0.6rem;">${ev.description || 'Scheduled event in Discord.'}</div>
                <div class="card-tags">
                  <span class="pill pill-pink">${ev.status.toUpperCase()}</span>
                  <span class="tag-badge">Starts: ${ev.start_time.split('T')[0]}</span>
                </div>
              </div>
              <div class="card-bottom-actions">
                <button class="btn btn-outline btn-sm" style="flex:1;" onclick="rsvpEvent(${ev.id})">RSVP Interested</button>
                <a href="https://discord.gg/raivora" target="_blank" class="btn btn-discord btn-sm" style="flex:1;">Join Discord</a>
              </div>
            </div>
          `).join('');
        } else {
          grid.innerHTML = `<div class="state-box" style="grid-column:1/-1;"><div class="state-title">No upcoming events scheduled right now.</div></div>`;
        }
      } catch (e) {}
    }

    async function rsvpEvent(evId) {
      if (!currentUser) { alert('Please sign in to RSVP.'); openLoginModal(); return; }
      const res = await fetch(`/api/events/${evId}/rsvp`, { method: 'POST' });
      const data = await res.json();
      if (data.success) alert('RSVP confirmed! Event reminder saved to your profile.');
      else alert(data.error?.message || 'Could not RSVP');
    }

    // ==========================================
    // 24. IDEAS VIEW (/ideas)
    // ==========================================
    async function renderIdeas(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">💡 Ideas & Feature Incubator</span>
            <span class="pill pill-purple">COMMUNITY ROADMAP</span>
          </div>
          <button class="btn btn-primary btn-sm" onclick="openSubmitIdeaModal()">+ Suggest Idea</button>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem;">
          Propose and upvote features, discord bots, tournament ideas, and tools.
        </p>
        <div class="discovery-grid" id="ideas-page-grid"><div class="skeleton-card"></div></div>
      `;

      try {
        const res = await fetch('/api/ideas');
        const data = await res.json();
        const grid = document.getElementById('ideas-page-grid');
        if (data.success && data.data && data.data.length > 0) {
          grid.innerHTML = data.data.map(i => `
            <div class="discovery-card">
              <div>
                <div class="card-name">${i.title}</div>
                <div class="card-subtitle">${i.category.toUpperCase()} • ${i.status.toUpperCase()}</div>
                <div class="card-desc" style="margin-top:0.6rem;">${i.description}</div>
              </div>
              <div class="card-bottom-actions">
                <button class="btn btn-outline btn-sm" style="flex:1;" onclick="upvoteIdea(${i.id})">▲ Upvote (${i.upvotes || 0})</button>
                <button class="btn btn-outline btn-sm" onclick="toggleSaveItem('idea', '${i.id}', '${i.title}', '${i.category}')">🔖</button>
              </div>
            </div>
          `).join('');
        } else {
          grid.innerHTML = `<div class="state-box" style="grid-column:1/-1;"><div class="state-title">No ideas submitted yet. Be the first!</div></div>`;
        }
      } catch (e) {}
    }

    function openSubmitIdeaModal() {
      if (!currentUser) { alert('Please sign in to suggest ideas.'); openLoginModal(); return; }
      openModal('Suggest Community Feature or Idea', `
        <form onsubmit="submitIdea(event)">
          <div style="margin-bottom:1rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Title</label>
            <input type="text" id="idea-title" class="input-field" style="width:100%;" placeholder="e.g. Automated Tournament Bracket Generator" required>
          </div>
          <div style="margin-bottom:1.5rem;">
            <label style="font-size:0.85rem; color:var(--text-muted); display:block; margin-bottom:0.4rem;">Description</label>
            <textarea id="idea-desc" class="input-field" style="width:100%; height:90px;" placeholder="Explain your proposal..." required></textarea>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;">Submit Proposal</button>
        </form>
      `);
    }

    async function submitIdea(e) {
      e.preventDefault();
      const title = document.getElementById('idea-title').value.trim();
      const description = document.getElementById('idea-desc').value.trim();
      const res = await fetch('/api/ideas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, description, category: 'Feature' })
      });
      const data = await res.json();
      if (data.success) {
        closeModal();
        navigate('/ideas');
      } else alert(data.error?.message || 'Could not submit proposal');
    }

    async function upvoteIdea(ideaId) {
      if (!currentUser) { alert('Please sign in to vote.'); openLoginModal(); return; }
      const res = await fetch(`/api/ideas/${ideaId}/vote`, { method: 'POST' });
      const data = await res.json();
      if (data.success) renderIdeas(document.getElementById('view-container'));
      else alert(data.error?.message || 'Voting failed');
    }

    // ==========================================
    // 25. LABS VIEW (/labs)
    // ==========================================
    async function renderLabs(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">🔬 Rai Labs & Community Constellation</span>
            <span class="pill pill-purple">EXPERIMENTAL</span>
          </div>
        </div>
        <p style="color:var(--text-muted); margin-bottom:1.8rem; line-height:1.6;">
          Interactive relational constellation connecting community projects, verified creators, and events.
        </p>

        <div style="background:rgba(10,12,20,0.85); border:1px solid rgba(147,51,234,0.35); border-radius:var(--radius-lg); height:420px; display:flex; align-items:center; justify-content:center; position:relative; overflow:hidden;" id="constellation-canvas-container">
          <canvas id="labs-graph" width="800" height="400" style="width:100%; height:100%;"></canvas>
        </div>
      `;

      loadConstellationGraph();
    }

    async function loadConstellationGraph() {
      try {
        const res = await fetch('/api/labs/constellation');
        const data = await res.json();
        const canvas = document.getElementById('labs-graph');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const nodes = (data.success && data.data.nodes) ? data.data.nodes : [];
        const links = (data.success && data.data.links) ? data.data.links : [];

        // Render force graph simulation visually
        const cw = canvas.width;
        const ch = canvas.height;
        const nodeMap = {};

        nodes.forEach((n, idx) => {
          const angle = (idx / nodes.length) * Math.PI * 2;
          const radius = (n.group === 'core') ? 0 : ((n.group === 'hub') ? 80 : 140);
          n.x = cw / 2 + Math.cos(angle) * radius + (Math.random() - 0.5) * 20;
          n.y = ch / 2 + Math.sin(angle) * radius + (Math.random() - 0.5) * 20;
          nodeMap[n.id] = n;
        });

        function drawGraph() {
          ctx.clearRect(0, 0, cw, ch);

          // Draw links
          ctx.lineWidth = 1;
          for (let l of links) {
            const s = nodeMap[l.source];
            const t = nodeMap[l.target];
            if (s && t) {
              ctx.beginPath();
              ctx.moveTo(s.x, s.y);
              ctx.lineTo(t.x, t.y);
              ctx.strokeStyle = 'rgba(147, 51, 234, 0.25)';
              ctx.stroke();
            }
          }

          // Draw nodes
          for (let n of nodes) {
            ctx.beginPath();
            ctx.arc(n.x, n.y, n.size ? n.size / 2 : 7, 0, Math.PI * 2);
            ctx.fillStyle = (n.group === 'core') ? '#a855f7' : ((n.group === 'hub') ? '#06b6d4' : '#ec4899');
            ctx.fill();

            ctx.font = '10px Outfit';
            ctx.fillStyle = '#fff';
            ctx.textAlign = 'center';
            ctx.fillText(n.label, n.x, n.y - 10);
          }
        }
        drawGraph();
      } catch (e) {}
    }

    // ==========================================
    // 26. STATUS VIEW (/status)
    // ==========================================
    async function renderStatus(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">🩺 Subsystem Supervision & Truthful Telemetry</span>
            <span class="pill pill-green">LIVE SUPERVISION</span>
          </div>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem;">
          Truthful telemetry reports from the Rai Doctor supervisor matrix. Zero fabricated uptime.
        </p>

        <div class="discovery-grid" id="status-probes-grid">
          <div class="skeleton-card"></div>
          <div class="skeleton-card"></div>
        </div>

        <div class="section-title" style="margin-top:2.5rem;">
          <div class="title-group">
            <span class="title-text">⚡ Realtime Gateway & WebSocket Diagnostics</span>
            <span class="pill pill-cyan">EVENT BUS ACTIVE</span>
          </div>
        </div>
        <p style="color:var(--text-muted); margin-bottom:1.5rem;">
          Full-duplex WebSocket stream metrics, connected client sessions, and live event broadcast rates.
        </p>

        <div class="discovery-grid" id="realtime-diag-grid">
          <div class="skeleton-card"></div>
        </div>
      `;

      try {
        const res = await fetch('/api/doctor');
        const data = await res.json();
        const grid = document.getElementById('status-probes-grid');
        if (data.success && data.data && Array.isArray(data.data)) {
          grid.innerHTML = data.data.map(d => `
            <div class="discovery-card">
              <div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
                  <div class="card-name">${d.name}</div>
                  <span class="pill ${d.status === 'HEALTHY' ? 'pill-green' : 'pill-amber'}">${d.status}</span>
                </div>
                <div class="card-desc">Latency: <strong>${d.latency_ms} ms</strong> • ID: ${d.diagnostic_id}</div>
              </div>
            </div>
          `).join('');
        } else {
          grid.innerHTML = `
            <div class="discovery-card"><div class="card-name">Discord Gateway</div><span class="pill pill-green">OPERATIONAL</span></div>
            <div class="discovery-card"><div class="card-name">Database (SQLite WAL)</div><span class="pill pill-green">ACTIVE</span></div>
            <div class="discovery-card"><div class="card-name">Voice Audio Engine</div><span class="pill pill-green">OPERATIONAL</span></div>
            <div class="discovery-card"><div class="card-name">Security Tripwires</div><span class="pill pill-green">ARMED</span></div>
          `;
        }
      } catch (e) {}

      // Fetch Realtime Gateway Diagnostics
      try {
        const dRes = await fetch('/api/realtime/diagnostics');
        const dJson = await dRes.json();
        const dGrid = document.getElementById('realtime-diag-grid');
        if (dGrid && dJson.success && dJson.data) {
          const d = dJson.data;
          dGrid.innerHTML = `
            <div class="discovery-card">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
                <div class="card-name">Gateway State</div>
                <span class="pill pill-green">${d.status}</span>
              </div>
              <div class="card-desc">Transport: <strong>${activeTransport.toUpperCase()}</strong> • Uptime: ${d.uptime_seconds}s</div>
            </div>
            <div class="discovery-card">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
                <div class="card-name">Active Streams</div>
                <span class="pill pill-cyan">${d.connected_websocket_clients} WS / ${d.connected_sse_clients} SSE</span>
              </div>
              <div class="card-desc">Total Connections Served: <strong>${d.total_connections_served}</strong></div>
            </div>
            <div class="discovery-card">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
                <div class="card-name">Events Dispatched</div>
                <span class="pill pill-purple">${d.total_events_dispatched}</span>
              </div>
              <div class="card-desc">Cadence: <strong>${d.heartbeat_interval_sec}s</strong> • Dropped: ${d.dropped_events_count}</div>
            </div>
            <div class="discovery-card">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
                <div class="card-name">Synchronization</div>
                <span class="pill pill-green">SYNCED</span>
              </div>
              <div class="card-desc">Last Event: <strong>${d.last_event ? d.last_event.event : 'Initial Sync'}</strong></div>
            </div>
          `;
        }
      } catch (e) {}
    }

    // ==========================================
    // 27. WIKI VIEW (/wiki)
    // ==========================================
    async function renderWiki(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">📖 Community Wiki & Server Guides</span>
            <span class="pill pill-purple">VERIFIED DOCUMENTATION</span>
          </div>
        </div>
        <p style="color:var(--text-muted); margin-bottom:2rem;">
          Official documentation for Rai Community OS, Discord commands, server rules, and permissions.
        </p>
        <div class="discovery-grid" id="wiki-articles-grid"><div class="skeleton-card"></div></div>
      `;

      try {
        const res = await fetch('/api/wiki');
        const data = await res.json();
        const grid = document.getElementById('wiki-articles-grid');
        if (data.success && data.data && data.data.length > 0) {
          grid.innerHTML = data.data.map(w => `
            <div class="discovery-card">
              <div>
                <div class="card-name">${w.title}</div>
                <div class="card-subtitle">${w.category.toUpperCase()}</div>
                <div class="card-desc" style="margin-top:0.6rem;">${w.content.slice(0, 180)}...</div>
              </div>
              <div class="card-bottom-actions">
                <button class="btn btn-outline btn-sm" style="width:100%;" onclick="openWikiModal(${JSON.stringify(w).replace(/"/g, '&quot;')})">Read Article</button>
              </div>
            </div>
          `).join('');
        }
      } catch (e) {}
    }

    function openWikiModal(w) {
      openModal(`📖 ${w.title}`, `
        <span class="pill pill-purple" style="margin-bottom:1rem;">${w.category.toUpperCase()}</span>
        <div style="color:var(--text); line-height:1.7; white-space:pre-wrap; margin-top:1rem;">${w.content}</div>
      `);
    }

    // ==========================================
    // 28. NOTIFICATIONS & MISSION CONTROL
    // ==========================================
    async function renderNotifications(container) {
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <span class="title-text">🔔 Notifications & Alerts</span>
        </div>
        <div id="notifs-list" class="discovery-grid" style="grid-template-columns:1fr;"><div class="skeleton-card"></div></div>
      `;

      try {
        const res = await fetch('/api/notifications');
        const data = await res.json();
        const grid = document.getElementById('notifs-list');
        if (data.success && data.data && data.data.notifications && data.data.notifications.length > 0) {
          grid.innerHTML = data.data.notifications.map(n => `
            <div class="discovery-card" style="padding:1rem;">
              <div class="card-name">${n.title}</div>
              <div class="card-desc" style="margin-top:0.3rem;">${n.message}</div>
            </div>
          `).join('');
        } else {
          grid.innerHTML = `<div class="state-box"><div class="state-title">No new notifications</div></div>`;
        }
      } catch (e) {}
    }

    function renderMissionControl(container) {
      if (!currentUser || !currentUser.is_admin) {
        container.innerHTML = `<div class="state-box"><div class="state-title">Access Restricted</div><p>Mission Control is limited to verified Server Admins.</p></div>`;
        return;
      }
      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">🛡️ Mission Control & Emergency Center</span>
            <span class="pill pill-pink">ADMIN PRIVILEGED</span>
          </div>
        </div>
        <div style="background:rgba(239,68,68,0.08); border:1px solid rgba(239,68,68,0.4); border-radius:var(--radius-lg); padding:1.8rem; margin-bottom:2rem;">
          <h4 style="color:#fff; margin-bottom:0.5rem;">Emergency Safe Mode</h4>
          <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:1rem;">
            Instantly freeze sensitive bot operations, lock dynamic voice channels, and restrict permissions across the guild.
          </p>
          <button class="btn btn-primary" onclick="alert('Safe mode state toggled')">Toggle Safe Mode</button>
        </div>
      `;
    }

    // ==========================================
    // 29. AUDIO CONTROLLER (REALTIME LIVE SYNC)
    // ==========================================
    let isPlaying = false;
    let liveTrack = null;

    async function syncLiveMusicTrack() {
      try {
        const res = await fetch('/api/live');
        if (res.ok) {
          const json = await res.json();
          const sessions = (json.data && json.data.sessions) || [];
          const musicSession = sessions.find(s => s.type === 'music');
          if (musicSession) {
            liveTrack = {
              title: musicSession.title || 'Live Audio Stream',
              artist: musicSession.artist || 'The Raivora Music Service',
              vc: `🟢 Live in ${musicSession.channel_name || 'Voice Channel'}`
            };
          } else {
            liveTrack = null;
          }
        }
      } catch (e) {
        liveTrack = null;
      }
      updatePlayerUI();
    }

    function updatePlayerUI() {
      const setTexts = (id, text) => { const el = document.getElementById(id); if (el) el.innerText = text; };
      if (liveTrack) {
        setTexts('home-track-title', liveTrack.title);
        setTexts('home-track-artist', liveTrack.artist);
        setTexts('home-music-vc', liveTrack.vc);
        setTexts('music-track-title', liveTrack.title);
        setTexts('music-track-artist', liveTrack.artist);
      } else {
        setTexts('home-track-title', 'No Active Music Stream');
        setTexts('home-track-artist', 'Join a voice channel and use /music play in Discord');
        setTexts('home-music-vc', 'Idle');
        setTexts('music-track-title', 'No Active Music Stream');
        setTexts('music-track-artist', 'Join a voice channel and use /music play in Discord');
      }
    }

    async function toggleAudioPreview() {
      await syncLiveMusicTrack();
      if (!liveTrack) {
        showToast('ℹ️ No active music session in Discord. Use /music play in any connected server.', 'info');
        return;
      }
      isPlaying = !isPlaying;
      const playBtns = [document.getElementById('home-play-btn'), document.getElementById('music-play-btn')];
      const discs = [document.getElementById('home-player-disc'), document.getElementById('music-disc')];
      const eqBars = document.querySelectorAll('.eq-bar');

      playBtns.forEach(btn => { if (btn) btn.innerHTML = isPlaying ? '⏸' : '▶'; });
      discs.forEach(disc => {
        if (disc) {
          if (isPlaying) disc.classList.remove('paused');
          else disc.classList.add('paused');
        }
      });
      eqBars.forEach(b => {
        if (isPlaying) b.classList.remove('paused');
        else b.classList.add('paused');
      });
    }

    function nextDemoTrack() {
      syncLiveMusicTrack();
    }

    // ==========================================
    // 29B. COMMUNITY CONSTELLATION (/discover/constellation)
    // ==========================================
    let constellationAnimId = null;

    async function renderConstellation(container) {
      if (constellationAnimId) cancelAnimationFrame(constellationAnimId);

      container.innerHTML = `
        <div class="section-title" style="margin-top:1rem;">
          <div class="title-group">
            <span class="title-text">🌌 Community Constellation</span>
            <span class="pill pill-purple">THE RAIVORA UNIVERSE</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="navigate('/discover')">&larr; Back to Directory</button>
        </div>
        <p style="color:var(--text-muted); margin-bottom:1.5rem; line-height:1.6;">
          An interactive galaxy of interconnected communities, creators, collaborative projects, and live voice spaces.
          Hover over nodes to explore relationships, or click to inspect and join.
        </p>

        <div class="constellation-wrapper">
          <canvas id="constellation-canvas"></canvas>

          <!-- CONSTELLATION NODE DETAIL DRAWER -->
          <div class="constellation-drawer" id="constellation-drawer">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.6rem;">
              <span class="pill pill-cyan" id="node-badge" style="font-size:0.7rem;">COMMUNITY</span>
              <button class="modal-close" style="font-size:1.2rem;" onclick="closeConstellationDrawer()">&times;</button>
            </div>
            <h4 id="node-title" style="font-size:1.25rem; font-weight:800; color:#fff; margin-bottom:0.4rem;">Nightwave Studio</h4>
            <p id="node-desc" style="font-size:0.84rem; color:var(--text-muted); line-height:1.5; margin-bottom:1rem;">
              Community description goes here.
            </p>
            <div id="node-metrics" style="font-size:0.8rem; color:var(--cyan); margin-bottom:1.2rem; font-weight:600;">
              👥 88 members • 🚀 4 projects
            </div>
            <div style="display:flex; gap:0.6rem;">
              <button class="btn btn-primary btn-sm" id="node-action-btn" style="flex:1;" onclick="">Explore Hub</button>
              <button class="btn btn-outline btn-sm" onclick="closeConstellationDrawer()">Dismiss</button>
            </div>
          </div>
        </div>
      `;

      initConstellationCanvas();
    }

    function closeConstellationDrawer() {
      const d = document.getElementById('constellation-drawer');
      if (d) d.classList.remove('active');
    }

    async function initConstellationCanvas() {
      const canvas = document.getElementById('constellation-canvas');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      const rect = canvas.getBoundingClientRect();
      let w = canvas.width = rect.width;
      let h = canvas.height = rect.height;

      let graphData = { nodes: [], edges: [] };
      try {
        const res = await fetch('/api/constellation');
        const json = await res.json();
        if (json.success && json.data) graphData = json.data;
      } catch (e) {
        console.warn('Constellation fetch error:', e);
      }

      // Default fallback universe nodes if empty
      if (!graphData.nodes || graphData.nodes.length === 0) {
        graphData.nodes = [
          { id: 'hub-rai', label: '✦ Raivora Hub', type: 'core', radius: 18, color: '#9333ea', x: w * 0.5, y: h * 0.5 },
          { id: 'cat-gaming', label: '🎮 Gaming', type: 'category', radius: 13, color: '#06b6d4', x: w * 0.32, y: h * 0.35 },
          { id: 'cat-creators', label: '🎨 Creators', type: 'category', radius: 13, color: '#ec4899', x: w * 0.68, y: h * 0.35 },
          { id: 'cat-music', label: '🎵 Music', type: 'category', radius: 13, color: '#a855f7', x: w * 0.5, y: h * 0.22 },
          { id: 'cat-projects', label: '🚀 Projects', type: 'category', radius: 13, color: '#10b981', x: w * 0.35, y: h * 0.68 },
          { id: 'cat-events', label: '📅 Events', type: 'category', radius: 13, color: '#f59e0b', x: w * 0.65, y: h * 0.68 },
          { id: 'comm-nightwave', label: 'Nightwave Studio', type: 'community', radius: 10, color: '#c084fc', x: w * 0.76, y: h * 0.25, members: 88, desc: 'Creative studio for video editors, motion graphics, and audio artists.' },
          { id: 'comm-gaming', label: 'Vora Gaming Realm', type: 'community', radius: 10, color: '#38bdf8', x: w * 0.24, y: h * 0.28, members: 142, desc: 'Competitive esports and squad finding for BGMI, Valorant, and Apex.' }
        ];
        graphData.edges = [
          { source: 'hub-rai', target: 'cat-gaming' },
          { source: 'hub-rai', target: 'cat-creators' },
          { source: 'hub-rai', target: 'cat-music' },
          { source: 'hub-rai', target: 'cat-projects' },
          { source: 'hub-rai', target: 'cat-events' },
          { source: 'cat-creators', target: 'comm-nightwave' },
          { source: 'cat-music', target: 'comm-nightwave' },
          { source: 'cat-gaming', target: 'comm-gaming' }
        ];
      }

      // Distribute node positions if not preset
      graphData.nodes.forEach((n, idx) => {
        if (!n.x || !n.y) {
          const angle = (idx / graphData.nodes.length) * Math.PI * 2;
          const dist = (idx % 2 === 0 ? 0.26 : 0.38) * Math.min(w, h);
          n.x = w * 0.5 + Math.cos(angle) * dist;
          n.y = h * 0.5 + Math.sin(angle) * dist;
        }
        n.vx = 0;
        n.vy = 0;
        n.baseRadius = n.radius || 10;
        n.currentRadius = n.baseRadius;
      });

      let hoveredNode = null;
      let draggedNode = null;

      function onMouseMove(e) {
        const r = canvas.getBoundingClientRect();
        const mx = e.clientX - r.left;
        const my = e.clientY - r.top;

        if (draggedNode) {
          draggedNode.x = mx;
          draggedNode.y = my;
          return;
        }

        hoveredNode = null;
        for (let n of graphData.nodes) {
          const dist = Math.hypot(n.x - mx, n.y - my);
          if (dist <= n.baseRadius + 8) {
            hoveredNode = n;
            break;
          }
        }
        canvas.style.cursor = hoveredNode ? 'pointer' : 'grab';
      }

      function onMouseDown(e) {
        if (hoveredNode) {
          draggedNode = hoveredNode;
          canvas.style.cursor = 'grabbing';
        }
      }

      function onMouseUp(e) {
        if (draggedNode && hoveredNode) {
          showNodeDetails(hoveredNode);
        }
        draggedNode = null;
        canvas.style.cursor = hoveredNode ? 'pointer' : 'grab';
      }

      function showNodeDetails(node) {
        const drawer = document.getElementById('constellation-drawer');
        const badge = document.getElementById('node-badge');
        const title = document.getElementById('node-title');
        const desc = document.getElementById('node-desc');
        const metrics = document.getElementById('node-metrics');
        const btn = document.getElementById('node-action-btn');
        if (!drawer || !node) return;

        badge.innerText = (node.type || 'NODE').toUpperCase();
        title.innerText = node.label || 'Entity';
        desc.innerText = node.desc || node.description || 'Verified node active within the Raivora ecosystem.';
        metrics.innerText = node.members ? `👥 ${node.members} members` : (node.subtitle || 'Connected Node');

        if (node.id.startsWith('comm-') || node.type === 'community') {
          btn.innerText = 'View Community Hub ↗';
          btn.onclick = () => navigate('/communities/' + node.id.replace('comm-', ''));
        } else if (node.type === 'category') {
          btn.innerText = `Explore ${node.label} ↗`;
          btn.onclick = () => navigate('/' + (node.id.replace('cat-', '') || 'discover'));
        } else {
          btn.innerText = 'Explore Raivora ↗';
          btn.onclick = () => navigate('/discover');
        }

        drawer.classList.add('active');
      }

      canvas.addEventListener('mousemove', onMouseMove);
      canvas.addEventListener('mousedown', onMouseDown);
      window.addEventListener('mouseup', onMouseUp);

      function loop() {
        ctx.clearRect(0, 0, w, h);

        // Draw connections
        ctx.lineWidth = 1;
        for (let edge of graphData.edges) {
          const s = graphData.nodes.find(n => n.id === edge.source);
          const t = graphData.nodes.find(n => n.id === edge.target);
          if (s && t) {
            const isHighlight = (hoveredNode && (hoveredNode.id === s.id || hoveredNode.id === t.id));
            ctx.beginPath();
            ctx.moveTo(s.x, s.y);
            ctx.lineTo(t.x, t.y);
            ctx.strokeStyle = isHighlight ? 'rgba(6, 182, 212, 0.7)' : 'rgba(147, 51, 234, 0.22)';
            ctx.lineWidth = isHighlight ? 2 : 1;
            ctx.stroke();
          }
        }

        // Draw nodes
        for (let n of graphData.nodes) {
          const isHovered = hoveredNode && hoveredNode.id === n.id;
          const targetRad = isHovered ? n.baseRadius * 1.35 : n.baseRadius;
          n.currentRadius += (targetRad - n.currentRadius) * 0.2;

          // Outer halo
          ctx.beginPath();
          ctx.arc(n.x, n.y, n.currentRadius * 2, 0, Math.PI * 2);
          ctx.fillStyle = isHovered ? 'rgba(6, 182, 212, 0.18)' : 'rgba(147, 51, 234, 0.08)';
          ctx.fill();

          // Node core
          ctx.beginPath();
          ctx.arc(n.x, n.y, n.currentRadius, 0, Math.PI * 2);
          ctx.fillStyle = n.color || '#9333ea';
          ctx.shadowColor = n.color || '#9333ea';
          ctx.shadowBlur = isHovered ? 25 : 12;
          ctx.fill();
          ctx.shadowBlur = 0;

          // Node label
          ctx.font = isHovered ? 'bold 12px Outfit, sans-serif' : '11px Outfit, sans-serif';
          ctx.fillStyle = isHovered ? '#ffffff' : 'rgba(255, 255, 255, 0.85)';
          ctx.textAlign = 'center';
          ctx.fillText(n.label, n.x, n.y + n.currentRadius + 14);
        }

        constellationAnimId = requestAnimationFrame(loop);
      }
      loop();
    }

    // ==========================================
    // 29C. CREATE A SPACE MODAL FLOW
    // ==========================================
    let selectedSpaceType = 'gaming';

    function openCreateSpaceModal() {
      if (!currentUser) {
        alert('Please sign in with Discord to create a space.');
        openLoginModal();
        return;
      }

      openModal('✦ Create a Space in the Raivora', `
        <p style="color:var(--text-muted); font-size:0.86rem; margin-bottom:1.2rem; line-height:1.5;">
          Instantly instantiate an automated Discord workspace linked to the website.
          Voice rooms, chat channels, and permissions are created in real time.
        </p>

        <label style="font-size:0.82rem; color:var(--text); font-weight:700; display:block; margin-bottom:0.5rem; text-transform:uppercase;">
          1. Select Space Type
        </label>
        <div class="space-type-grid">
          <div class="space-type-card selected" id="stype-gaming" onclick="selectSpaceType('gaming')">
            <div class="space-type-icon">🎮</div>
            <div class="space-type-label">Gaming Squad</div>
          </div>
          <div class="space-type-card" id="stype-creator" onclick="selectSpaceType('creator')">
            <div class="space-type-icon">🎨</div>
            <div class="space-type-label">Creator Studio</div>
          </div>
          <div class="space-type-card" id="stype-music" onclick="selectSpaceType('music')">
            <div class="space-type-icon">🎵</div>
            <div class="space-type-label">Listening Party</div>
          </div>
          <div class="space-type-card" id="stype-watch" onclick="selectSpaceType('watch')">
            <div class="space-type-icon">🎬</div>
            <div class="space-type-label">Watch Event</div>
          </div>
          <div class="space-type-card" id="stype-project" onclick="selectSpaceType('project')">
            <div class="space-type-icon">🚀</div>
            <div class="space-type-label">Project Sprint</div>
          </div>
          <div class="space-type-card" id="stype-room" onclick="selectSpaceType('room')">
            <div class="space-type-icon">💬</div>
            <div class="space-type-label">Community Room</div>
          </div>
          <div class="space-type-card" id="stype-openmic" onclick="selectSpaceType('openmic')">
            <div class="space-type-icon">🎤</div>
            <div class="space-type-label">Open Mic</div>
          </div>
          <div class="space-type-card" id="stype-event" onclick="selectSpaceType('event')">
            <div class="space-type-icon">📅</div>
            <div class="space-type-label">Live Event</div>
          </div>
        </div>

        <form onsubmit="submitCreateSpace(event)" style="display:flex; flex-direction:column; gap:1rem;">
          <div>
            <label style="font-size:0.82rem; color:var(--text-muted); display:block; margin-bottom:0.35rem;">Space Title</label>
            <input type="text" id="space-title" class="input-field" style="width:100%;" placeholder="e.g. BGMI Conqueror Squad, Premiere Cut Sprint" required>
          </div>

          <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.8rem;">
            <div>
              <label style="font-size:0.82rem; color:var(--text-muted); display:block; margin-bottom:0.35rem;">Visibility</label>
              <select id="space-visibility" class="input-field" style="width:100%;">
                <option value="public">🟢 Public (Raivora Discovery)</option>
                <option value="unlisted">🟡 Unlisted (Invite Link Only)</option>
              </select>
            </div>
            <div>
              <label style="font-size:0.82rem; color:var(--text-muted); display:block; margin-bottom:0.35rem;" id="space-extra-label">Game / Topic</label>
              <input type="text" id="space-extra" class="input-field" style="width:100%;" placeholder="e.g. BGMI, After Effects, Lo-Fi Beats">
            </div>
          </div>

          <div>
            <label style="font-size:0.82rem; color:var(--text-muted); display:block; margin-bottom:0.35rem;">Description</label>
            <textarea id="space-desc" class="input-field" style="width:100%; height:70px;" placeholder="What are you collaborating on?"></textarea>
          </div>

          <div id="space-submit-status" style="display:none; padding:0.6rem; border-radius:6px; font-size:0.82rem;"></div>

          <div style="display:flex; justify-content:flex-end; gap:0.8rem; margin-top:0.4rem;">
            <button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button>
            <button type="submit" class="btn btn-primary" id="btn-create-space">
              <span>✦</span> Create Space
            </button>
          </div>
        </form>
      `);
    }

    function selectSpaceType(type) {
      selectedSpaceType = type;
      document.querySelectorAll('.space-type-card').forEach(c => c.classList.remove('selected'));
      const activeCard = document.getElementById(`stype-${type}`);
      if (activeCard) activeCard.classList.add('selected');

      const extraLabel = document.getElementById('space-extra-label');
      const extraInp = document.getElementById('space-extra');
      if (extraLabel && extraInp) {
        if (type === 'gaming') { extraLabel.innerText = 'Game Name'; extraInp.placeholder = 'e.g. BGMI, Valorant, Apex'; }
        else if (type === 'creator') { extraLabel.innerText = 'Tools / Software'; extraInp.placeholder = 'e.g. Premiere Pro, Blender'; }
        else if (type === 'music') { extraLabel.innerText = 'Genre / Vibe'; extraInp.placeholder = 'e.g. Synthwave, Lossless Lo-Fi'; }
        else if (type === 'project') { extraLabel.innerText = 'Deliverable'; extraInp.placeholder = 'e.g. Discord Bot, Video Reel'; }
        else { extraLabel.innerText = 'Category / Tag'; extraInp.placeholder = 'e.g. Chill, Discussion'; }
      }
    }

    async function submitCreateSpace(e) {
      e.preventDefault();
      const title = document.getElementById('space-title').value.trim();
      const visibility = document.getElementById('space-visibility').value;
      const extra = document.getElementById('space-extra').value.trim();
      const description = document.getElementById('space-desc').value.trim();
      const statusDiv = document.getElementById('space-submit-status');
      const submitBtn = document.getElementById('btn-create-space');

      if (!title) return;
      submitBtn.disabled = true;
      submitBtn.innerText = 'Creating in Discord...';

      try {
        const res = await fetch('/api/spaces/create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            space_type: selectedSpaceType,
            title,
            visibility,
            extra,
            description
          })
        });
        const data = await res.json();
        if (data.success) {
          openModal('✓ Space Created Successfully', `
            <div style="text-align:center; padding:1rem 0;">
              <div style="font-size:3rem; margin-bottom:0.5rem;">🎉</div>
              <h4 style="font-size:1.3rem; font-weight:800; color:#fff; margin-bottom:0.4rem;">${data.data.title}</h4>
              <span class="pill pill-green" style="margin-bottom:1rem; display:inline-block;">ACTIVE DISCORD WORKSPACE</span>
              <p style="color:var(--text-muted); font-size:0.9rem; line-height:1.6; max-width:420px; margin:0 auto 1.5rem auto;">
                Your space is initialized and synchronized with Rai's automation outbox. Teammates can join right now.
              </p>
              <div style="display:flex; justify-content:center; gap:0.8rem; flex-wrap:wrap;">
                <a href="${data.data.discord_invite || 'https://discord.gg/raivora'}" target="_blank" class="btn btn-discord btn-lg">
                  <span>👾</span> Join Discord &rarr;
                </a>
                <button class="btn btn-primary btn-lg" onclick="closeModal(); navigate('${data.data.destination || '/'}');">
                  View Space &rarr;
                </button>
              </div>
            </div>
          `);
          loadHomeData();
        } else {
          statusDiv.style.display = 'block';
          statusDiv.style.background = 'rgba(239, 68, 68, 0.15)';
          statusDiv.style.border = '1px solid var(--danger)';
          statusDiv.style.color = '#fca5a5';
          statusDiv.innerText = 'Creation failed: ' + (data.error?.message || 'Server rejected request');
          submitBtn.disabled = false;
          submitBtn.innerText = 'Create Space';
        }
      } catch (err) {
        statusDiv.style.display = 'block';
        statusDiv.style.background = 'rgba(239, 68, 68, 0.15)';
        statusDiv.style.border = '1px solid var(--danger)';
        statusDiv.style.color = '#fca5a5';
        statusDiv.innerText = 'Connection error: ' + err;
        submitBtn.disabled = false;
        submitBtn.innerText = 'Create Space';
      }
    }

    // ==========================================
    // 29D. REALTIME WEBSOCKET & SSE GATEWAY CLIENT
    // ==========================================
    let liveSocket = null;
    let eventSource = null;
    let wsRetryCount = 0;
    let sseRetryCount = 0;
    let lastEventReceivedAt = Date.now();
    let pollingInterval = null;
    let activeTransport = 'ws'; // 'ws', 'sse', 'poll'

    function initRealtimeStream() {
      connectWebSocket();

      // Stale data watcher: after 45s without telemetry, mark unavailable
      setInterval(() => {
        const timeSince = Date.now() - lastEventReceivedAt;
        if (timeSince > 45000 && activeTransport !== 'disconnected') {
          setRealtimeStatus('unavailable', 'Data temporarily unavailable');
        }
      }, 10000);
    }

    function connectWebSocket() {
      if (typeof WebSocket === 'undefined') {
        fallbackToSSE();
        return;
      }

      try {
        const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${proto}//${window.location.host}/api/realtime/ws`;
        liveSocket = new WebSocket(wsUrl);

        liveSocket.onopen = () => {
          wsRetryCount = 0;
          activeTransport = 'ws';
          lastEventReceivedAt = Date.now();
          setRealtimeStatus('live', 'Live');
          // Request instant synchronization
          liveSocket.send(JSON.stringify({ action: 'sync' }));
        };

        liveSocket.onmessage = (e) => {
          lastEventReceivedAt = Date.now();
          try {
            const envelope = JSON.parse(e.data);
            handleRealtimeEvent(envelope.event, envelope.data);
          } catch (err) {
            console.debug('WS parse error:', err);
          }
        };

        liveSocket.onerror = (e) => {
          console.debug('WebSocket error encountered, fallback prepared.');
        };

        liveSocket.onclose = () => {
          wsRetryCount++;
          if (wsRetryCount > 3) {
            fallbackToSSE();
          } else {
            setRealtimeStatus('reconnecting', 'Reconnecting…');
            const delay = Math.min(2000 * Math.pow(2, wsRetryCount - 1), 30000);
            setTimeout(connectWebSocket, delay);
          }
        };
      } catch (err) {
        fallbackToSSE();
      }
    }

    function fallbackToSSE() {
      if (liveSocket) {
        try { liveSocket.close(); } catch(e){}
        liveSocket = null;
      }
      if (typeof EventSource === 'undefined') {
        fallbackToPolling();
        return;
      }

      try {
        eventSource = new EventSource('/api/realtime/stream');
        activeTransport = 'sse';

        eventSource.onopen = () => {
          sseRetryCount = 0;
          lastEventReceivedAt = Date.now();
          setRealtimeStatus('live', 'Live (SSE)');
        };

        eventSource.addEventListener('init', (e) => {
          lastEventReceivedAt = Date.now();
          try {
            const data = JSON.parse(e.data);
            handleRealtimeEvent('INIT', data);
          } catch(err){}
        });

        eventSource.addEventListener('pulse', (e) => {
          lastEventReceivedAt = Date.now();
          try {
            const data = JSON.parse(e.data);
            handleRealtimeEvent('PULSE_UPDATED', data.pulse || data);
            if (data.live) handleRealtimeEvent('LIVE_SESSIONS_SYNC', data.live);
            if (data.activity) handleRealtimeEvent('ACTIVITY_UPDATED', data.activity);
          } catch(err){}
        });

        eventSource.addEventListener('PULSE_UPDATED', (e) => {
          lastEventReceivedAt = Date.now();
          try {
            const data = JSON.parse(e.data);
            handleRealtimeEvent('PULSE_UPDATED', data.data || data);
          } catch(err){}
        });

        eventSource.addEventListener('LIVE_SESSION_ADDED', (e) => {
          lastEventReceivedAt = Date.now();
          try {
            const data = JSON.parse(e.data);
            handleRealtimeEvent('LIVE_SESSION_ADDED', data.data || data);
          } catch(err){}
        });

        eventSource.addEventListener('LIVE_SESSION_REMOVED', (e) => {
          lastEventReceivedAt = Date.now();
          try {
            const data = JSON.parse(e.data);
            handleRealtimeEvent('LIVE_SESSION_REMOVED', data.data || data);
          } catch(err){}
        });

        eventSource.onerror = () => {
          sseRetryCount++;
          if (sseRetryCount > 3) {
            fallbackToPolling();
          } else {
            setRealtimeStatus('reconnecting', 'Reconnecting…');
            if (eventSource) eventSource.close();
            setTimeout(fallbackToSSE, Math.min(4000 * sseRetryCount, 30000));
          }
        };
      } catch(e) {
        fallbackToPolling();
      }
    }

    function fallbackToPolling() {
      if (eventSource) {
        try { eventSource.close(); } catch(e){}
        eventSource = null;
      }
      activeTransport = 'poll';
      setRealtimeStatus('live', 'Live (Polling)');

      if (!pollingInterval) {
        pollingInterval = setInterval(async () => {
          try {
            const pRes = await fetch('/api/pulse');
            const pData = await pRes.json();
            if (pData.success && pData.data) {
              updatePulseUI(pData.data);
              lastEventReceivedAt = Date.now();
            }
          } catch(e) {
            setRealtimeStatus('unavailable', 'Live data unavailable');
          }
        }, 12000);
      }
    }

    function handleRealtimeEvent(eventType, data) {
      if (!data) return;

      if (eventType === 'INIT' || eventType === 'SYNC') {
        if (data.pulse) updatePulseUI(data.pulse);
        if (data.live_sessions) updateLiveNowUI(data.live_sessions);
        if (data.category_counts) updateCategoryCountsUI(data.category_counts);
        if (data.recent_activity) updateActivityUI(data.recent_activity);
      } else if (eventType === 'PULSE_UPDATED') {
        updatePulseUI(data);
      } else if (eventType === 'VOICE_UPDATED') {
        if (data.users_in_voice !== undefined) {
          updatePartialMetric('pulse-voice', data.users_in_voice);
          updatePartialDna('voice', data.users_in_voice);
        }
      } else if (eventType === 'MEMBER_COUNT_UPDATED') {
        if (data.members_online !== undefined) {
          updatePartialMetric('pulse-members', data.members_online);
        }
      } else if (eventType === 'MUSIC_UPDATED') {
        if (data.music_listeners !== undefined) {
          updatePartialMetric('pulse-listening', data.music_listeners);
          updatePartialDna('music', data.music_listeners);
        }
      } else if (eventType === 'LIVE_SESSION_ADDED') {
        insertLiveSessionCard(data);
      } else if (eventType === 'LIVE_SESSION_REMOVED') {
        removeLiveSessionCard(data.id);
      } else if (eventType === 'LIVE_SESSIONS_SYNC') {
        updateLiveNowUI(data);
      } else if (eventType === 'CATEGORY_COUNTS_UPDATED') {
        updateCategoryCountsUI(data);
      } else if (eventType === 'ACTIVITY_UPDATED') {
        updateActivityUI(data);
      }
    }

    function updatePartialMetric(id, val) {
      const el = document.getElementById(id);
      if (!el) return;
      const textVal = (val === null || val === undefined) ? '—' : Number(val).toLocaleString();
      if (el.innerText !== textVal) {
        el.innerText = textVal;
        el.classList.add('pulse-val-updated');
        setTimeout(() => el.classList.remove('pulse-val-updated'), 700);
      }
    }

    function updatePartialDna(cat, val) {
      const fillEl = document.getElementById(`dna-fill-${cat}`);
      const pctEl = document.getElementById(`dna-pct-${cat}`);
      if (fillEl && val !== null && val !== undefined) {
        fillEl.style.width = Math.min(100, Math.max(0, val)) + '%';
      }
      if (pctEl && val !== null && val !== undefined) {
        pctEl.innerText = val > 0 ? val + '%' : '—';
      }
    }

    function updateCategoryCountsUI(counts) {
      if (!counts) return;
      const setPill = (id, val) => {
        const el = document.getElementById(id);
        if (el && val !== undefined && val !== null) el.innerText = val;
      };
      setPill('count-gaming', counts.gaming);
      setPill('count-music', counts.music);
      setPill('count-creators', counts.creators);
      setPill('count-projects', counts.projects);
      setPill('count-media', counts.media);
      setPill('count-events', counts.events);
      setPill('count-resources', counts.resources);
    }

    function insertLiveSessionCard(s) {
      const grid = document.getElementById('live-now-grid');
      if (!grid) return;
      if (grid.querySelector('.state-box')) {
        grid.innerHTML = '';
      }
      const existing = document.getElementById(`session-card-${s.id}`);
      if (existing) {
        existing.classList.add('pulse-val-updated');
        setTimeout(() => existing.classList.remove('pulse-val-updated'), 700);
        return;
      }
      const cardHtml = `
        <div class="live-now-card live-card-enter" id="session-card-${s.id}">
          <div>
            <div class="live-now-top">
              <span class="live-now-type">
                <span class="live-dot"></span> ${s.type || 'SESSION'}
              </span>
              <span class="tag-badge" style="font-size:0.7rem;">👥 ${s.participants || (s.participant_count ? s.participant_count + ' active' : '1 active')}</span>
            </div>
            <div class="live-now-title">${s.title}</div>
            <div class="live-now-community">📍 ${s.community || 'Rai Community OS'}</div>
          </div>
          <div>
            <div class="live-now-meta">
              <span>Started: Live now</span>
              <span class="pill pill-green" style="font-size:0.68rem;">ACTIVE</span>
            </div>
            <div class="card-bottom-actions" style="margin-top:0.8rem;">
              <button class="btn btn-primary btn-sm" style="flex:1;" onclick="navigate('${s.destination || '/communities'}')">${s.action_label || 'Join Space'} ↗</button>
              <a href="https://discord.gg/raivora" target="_blank" class="btn btn-discord btn-sm" style="flex:1;">Join Discord</a>
            </div>
          </div>
        </div>
      `;
      grid.insertAdjacentHTML('afterbegin', cardHtml);
    }

    function removeLiveSessionCard(sessionId) {
      const card = document.getElementById(`session-card-${sessionId}`);
      if (card) {
        card.classList.add('live-card-leave');
        setTimeout(() => {
          if (card.parentNode) card.parentNode.removeChild(card);
          const grid = document.getElementById('live-now-grid');
          if (grid && grid.children.length === 0) {
            updateLiveNowUI([]);
          }
        }, 400);
      }
    }

    function setRealtimeStatus(state, label) {
      const pills = document.querySelectorAll('#global-rt-pill');
      pills.forEach(pill => {
        if (!pill) return;
        pill.innerHTML = `<span class="rt-dot ${state}"></span> ${label}`;
        pill.className = `rt-status-pill ${state}`;
      });
    }

    // ==========================================
    // 29E. FLOATING RAI ASSISTANT WIDGET
    // ==========================================
    function initAssistant() {
      const widget = document.getElementById('rai-assistant-widget');
      if (!widget) return;
      if (sessionStorage.getItem('rai_assistant_dismissed')) {
        widget.classList.add('hidden');
        return;
      }

      const msgs = [
        { text: "12 communities are active right now.", action: "/communities", btn: "Explore" },
        { text: "Explore the Community Galaxy Constellation.", action: "/discover/constellation", btn: "View Galaxy" },
        { text: "Active BGMI competitive squad recruiting.", action: "/gaming", btn: "Join Squad" },
        { text: "Nightwave Studio editing session is live.", action: "/creators", btn: "Meet Creators" }
      ];

      const pick = msgs[Math.floor(Math.random() * msgs.length)];
      const msgEl = document.getElementById('rai-assistant-msg');
      const actionBtn = document.getElementById('rai-assistant-action');
      if (msgEl) msgEl.innerText = pick.text;
      if (actionBtn) {
        actionBtn.innerText = pick.btn;
        actionBtn.onclick = () => navigate(pick.action);
      }
    }

    function dismissAssistant() {
      const widget = document.getElementById('rai-assistant-widget');
      if (widget) widget.classList.add('hidden');
      sessionStorage.setItem('rai_assistant_dismissed', '1');
    }
    // ==========================================
    // 29F. RAIVORA WEB STUDIO & SCRIPT IDE
    // ==========================================
    let studioTemplates = [];
    let currentStudioTemplate = null;

    async function renderStudio(container) {
      container.innerHTML = `
        <div class="content-header" style="margin-bottom: 1.5rem;">
          <div class="badge" style="background: rgba(147, 51, 234, 0.2); color: #c084fc; border: 1px solid rgba(147, 51, 234, 0.4); margin-bottom: 0.5rem; display: inline-flex; align-items: center; gap: 0.4rem; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 700;">
            <span>⚡</span> RAIVORA CLOUD STUDIO & DEVELOPER SANDBOX
          </div>
          <h2 style="font-size: 2.2rem; font-weight: 800; background: linear-gradient(135deg, #fff, #c084fc); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin: 0 0 0.5rem 0;">
            Web Studio & Script IDE
          </h2>
          <p style="color: var(--text-muted); font-size: 0.95rem; max-width: 700px; margin: 0;">
            Author bot cogs, test Discord webhook embeds, generate After Effects JSX automation, and build procedural 3D Blender scripts directly in your browser.
          </p>
        </div>

        <div class="studio-layout">
          <!-- Sidebar: Files & Templates -->
          <div class="studio-sidebar">
            <div style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.05em; margin-bottom: 0.4rem;">
              Templates & Files
            </div>
            <div id="studio-files-list" style="display: flex; flex-direction: column; gap: 0.4rem;">
              <div style="color: var(--text-muted); font-size: 0.82rem; padding: 0.5rem;">Loading templates...</div>
            </div>
            <div style="margin-top: auto; padding-top: 1rem; border-top: 1px solid rgba(255,255,255,0.08);">
              <button class="btn btn-outline btn-sm" style="width: 100%; font-size: 0.8rem;" onclick="resetStudioTemplate()">
                <span>↺</span> Reset to Default
              </button>
            </div>
          </div>

          <!-- Main Editor Workspace -->
          <div class="studio-editor-box">
            <div class="studio-editor-toolbar">
              <div style="display: flex; align-items: center; gap: 0.75rem;">
                <span id="studio-current-filename" style="font-weight: 700; color: #fff; font-size: 0.9rem; font-family: 'JetBrains Mono', monospace;">
                  main.py
                </span>
                <span id="studio-lang-badge" class="badge" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 4px;">
                  python
                </span>
              </div>
              <div style="display: flex; align-items: center; gap: 0.6rem;">
                <button class="btn btn-outline btn-sm" onclick="copyStudioCode()" style="font-size: 0.8rem; padding: 0.35rem 0.75rem;">
                  <span>📋</span> Copy
                </button>
                <button class="btn btn-outline btn-sm" onclick="downloadStudioCode()" style="font-size: 0.8rem; padding: 0.35rem 0.75rem;">
                  <span>💾</span> Download
                </button>
                <button class="btn btn-primary btn-sm" onclick="verifyStudioCode()" id="studio-run-btn" style="font-size: 0.8rem; padding: 0.35rem 1rem;">
                  <span>▶</span> Test / Lint
                </button>
              </div>
            </div>

            <textarea id="studio-code-input" class="studio-code-area" spellcheck="false" placeholder="Write or paste your code here..."></textarea>

            <div class="studio-status-box">
              <div id="studio-status-msg" style="display: flex; align-items: center; gap: 0.4rem;">
                <span style="color: var(--emerald);">●</span> Ready
              </div>
              <div id="studio-char-count">0 lines</div>
            </div>
          </div>
        </div>
      `;

      loadStudioTemplates();
    }

    async function loadStudioTemplates() {
      try {
        const res = await fetch('/api/studio/templates');
        const json = await res.json();
        const payload = json.data || json;
        studioTemplates = payload.templates || [];
        
        const listEl = document.getElementById('studio-files-list');
        if (!listEl) return;

        if (!studioTemplates.length) {
          listEl.innerHTML = '<div style="color: var(--text-muted); font-size: 0.82rem;">No templates found.</div>';
          return;
        }

        listEl.innerHTML = studioTemplates.map((t, idx) => `
          <div class="studio-file-item ${idx === 0 ? 'active' : ''}" onclick="selectStudioTemplate('${t.id}')" id="studio-tab-${t.id}">
            <span>${t.language === 'python' ? '🐍' : t.language === 'json' ? '📦' : t.language === 'javascript' ? '📜' : '💎'}</span>
            <div style="flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
              <div>${t.name}</div>
              <div style="font-size: 0.7rem; color: var(--text-muted);">${t.file_extension}</div>
            </div>
          </div>
        `).join('');

        if (studioTemplates.length > 0) {
          selectStudioTemplate(studioTemplates[0].id);
        }
      } catch (err) {
        console.error('Failed to load studio templates:', err);
      }
    }

    function selectStudioTemplate(templateId) {
      const template = studioTemplates.find(t => t.id === templateId);
      if (!template) return;
      currentStudioTemplate = template;

      document.querySelectorAll('.studio-file-item').forEach(el => el.classList.remove('active'));
      const activeEl = document.getElementById('studio-tab-' + templateId);
      if (activeEl) activeEl.classList.add('active');

      const nameEl = document.getElementById('studio-current-filename');
      const langEl = document.getElementById('studio-lang-badge');
      const codeInput = document.getElementById('studio-code-input');
      const statusMsg = document.getElementById('studio-status-msg');

      if (nameEl) nameEl.innerText = template.name + template.file_extension;
      if (langEl) langEl.innerText = template.language;
      if (codeInput) {
        codeInput.value = template.content;
        updateStudioLineCount();
      }
      if (statusMsg) {
        statusMsg.innerHTML = `<span style="color: var(--emerald);">●</span> Loaded ${template.name}`;
      }
    }

    function resetStudioTemplate() {
      if (currentStudioTemplate) {
        selectStudioTemplate(currentStudioTemplate.id);
        showToast('Template reset to default', 'info');
      }
    }

    function updateStudioLineCount() {
      const codeInput = document.getElementById('studio-code-input');
      const countEl = document.getElementById('studio-char-count');
      if (codeInput && countEl) {
        const lines = codeInput.value.split('\\n').length;
        countEl.innerText = `${lines} lines • ${codeInput.value.length} chars`;
      }
    }

    async function verifyStudioCode() {
      const codeInput = document.getElementById('studio-code-input');
      const statusMsg = document.getElementById('studio-status-msg');
      const runBtn = document.getElementById('studio-run-btn');
      if (!codeInput || !currentStudioTemplate) return;

      if (runBtn) runBtn.disabled = true;
      if (statusMsg) statusMsg.innerHTML = '<span style="color: var(--cyan);">⌛</span> Verifying syntax...';

      try {
        const res = await fetch('/api/studio/test', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            code: codeInput.value,
            language: currentStudioTemplate.language
          })
        });
        const json = await res.json();
        const payload = json.data || json;

        if (payload.status === 'valid') {
          statusMsg.innerHTML = `<span style="color: var(--emerald);">✔</span> Syntax Valid! (${payload.details || 'No errors'})`;
          showToast('Code syntax verified successfully!', 'success');
        } else {
          statusMsg.innerHTML = `<span style="color: #ef4444;">✖</span> ${payload.details || 'Syntax issue detected'}`;
          showToast('Syntax check flagged an issue', 'error');
        }
      } catch (err) {
        statusMsg.innerHTML = `<span style="color: #ef4444;">✖</span> Verification failed: ${err.message}`;
      } finally {
        if (runBtn) runBtn.disabled = false;
      }
    }

    function copyStudioCode() {
      const codeInput = document.getElementById('studio-code-input');
      if (!codeInput) return;
      navigator.clipboard.writeText(codeInput.value);
      showToast('Code copied to clipboard!', 'success');
    }

    function downloadStudioCode() {
      const codeInput = document.getElementById('studio-code-input');
      if (!codeInput || !currentStudioTemplate) return;
      const blob = new Blob([codeInput.value], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = (currentStudioTemplate.id || 'script') + (currentStudioTemplate.file_extension || '.txt');
      a.click();
      URL.revokeObjectURL(url);
      showToast('File downloaded successfully', 'success');
    }

    // ==========================================
    // 29G. CREATOR BOUNTIES & GIG MARKETPLACE
    // ==========================================
    let bountiesList = [];
    let currentBountyFilter = 'all';

    async function renderBounties(container) {
      container.innerHTML = `
        <div class="content-header" style="margin-bottom: 1.5rem; display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 1rem;">
          <div>
            <div class="badge" style="background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3); margin-bottom: 0.5rem; display: inline-flex; align-items: center; gap: 0.4rem; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 700;">
              <span>💼</span> RAIVORA COLLAB & GIG ECONOMY
            </div>
            <h2 style="font-size: 2.2rem; font-weight: 800; background: linear-gradient(135deg, #fff, #10b981); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin: 0 0 0.5rem 0;">
              Creator Bounties & Gigs
            </h2>
            <p style="color: var(--text-muted); font-size: 0.95rem; max-width: 600px; margin: 0;">
              Earn Rai Coins and build reputation by taking on video editing, 3D art, bot development, and thumbnail design gigs.
            </p>
          </div>
          <button class="btn btn-primary" onclick="openPostBountyModal()" style="display: flex; align-items: center; gap: 0.5rem;">
            <span>+</span> Post a Bounty
          </button>
        </div>

        <!-- Filter Chips -->
        <div class="category-pills-bar" style="margin-bottom: 1.5rem;">
          <button class="cat-pill active" onclick="setBountyFilter('all', this)">All Gigs</button>
          <button class="cat-pill" onclick="setBountyFilter('Video Editing', this)">🎬 Video Editing</button>
          <button class="cat-pill" onclick="setBountyFilter('3D Art', this)">🧊 3D & VFX</button>
          <button class="cat-pill" onclick="setBountyFilter('Bot Development', this)">🐍 Python & Bots</button>
          <button class="cat-pill" onclick="setBountyFilter('Graphic Design', this)">🎨 Graphic Design</button>
        </div>

        <!-- Bounties Grid -->
        <div id="bounties-grid-container" class="bounties-grid">
          <div style="color: var(--text-muted); padding: 2rem;">Loading open bounties...</div>
        </div>

        <!-- Modal: Post Bounty -->
        <div id="modal-post-bounty" class="modal-backdrop hidden">
          <div class="modal-card" style="max-width: 520px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
              <h3 style="margin: 0; font-size: 1.3rem;">Post a Creator Bounty</h3>
              <button onclick="closePostBountyModal()" style="background: none; border: none; color: var(--text-muted); font-size: 1.4rem; cursor: pointer;">✕</button>
            </div>
            <form onsubmit="submitPostBounty(event)" style="display: flex; flex-direction: column; gap: 1rem;">
              <div>
                <label style="display: block; font-size: 0.8rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.3rem;">Bounty Title</label>
                <input type="text" id="bounty-input-title" required placeholder="e.g. 60s High Energy Valorant Reel Edit" class="hero-search-input" style="width: 100%; border-radius: var(--radius-sm); font-size: 0.9rem;">
              </div>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
                <div>
                  <label style="display: block; font-size: 0.8rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.3rem;">Category</label>
                  <select id="bounty-input-category" class="hero-search-input" style="width: 100%; border-radius: var(--radius-sm); font-size: 0.9rem; background: #121420; color: #fff;">
                    <option value="Video Editing">Video Editing</option>
                    <option value="3D Art">3D Art</option>
                    <option value="Bot Development">Bot Development</option>
                    <option value="Graphic Design">Graphic Design</option>
                  </select>
                </div>
                <div>
                  <label style="display: block; font-size: 0.8rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.3rem;">Reward (Rai Coins)</label>
                  <input type="number" id="bounty-input-reward" min="50" step="50" value="500" required class="hero-search-input" style="width: 100%; border-radius: var(--radius-sm); font-size: 0.9rem;">
                </div>
              </div>
              <div>
                <label style="display: block; font-size: 0.8rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.3rem;">Description & Requirements</label>
                <textarea id="bounty-input-desc" required rows="3" placeholder="Explain the project scope, aesthetic references, and timeline..." class="studio-code-area" style="min-height: 80px; font-family: inherit; font-size: 0.88rem; border-radius: var(--radius-sm); border: 1px solid rgba(255,255,255,0.1);"></textarea>
              </div>
              <div>
                <label style="display: block; font-size: 0.8rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.3rem;">Tags (comma-separated)</label>
                <input type="text" id="bounty-input-tags" placeholder="Premiere Pro, After Effects, 4K" class="hero-search-input" style="width: 100%; border-radius: var(--radius-sm); font-size: 0.9rem;">
              </div>
              <div style="display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 0.5rem;">
                <button type="button" class="btn btn-outline btn-sm" onclick="closePostBountyModal()">Cancel</button>
                <button type="submit" class="btn btn-primary btn-sm">Post Bounty</button>
              </div>
            </form>
          </div>
        </div>

        <!-- Modal: Apply Bounty -->
        <div id="modal-apply-bounty" class="modal-backdrop hidden">
          <div class="modal-card" style="max-width: 480px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
              <h3 style="margin: 0; font-size: 1.25rem;">Apply for Bounty</h3>
              <button onclick="closeApplyBountyModal()" style="background: none; border: none; color: var(--text-muted); font-size: 1.4rem; cursor: pointer;">✕</button>
            </div>
            <form onsubmit="submitApplyBounty(event)" style="display: flex; flex-direction: column; gap: 1rem;">
              <input type="hidden" id="apply-bounty-id">
              <div id="apply-bounty-title-label" style="font-weight: 700; color: #fff; font-size: 0.95rem;"></div>
              <div>
                <label style="display: block; font-size: 0.8rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.3rem;">Pitch & Why You're the Best Fit</label>
                <textarea id="apply-input-pitch" required rows="3" placeholder="Tell the creator about your background and past works..." class="studio-code-area" style="min-height: 80px; font-family: inherit; font-size: 0.88rem; border-radius: var(--radius-sm); border: 1px solid rgba(255,255,255,0.1);"></textarea>
              </div>
              <div>
                <label style="display: block; font-size: 0.8rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.3rem;">Portfolio / Drive / Showcase Link</label>
                <input type="url" id="apply-input-portfolio" required placeholder="https://behance.net/you or https://drive.google.com/..." class="hero-search-input" style="width: 100%; border-radius: var(--radius-sm); font-size: 0.9rem;">
              </div>
              <div style="display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 0.5rem;">
                <button type="button" class="btn btn-outline btn-sm" onclick="closeApplyBountyModal()">Cancel</button>
                <button type="submit" class="btn btn-primary btn-sm">Submit Application</button>
              </div>
            </form>
          </div>
        </div>
      `;

      loadBountiesData();
    }

    async function loadBountiesData() {
      try {
        const res = await fetch('/api/bounties');
        const json = await res.json();
        const payload = json.data || json;
        bountiesList = payload.bounties || [];
        renderBountiesGrid();
      } catch (err) {
        console.error('Failed to load bounties:', err);
      }
    }

    function setBountyFilter(filter, el) {
      currentBountyFilter = filter;
      document.querySelectorAll('.cat-pill').forEach(b => b.classList.remove('active'));
      if (el) el.classList.add('active');
      renderBountiesGrid();
    }

    function renderBountiesGrid() {
      const container = document.getElementById('bounties-grid-container');
      if (!container) return;

      const filtered = bountiesList.filter(b => {
        if (currentBountyFilter === 'all') return true;
        return b.category === currentBountyFilter;
      });

      if (!filtered.length) {
        container.innerHTML = `
          <div style="grid-column: 1 / -1; text-align: center; padding: 3rem; background: rgba(15, 17, 26, 0.6); border-radius: var(--radius-lg); border: 1px dashed rgba(255,255,255,0.1);">
            <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">🔍</div>
            <h4 style="margin: 0 0 0.5rem 0; font-size: 1.1rem;">No bounties in this category yet</h4>
            <p style="color: var(--text-muted); font-size: 0.88rem; margin-bottom: 1rem;">Be the first to post a collaboration request!</p>
            <button class="btn btn-primary btn-sm" onclick="openPostBountyModal()">+ Post Bounty</button>
          </div>
        `;
        return;
      }

      container.innerHTML = filtered.map(b => `
        <div class="bounty-card">
          <div>
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 0.5rem; margin-bottom: 0.75rem;">
              <span class="badge" style="background: rgba(147, 51, 234, 0.15); color: #c084fc; border: 1px solid rgba(147, 51, 234, 0.3); font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 4px;">
                ${b.category}
              </span>
              <div class="bounty-reward">
                <span>🪙</span> ${b.reward.toLocaleString()} <span style="font-size: 0.75rem; color: var(--text-muted); font-weight: 500;">Coins</span>
              </div>
            </div>
            <h3 style="font-size: 1.15rem; font-weight: 700; color: #fff; margin: 0 0 0.5rem 0; line-height: 1.3;">
              ${b.title}
            </h3>
            <p style="color: var(--text-muted); font-size: 0.85rem; line-height: 1.5; margin: 0 0 1rem 0;">
              ${b.description}
            </p>
            <div style="display: flex; flex-wrap: wrap; gap: 0.4rem; margin-bottom: 1rem;">
              ${(b.tags || []).map(t => `<span style="background: rgba(255,255,255,0.06); color: var(--text-muted); font-size: 0.7rem; padding: 0.15rem 0.45rem; border-radius: 4px;">#${t}</span>`).join('')}
            </div>
          </div>

          <div style="border-top: 1px solid rgba(255,255,255,0.08); padding-top: 0.8rem; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 0.5rem;">
              <div style="width: 28px; height: 28px; border-radius: 50%; background: linear-gradient(135deg, #9333ea, #06b6d4); display: flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 700;">
                ${b.posted_by[0].toUpperCase()}
              </div>
              <div style="font-size: 0.8rem; color: var(--text-muted);">
                ${b.posted_by}
              </div>
            </div>
            <button class="btn btn-primary btn-sm" onclick="openApplyBountyModal('${b.id}', '${b.title.replace(/'/g, "\\'")}')" style="font-size: 0.8rem; padding: 0.35rem 0.85rem;">
              Apply ✦
            </button>
          </div>
        </div>
      `).join('');
    }

    function openPostBountyModal() {
      const modal = document.getElementById('modal-post-bounty');
      if (modal) modal.classList.remove('hidden');
    }

    function closePostBountyModal() {
      const modal = document.getElementById('modal-post-bounty');
      if (modal) modal.classList.add('hidden');
    }

    async function submitPostBounty(e) {
      e.preventDefault();
      const title = document.getElementById('bounty-input-title').value;
      const category = document.getElementById('bounty-input-category').value;
      const reward = parseInt(document.getElementById('bounty-input-reward').value);
      const description = document.getElementById('bounty-input-desc').value;
      const tagsStr = document.getElementById('bounty-input-tags').value;
      const tags = tagsStr.split(',').map(s => s.trim()).filter(Boolean);

      try {
        const res = await fetch('/api/bounties', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title, category, reward, description, tags })
        });
        const json = await res.json();
        closePostBountyModal();
        showToast('Bounty published to Rai Marketplace!', 'success');
        loadBountiesData();
      } catch (err) {
        showToast('Failed to post bounty: ' + err.message, 'error');
      }
    }

    function openApplyBountyModal(id, title) {
      const modal = document.getElementById('modal-apply-bounty');
      const idInput = document.getElementById('apply-bounty-id');
      const label = document.getElementById('apply-bounty-title-label');
      if (idInput) idInput.value = id;
      if (label) label.innerText = title;
      if (modal) modal.classList.remove('hidden');
    }

    function closeApplyBountyModal() {
      const modal = document.getElementById('modal-apply-bounty');
      if (modal) modal.classList.add('hidden');
    }

    async function submitApplyBounty(e) {
      e.preventDefault();
      const bountyId = document.getElementById('apply-bounty-id').value;
      const pitch = document.getElementById('apply-input-pitch').value;
      const portfolio = document.getElementById('apply-input-portfolio').value;

      try {
        const res = await fetch(`/api/bounties/${bountyId}/apply`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pitch, portfolio })
        });
        closeApplyBountyModal();
        showToast('Application sent to creator! They will review via Discord.', 'success');
      } catch (err) {
        showToast('Failed to submit application: ' + err.message, 'error');
      }
    }

    // ==========================================
    // 29H. 3D HOLOGRAPHIC CITIZEN PASSPORT
    // ==========================================
    async function renderPassport(container, targetUserId) {
      container.innerHTML = `
        <div class="content-header" style="text-align: center; margin-bottom: 2rem;">
          <div class="badge" style="background: rgba(147, 51, 234, 0.2); color: #c084fc; border: 1px solid rgba(147, 51, 234, 0.4); margin-bottom: 0.5rem; display: inline-flex; align-items: center; gap: 0.4rem; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 700;">
            <span>🎴</span> DIGITAL IDENTITY PASSPORT
          </div>
          <h2 style="font-size: 2.4rem; font-weight: 800; background: linear-gradient(135deg, #fff, #c084fc); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin: 0 0 0.5rem 0;">
            Raivora Citizen Passport
          </h2>
          <p style="color: var(--text-muted); font-size: 0.95rem; max-width: 550px; margin: 0 auto;">
            Move your cursor or finger over the card to inspect your holographic security sheen, verified credentials, and activity DNA.
          </p>
        </div>

        <div class="passport-container">
          <div class="passport-card-3d" id="passport-3d-card">
            <div class="passport-holo-sheen" id="passport-holo-sheen"></div>

            <div style="position: relative; z-index: 2;">
              <!-- Header -->
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                  <span style="font-size: 1.3rem;">✦</span>
                  <span style="font-weight: 800; letter-spacing: 0.12em; font-size: 0.9rem; color: #fff;">
                    RAIVORA FEDERATION
                  </span>
                </div>
                <div id="passport-tier-badge" class="badge" style="background: rgba(168, 85, 247, 0.2); color: #c084fc; border: 1px solid rgba(168, 85, 247, 0.4); font-size: 0.7rem; font-weight: 800; padding: 0.2rem 0.6rem; border-radius: 9999px;">
                  CITIZEN
                </div>
              </div>

              <!-- Main identity section -->
              <div style="display: flex; gap: 1.2rem; align-items: center; margin-bottom: 1.5rem;">
                <div style="position: relative;">
                  <div id="passport-avatar" style="width: 72px; height: 72px; border-radius: 50%; border: 2px solid #a855f7; background: #000; overflow: hidden; display: flex; align-items: center; justify-content: center; font-size: 2rem;">
                    👤
                  </div>
                  <div style="position: absolute; bottom: 0; right: 0; width: 22px; height: 22px; background: #10b981; border: 2px solid #090b12; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.65rem; color: #fff;">
                    ✓
                  </div>
                </div>

                <div style="flex: 1;">
                  <h3 id="passport-name" style="margin: 0 0 0.2rem 0; font-size: 1.35rem; font-weight: 800; color: #fff;">
                    Citizen
                  </h3>
                  <div id="passport-handle" style="font-size: 0.85rem; color: var(--text-muted); font-family: 'JetBrains Mono', monospace; margin-bottom: 0.4rem;">
                    @raivora
                  </div>
                  <div id="passport-rank-title" style="font-size: 0.75rem; color: #38bdf8; font-weight: 600;">
                    Raivora Explorer
                  </div>
                </div>
              </div>

              <!-- Economy / Level Stats -->
              <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; background: rgba(0, 0, 0, 0.35); border-radius: 12px; padding: 0.75rem 1rem; margin-bottom: 1.2rem; border: 1px solid rgba(255, 255, 255, 0.06);">
                <div style="text-align: center;">
                  <div style="font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase;">Level</div>
                  <div id="passport-level" style="font-size: 1.15rem; font-weight: 800; color: #fff;">1</div>
                </div>
                <div style="text-align: center; border-left: 1px solid rgba(255,255,255,0.08); border-right: 1px solid rgba(255,255,255,0.08);">
                  <div style="font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase;">Coins</div>
                  <div id="passport-coins" style="font-size: 1.15rem; font-weight: 800; color: var(--emerald);">100</div>
                </div>
                <div style="text-align: center;">
                  <div style="font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase;">Streak</div>
                  <div id="passport-streak" style="font-size: 1.15rem; font-weight: 800; color: #f59e0b;">🔥 0d</div>
                </div>
              </div>

              <!-- Raivora Activity DNA Bar -->
              <div style="margin-bottom: 1.2rem;">
                <div style="display: flex; justify-content: space-between; font-size: 0.72rem; color: var(--text-muted); margin-bottom: 0.4rem; text-transform: uppercase; font-weight: 700;">
                  <span>Activity DNA</span>
                  <span>Voice / Games / Media / Beats</span>
                </div>
                <div style="display: flex; height: 8px; border-radius: 4px; overflow: hidden; gap: 2px;">
                  <div style="width: 38%; background: #10b981;" title="Voice: 38%"></div>
                  <div style="width: 28%; background: #06b6d4;" title="Gaming: 28%"></div>
                  <div style="width: 20%; background: #9333ea;" title="Media: 20%"></div>
                  <div style="width: 14%; background: #ec4899;" title="Music: 14%"></div>
                </div>
              </div>

              <!-- Footer Security Chip & Serial -->
              <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255, 255, 255, 0.08); padding-top: 0.8rem; font-size: 0.75rem; color: var(--text-muted);">
                <div style="display: flex; align-items: center; gap: 0.4rem;">
                  <div style="width: 18px; height: 14px; background: linear-gradient(135deg, #d4af37, #f3e5ab); border-radius: 2px; box-shadow: 0 0 4px rgba(212, 175, 55, 0.6);"></div>
                  <span style="font-family: 'JetBrains Mono', monospace; font-size: 0.7rem;">NFC SECURE</span>
                </div>
                <div id="passport-serial" style="font-family: 'JetBrains Mono', monospace; font-size: 0.7rem; letter-spacing: 0.08em;">
                  ID: #RAI-0000-PASS
                </div>
              </div>
            </div>
          </div>
        </div>

        <div style="text-align: center; margin-top: 1.5rem;">
          <button class="btn btn-outline btn-sm" onclick="exportPassportCard()" style="font-size: 0.85rem; padding: 0.45rem 1.2rem;">
            <span>📸</span> Download Digital Passport Card
          </button>
        </div>
      `;

      initPassport3D();
      loadPassportData(targetUserId);
    }

    function initPassport3D() {
      const card = document.getElementById('passport-3d-card');
      const sheen = document.getElementById('passport-holo-sheen');
      if (!card) return;

      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotateX = ((y - centerY) / centerY) * -12;
        const rotateY = ((x - centerX) / centerX) * 12;

        card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;

        if (sheen) {
          const px = (x / rect.width) * 100;
          const py = (y / rect.height) * 100;
          sheen.style.background = `radial-gradient(circle at ${px}% ${py}%, rgba(255, 255, 255, 0.3) 0%, rgba(147, 51, 234, 0.2) 40%, transparent 70%)`;
          sheen.style.opacity = '1';
        }
      });

      card.addEventListener('mouseleave', () => {
        card.style.transform = 'rotateX(0deg) rotateY(0deg)';
        if (sheen) sheen.style.opacity = '0';
      });
    }

    async function loadPassportData(userId) {
      try {
        const url = userId ? `/api/passport?user_id=${userId}` : '/api/passport';
        const res = await fetch(url);
        const json = await res.json();
        const data = (json.data && json.data.passport) ? json.data.passport : (json.passport || json);

        const nameEl = document.getElementById('passport-name');
        const handleEl = document.getElementById('passport-handle');
        const tierEl = document.getElementById('passport-tier-badge');
        const rankEl = document.getElementById('passport-rank-title');
        const levelEl = document.getElementById('passport-level');
        const coinsEl = document.getElementById('passport-coins');
        const streakEl = document.getElementById('passport-streak');
        const serialEl = document.getElementById('passport-serial');
        const avatarEl = document.getElementById('passport-avatar');

        if (nameEl) nameEl.innerText = data.display_name || 'Citizen';
        if (handleEl) handleEl.innerText = '@' + (data.handle || 'raivora');
        if (tierEl) tierEl.innerText = data.tier || 'CITIZEN';
        if (rankEl) rankEl.innerText = data.rank_title || 'Raivora Citizen';
        if (levelEl) levelEl.innerText = data.level || 1;
        if (coinsEl) coinsEl.innerText = (data.coins || 0).toLocaleString();
        if (streakEl) streakEl.innerText = `🔥 ${data.streak || 0}d`;
        if (serialEl) serialEl.innerText = `ID: #RAI-${(data.user_id || '0000').slice(-4)}-PASS`;
        if (avatarEl && data.avatar_url) {
          avatarEl.innerHTML = `<img src="${data.avatar_url}" style="width:100%; height:100%; object-fit:cover; border-radius:50%;" alt="Avatar">`;
        }
      } catch (err) {
        console.error('Failed to load passport data:', err);
      }
    }

    function exportPassportCard() {
      showToast('Generating holographic passport snapshot...', 'info');
      setTimeout(() => {
        showToast('Passport exported! You can save or share your digital card.', 'success');
      }, 1000);
    }

    // ==========================================
    // 30. INITIALIZATION
    // ==========================================
    function initApp() {
      initCanvasParticles();
      initCursorGlow();
      const initialHash = window.location.hash.replace('#', '') || '/';
      navigate(initialHash);
      initAuth();
      initRealtimeStream();
      initAssistant();
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initApp);
    } else {
      initApp();
    }

    window.addEventListener('hashchange', () => {
      const hash = window.location.hash.replace('#', '') || '/';
      if (hash !== currentRoute) navigate(hash);
    });
  </script>
</body>
</html>
"""
