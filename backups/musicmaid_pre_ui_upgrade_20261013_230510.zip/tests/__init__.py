"""
Sentinel Bot Test Suite.
"""
